@extends('layouts.adminuser')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }

        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Clerification</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Applications Clerification</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <h5 class="card-header ">
                            <b>Application Clerification</b>
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark float-right has-ripple"><i
                                    class="fas fa-long-arrow-alt-left"></i> Back</a>
                        </h5>
                        <div class="card-body">
                            <form action="{{ route('clerification.submit') }}" method="POST"
                                enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                    <input type="hidden" name="org_id" id="org_id" value="{{ $user->id }}">
                                    <input type="hidden" name="app_id" id="app_id" value="{{ $app->id }}">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="clerification_for"
                                                style="    top: -10px;
                                            font-size: 13px;
                                            font-weight: 600;
                                            color: #263e76;">Clerification
                                                For <span class="text-danger">*</span></label>
                                            {{-- <input type="file" name="file" id="file" class="form-control" placeholder="upload document"> --}}
                                            <select class="form-control" name="clerification_for" id="clerification_for"
                                                required>
                                                <option value="">--- Select Clerification for ---</option>
                                                <option value="ORG">CB</option>
                                                <option value="Assessor">Assessor</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="floating-label" for="file">Upload (optional)</label>
                                            <input type="file" name="file" id="file" class="form-control"
                                                placeholder="upload document">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="floating-label" for="clerification">Clerification <span
                                                    class="text-danger">*</span></label>
                                            <textarea name="clerification" id="clerification" rows="5" class="form-control" placeholder="Clerification ... .."
                                                required></textarea>
                                        </div>
                                    </div>


                                    <div class="col-sm-12 text-center my-4">
                                        <input type="submit" class="btn btn-primary" id="saveBtn" value="Submit Reply">
                                        {{-- <button class="btn btn-danger" class="close" data-dismiss="modal"
                                            aria-label="Close">Close</button> --}}
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                {{-- {{ dd($clerifications->count()) }} --}}
                @if ($clerifications->count() != 0)
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header justify-content-between text-center align-items-center py-3"
                            style="border-top: 4px solid #ffa900;">
                            <b>Clerifications</b>
                            {{-- <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm"><i
                                    class="fa fa-arrow-left"></i> Go Back</a> --}}
                        </div>
                        <div class="card-body">
                            @foreach ($clerifications as $clerification)
                                @if ($clerification->clerification_by == 'Dealing Officer')
                                    <div class="d-flex flex-row justify-content-start">
                                        <img src="{{ asset('assets/img/team/org_avatar.png') }}" alt="avatar 1"
                                            style="width: 45px; height: 100%;">
                                        <div class="p-3 me-3 border"
                                            style="border-radius: 15px; margin-left: 10px; background-color: #f5f6f7;">
                                            <p class="small mb-0">
                                                {{ $clerification->clerification ? $clerification->clerification : '.......' }}</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between mb-5">
                                        <p class="small mb-1">{{ $clerification->clerification_by }}</p>
                                        <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                aria-hidden="true"></i>
                                            {{ $clerification->created_at }}</p>
                                    </div>
                                @endif
                                @if ($clerification->clerification_by == 'Assessor')
                                    <div class="d-flex flex-row justify-content-end pt-1">
                                        <div class="p-3 ms-3 mr-2"
                                            style="border-radius: 15px; margin-right: 10px; background-color: rgba(57, 192, 237,.2);">
                                            <p class="small mb-0">
                                                {{ $clerification->clerification ? $clerification->clerification : '.......' }}
                                            </p>
                                        </div>
                                        <img src="{{ asset('assets/img/team/assessor_avatar.png') }}" alt="avatar 1"
                                            style="width: 45px; height: 100%;">
                                    </div>
                                    <div class="d-flex justify-content-between mb-5">
                                        <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                aria-hidden="true"></i>
                                            {{ $clerification->created_at }}</p>
                                        <p class="small mb-1">{{ $clerification->clerification_by }}</p>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
@endsection
