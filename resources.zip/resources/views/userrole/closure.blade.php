@extends('layouts.adminuser')
@section('content')
    <style>
        .date {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Closure</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Closure</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            {{-- @php
                $user = \App\User::where('id', $org_id)->first();
            @endphp --}}
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <h5 class="card-header text-center">
                            Closure Action
                            <a href="{{ route('assessor.allotment') }}"
                                class="btn btn-dark btn-sm float-right has-ripple"><i class="feather icon-arrow-left"></i>
                                Back</a>
                        </h5>
                        <div class="card-body my-2">
                            @php
                                $loginuser = Session('userRole');
                                $app = \App\ApplicationStatus::where('id', $app_id)->where('isDeleted',0)->first();
                                $user = \App\User::where('id',$app->user_id)->first();
                                @$cert = \App\AppClosure::where('org_id',$user->id)->where('app_id',$app->id)->where('do_id',$loginuser->id)->where('status','Recognise')->first();
                            @endphp
                            <form action="#" method="POST" id="userForm">
                                @csrf
                                {{-- <input type="hidden" name="org_id" id="org_id" value="{{ $user->id }}">
                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}"> --}}
                                {{-- <input type="hidden" name="alloted_by" id="alloted_by"  value="{{ $alloted_by }}"> --}}
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Organization
                                                Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="user"
                                                style="color: #4680ff;font-weight: 600;">{{ $user->name }}</label> &nbsp; &nbsp; &nbsp; &nbsp;
                                                @if (@$cert )
                                                <a href="http://paddscheme.7techies.com/certificate/index.php?id=<?php echo $app->id;?>" target="_blank" class="float-right btn btn-warning btn-sm mr-5 ">View Certificate</a>
                                                @endif
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">UserName</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="user"
                                                style="color: #4680ff;font-weight: 600;">{{ $user->username }}</label>
                                            <input type="hidden" name="org_id" id="org_id" value="{{ $user->id }}">
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app->id }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Application Number</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="user" style="color: #4680ff;font-weight: 600;">{{ $app->application_no }}</label>
                                        </div>
                                    </div>
                                </div>
                                @if ($app->stage != '4')
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Status</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline1"value="Recognise" name="status"
                                                class="custom-control-input status">
                                            <label class="custom-control-label" for="customRadioInline1">Recognise</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline2" value="Not Recognise"
                                                name="status" class="custom-control-input status">
                                            <label class="custom-control-label" for="customRadioInline2">Not
                                                Recognise</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="date">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="user" style="color: #080d19;font-weight: 600;">Issue
                                                    Date</label>
                                                <input type="date" name="from_date" id="from_date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="user" style="color: #080d19;font-weight: 600;">Valid
                                                    Upto</label>
                                                <input type="date" name="to_date" id="to_date" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 date">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Certificate Number
                                                </label>
                                            <input type="text" name="cert_no" id="cert_no" class="form-control"
                                                placeholder="Certificate number" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Final
                                                Remark</label>
                                            <textarea name="final_remark" id="final_remark" class="form-control" cols="30" rows="1"
                                                placeholder="Final Remark"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-12">
                                        <button type="submit" name="submit" class="btn btn-primary" id="SaveBtn">
                                            Submit Closure
                                        </button>
                                    </div>
                                </div>
                                @endif
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(".status").change(function() {
            if ($(this).is(":checked")) {
                var val = $(this).val();
                if (val == "Recognise") {
                    $('.date').show();
                } else {
                    $('.date').hide();
                }
            }
        });
    </script>
@endsection
