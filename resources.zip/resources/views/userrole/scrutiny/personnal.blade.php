@extends('layouts.adminuser')
@section('content')
    <style>
        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }
        .remark{
            display: none;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Scrutiny</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Scrutiny</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-pills bg-white" id="myTab" role="tablist">
                                <li class="nav-item">
                                        <a href="{{ route('scrutiny',[$app->id]) }}" class="nav-link text-uppercase">General Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('personnel.scrutiny',[$app->id]) }}" class="nav-link text-uppercase active has-ripple">Personnel Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('other.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Other Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('financial.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Financial Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('annexed.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Annexed</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('final.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Final Step</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <!-- varient [ 2 ][ cover shape ] card Start -->
                        <div class="tab-pane fade  show active" id="personal" role="tabpanel" aria-labelledby="personal-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2 text-center" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="2" style="background: #d6d6d6; text-align: center;">1.
                                                            Quality Manager or Management Representative</th>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2">
                                                            <table class="" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;">
                                                                <tr>
                                                                    <th>Quality Manager Name</th>
                                                                    <th>Quality Manager Designation</th>
                                                                </tr>
                                                                <tr>
                                                                    <td>{{ $personnel_info->quality_manager_name }}
                                                                    </td>
                                                                    <td>{{ $personnel_info->quality_manager_designation }}
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">2.
                                                                    Personnel for Voluntary Certification Scheme</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Location</th>
                                                                            <th>Managerial Staff</th>
                                                                            <th>Evaluators</th>
                                                                            <th>Support Staff</th>
                                                                            <th>Technical Staff</th>
                                                                            <th>Total</th>
                                                                        </tr>
                                                                        @foreach ($certificate_schemes as $certificate_scheme)
                                                                        @php
                                                                            $branch = \App\AppBranchAddress::where('id',$certificate_scheme->branch_id)->where('isDeleted',0)->first();
                                                                        @endphp
                                                                            <tr>
                                                                                <td>{{ @$branch->branch_name }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->managerial_staff }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->evaluators }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->support_staff }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->technical_experts }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->total }}</td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $user->id }}">
                                                        <input type="hidden" name="app_id"
                                                        value="{{ $app->id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="PI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_PI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate1" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_PI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="adequate1">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate1" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_PI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label "
                                                                    for="InAdequate1">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_PI ? $scrutiny_PI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
    </div>
    </div>
    </div>
@endsection

@section('script')
<script>
    window.onload = function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'InAdequate') {
                $(".remark").show();
            } else {
                $(".remark").hide();
            }
        };

$(".option").change(function() {
    // var val = $('input[name="option"]:checked').val();
    // alert(val);
            if ($(this).is(":checked")) {
                var val = $(this).val();
                if (val == "InAdequate") {
                    $('.remark').show();
                } else {
                    $('.remark').hide();
                }
            }
        });
</script>
@endsection
