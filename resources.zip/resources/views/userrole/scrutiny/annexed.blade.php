@extends('layouts.adminuser')
@section('content')
    <style>
        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }
        .remark{
            display: none;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Scrutiny</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Scrutiny</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-pills bg-white" id="myTab" role="tablist">
                                <li class="nav-item">
                                        <a href="{{ route('scrutiny',[$app->id]) }}" class="nav-link text-uppercase">General Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('personnel.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Personnel Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('other.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Other Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('financial.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Financial Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('annexed.scrutiny',[$app->id]) }}" class="nav-link text-uppercase active has-ripple">Annexed</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('final.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Final Step</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <!-- [ user card1 ] start -->
                        <!-- user card [ 3 ] Start -->
                        <div class="tab-pane fade show active" id="annexed" role="tabpanel" aria-labelledby="annexed-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="3" style="background: #d6d6d6; text-align: center;">
                                                            Annexed Information
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <td width="7%">(1)</td>
                                                        <td width="75%">
                                                            Organization Registration Certificate & Memorandum / Articles of
                                                            Association (copy only)
                                                        </td>
                                                        <td width="18%">
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(2)</td>
                                                        <td>
                                                            Master List of Documents reference of voluntary certification
                                                            scheme (with issue and/or revision status)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(3)</td>
                                                        <td>
                                                            Quality Manual by applicable accreditation standard i.e. ISO/IEC
                                                            17065, ISO/IEC 17021,ISO/IEC17024 etc.
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(4)</td>
                                                        <td>
                                                            Documentation relating to voluntary certification scheme
                                                            (Procedures, Competence Criteria, Formats, Checklists etc.)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(5)</td>
                                                        <td>
                                                            Branch Office(s) with activities to be covered under approval
                                                            (list per format in Table – A)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(6)</td>
                                                        <td>
                                                            List of Managerial Personnel, Auditors & Technical Experts (list
                                                            as per format in Table – B)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(7)</td>
                                                        <td>
                                                            Other Documents (annex list)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(8)</td>
                                                        <td>
                                                            Reference of any voluntary certification scheme
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td>
                                                            Any other relevant information
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $user->id }}">
                                                    <input type="hidden" name="app_id"
                                                        value="{{ $app->id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="AI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_AI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate4" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_AI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="adequate4">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate4" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_AI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate4">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_AI ? $scrutiny_AI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- user card [ 3 ] end -->
                        <div class="tab-pane fade" id="final" role="tabpanel" aria-labelledby="final-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12 my-2 mx-5">
                                                <form action="{{ route('sendtocb') }}" method="POST">
                                                    @csrf
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5>Final Report</h5>
                                                            <hr>
                                                            {{-- <div class="form-group">
                                                                <textarea name="" id="" cols="60" rows="5" placeholder="Remark" style="padding: 10px;"></textarea>
                                                            </div> --}}
                                                            {{-- @php

                                                                $scrutiny_GI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'GI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_PI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'PI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_OI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'OI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_FI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'FI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_AI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'AI')
                                                                    ->where('isActive', 0)
                                                                    ->first();

                                                                    $scrutiny = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('option', 'Adequate')
                                                                    ->where('isActive', 0)
                                                                    ->get();
                                                            @endphp --}}
                                                            @php
                                                                 $scrutiny = \App\AppScrutiny::where('org_id', $general_info->org_id)
                                                                    ->where('option', 'Adequate')
                                                                    ->where('isActive', 0)
                                                                    ->get();
                                                            @endphp
                                                        {{-- {{ dd($scrutiny->count()) }} --}}
                                                            <div>
                                                                @if ($scrutiny->count() == 5)
                                                                <a href="{{ route('scrutiny.close', [$general_info->org_id]) }}"
                                                                    class="btn btn-primary has-ripple">Scrutiny
                                                                    Close</a>
                                                                   @else 
                                                                   <button type="submit" class="btn btn-primary has-ripple">Send this report
                                                                                         to CB</button>
                                                                @endif
                                                                {{-- @if (@$scrutiny_GI->option = 'Adequate')
                                                                    @if (@$scrutiny_PI->option = 'Adequate')
                                                                        @if (@$scrutiny_OI->option = 'Adequate')
                                                                            @if (@$scrutiny_FI->option = 'Adequate')
                                                                                @if (@$scrutiny_AI->option = 'Adequate')
                                                                                    <a href="{{ route('scrutiny.close', [$general_info->org_id]) }}"
                                                                                        class="btn btn-primary has-ripple">Scrutiny
                                                                                        Close</a>
                                                                                @else
                                                                                    <button type="submit"
                                                                                        class="btn btn-primary has-ripple">Report
                                                                                        Send to CB</button>
                                                                                @endif
                                                                            @endif
                                                                        @endif
                                                                    @endif
                                                                @endif --}}

                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
    </div>
    </div>
    </div>
@endsection

@section('script')
<script>
 window.onload = function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'InAdequate') {
                $(".remark").show();
            } else {
                $(".remark").hide();
            }
        };

    $(".option").change(function() {
    // var val = $('input[name="option"]:checked').val();
    // alert(val);
            if ($('input[name="option"]:checked').val()) {
                var val = $('input[name="option"]:checked').val();
                if (val == "InAdequate") {
                    $('.remark').show();
                } else {
                    $('.remark').hide();
                }
            }
        });
</script>
@endsection
