@extends('layouts.adminuser')
@section('content')
    <style>
        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Scrutiny</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Scrutiny</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-pills bg-white" id="myTab" role="tablist">
                                <li class="nav-item">
                                        <a href="{{ route('scrutiny',[$app->id]) }}" class="nav-link text-uppercase">General Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('personnel.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Personnel Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('other.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Other Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('financial.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Financial Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('annexed.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Annexed</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('final.scrutiny',[$app->id]) }}" class="nav-link text-uppercase active has-ripple">Final Step</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <!-- user card [ 3 ] end -->
                        <div class="tab-pane fade show active" id="final" role="tabpanel" aria-labelledby="final-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12 my-2 mx-5">
                                                <form action="{{ route('sendtocb') }}" method="POST">
                                                    @csrf
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $user->id }}">
                                                        <input type="hidden" name="app_id"
                                                        value="{{ $app->id }}">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5>Final Report</h5>
                                                            <hr>
                                                            @php
                                                                 $scrutiny = \App\AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)
                                                                    ->where('option', 'Adequate')
                                                                    ->where('isActive', 0)
                                                                    ->get();
                                                                    $has_all_scrutiny = \App\AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)
                                                                                        ->where('isActive', 0)->get();
                                                            @endphp
                                                        {{-- {{ dd($has_all_scrutiny->count()) }} --}}
                                                            <div>
                                                                @if ($scrutiny->count() == 5)
                                                                <a href="{{ route('scrutiny.close', [$app->id]) }}"
                                                                    class="btn btn-primary has-ripple">Scrutiny
                                                                    Close</a>
                                                                    @elseif ($has_all_scrutiny->count() != 5)
                                                                       <h5 class="text-danger"><b>* You must have scrutiny of each and every Application form before proceeding next action.</b></h5>
                                                                   @else 
                                                                   <button type="submit" class="btn btn-primary has-ripple">Send This Report
                                                                                         To CB</button>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
    </div>
    </div>
    </div>
@endsection
