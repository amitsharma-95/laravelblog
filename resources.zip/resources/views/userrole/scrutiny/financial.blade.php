@extends('layouts.adminuser')
@section('content')
    <style>
        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }
        .remark{
            display: none;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Scrutiny</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Scrutiny</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-pills bg-white" id="myTab" role="tablist">
                                <li class="nav-item">
                                        <a href="{{ route('scrutiny',[$app->id]) }}" class="nav-link text-uppercase">General Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('personnel.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Personnel Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('other.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Other Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('financial.scrutiny',[$app->id]) }}" class="nav-link text-uppercase active has-ripple">Financial Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('annexed.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Annexed</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('final.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Final Step</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <!-- varient [ Profile ] card Start -->
                        <div class="tab-pane fade show active" id="financial" role="tabpanel" aria-labelledby="financial-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2 text-center" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="2" style="background: #d6d6d6; text-align: center;">
                                                            Financial Performance</th>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2">
                                                            <table class="" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;">
                                                                <tr>
                                                                    <th>Financial Year</th>
                                                                    <th>Total Income</th>
                                                                    <th>Income from certification</th>
                                                                    <th>Net Profit</th>
                                                                </tr>
                                                                @foreach ($financial_performances as $financial_performance)
                                                                    <tr>
                                                                        <td>{{ $financial_performance->financial_year }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->total_income }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->income_from_certification }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->net_profit }}</td>
                                                                    </tr>
                                                                @endforeach
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $user->id }}">
                                                        <input type="hidden" name="app_id"
                                                        value="{{ $app->id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="FI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_FI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate3" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_FI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="adequate3">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate3" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_FI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate3">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_FI ? $scrutiny_FI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- varient [ Profile ] card End -->
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
    </div>
    </div>
    </div>
@endsection

@section('script')
<script>
 window.onload = function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'InAdequate') {
                $(".remark").show();
            } else {
                $(".remark").hide();
            }
        };

    $(".option").change(function() {
    // var val = $('input[name="option"]:checked').val();
    // alert(val);
            if ($(this).is(":checked")) {
                var val = $(this).val();
                if (val == "InAdequate") {
                    $('.remark').show();
                } else {
                    $('.remark').hide();
                }
            }
        });
</script>
@endsection
