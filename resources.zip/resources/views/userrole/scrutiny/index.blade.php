@extends('layouts.adminuser')
@section('content')
    <style>
        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }
        .remark{
            display: none;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Scrutiny</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Application Scrutiny</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-pills bg-white" id="myTab" role="tablist">
                                <li class="nav-item">
                                        <a href="{{ route('scrutiny',[$app->id]) }}" class="nav-link text-uppercase active has-ripple">General Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('personnel.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Personnel Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('other.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Other Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('financial.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Financial Information</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('annexed.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Annexed</a>
                                </li>
                                <li class="nav-item">
                                        <a href="{{ route('final.scrutiny',[$app->id]) }}" class="nav-link text-uppercase">Final Step</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <!-- [ user card1 ] start -->
                        <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card user-card-1">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12 " style="font-size: 15px;">
                                                <table class="" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    {{-- <tr>
                                                        <th colspan="2" style="background: #d6d6d6; text-align:center">
                                                            General Information
                                                        </th>
                                                    </tr> --}}
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">1.
                                                                    Conformity Assessment Bodies</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Name of the Organization</th>
                                                                            <th>Name of the Scheme</th>
                                                                            <th>Scheme Level</th>
                                                                            <th>Contact Number</th>
                                                                            <th>Email Address</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ $user->org_name }}</td>
                                                                            <td>{{ $scheme->scheme_name }}</td>
                                                                            <td>{{ $app->level }}</td>
                                                                            <td>{{ $general_info->ab_mobile }}</td>
                                                                            <td>{{ $general_info->ab_email }}</td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">2.
                                                                    Address
                                                                    of Main Office</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Address of Main Office</th>
                                                                            <th>State</th>
                                                                            <th>City</th>
                                                                            <th>Pincode</th>
                                                                            <th>Website</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ $general_info->main_ofc_address }}
                                                                            </td>
                                                                            <td>{{ $general_info->state }}
                                                                            </td>
                                                                            <td>{{ $general_info->city }}
                                                                            </td>
                                                                            <td>{{ $general_info->pin }}
                                                                            </td>
                                                                            <td>{{ $general_info->web }}
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th colspan="2"
                                                                    style="background: #d6d6d6; text-align: center;">3.
                                                                    Ownership Details</th>
                                                            </tr>
                                                            <tr>
                                                                <td width="50%">Ownership Detail</td>
                                                                <td>{{ $general_info->owneship_detail }}</td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">4.
                                                                    Legal Registration Details</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Status</th>
                                                                            <th>Registration Number</th>
                                                                            <th>Date of Registration</th>
                                                                            <th>Registration Authority</th>
                                                                            <th>Place of Registration</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ $general_info->status }}
                                                                            </td>
                                                                            <td>{{ $general_info->reg_no }}
                                                                            </td>
                                                                            <td>{{ $general_info->reg_date }}
                                                                            </td>
                                                                            <td>{{ $general_info->reg_authority }}
                                                                            </td>
                                                                            <td>{{ $general_info->reg_place }}
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">5.
                                                                    Chief Executive Details</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Chief Executive Name</th>
                                                                            <th>Chief Executive Designation</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ $general_info->chief_name }}
                                                                            </td>
                                                                            <td>{{ $general_info->chief_designation }}
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">6.
                                                                    Primary Contact Person Details</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Designation</th>
                                                                            <th>Mobile Number</th>
                                                                            <th>Email Address</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ $user->name }}
                                                                            </td>
                                                                            <td>{{ $general_info->p_designation }}
                                                                            </td>
                                                                            <td>{{ $user->mobile }}</td>
                                                                            <td>{{ $user->email }}</td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">7.
                                                                    Address
                                                                    of Branch Office/Offices</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Branch Name</th>
                                                                            <th> Address of Branch Office</th>
                                                                            <th>State</th>
                                                                            <th>City</th>
                                                                            <th>Pincode</th>
                                                                            <th>Contact Person</th>
                                                                            <th>Designation</th>
                                                                            <th>Email</th>
                                                                            <th>Mobile</th>
                                                                        </tr>
                                                                        @foreach ($branch_addresses as $branch_address)
                                                                            <tr>
                                                                                <td>{{ $branch_address->branch_name }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_address }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_state }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_city }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_pin }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_p_name }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_p_designation }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_p_email }}
                                                                                </td>
                                                                                <td>{{ $branch_address->branch_p_mobile }}
                                                                                </td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $user->id }}">
                                                        <input type="hidden" name="app_id" id="app_id" value="{{ $app->id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="GI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_GI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_GI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="adequate">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_GI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input option">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_GI ? $scrutiny_GI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ user card1 ] end -->
                        <!-- varient [ 2 ][ cover shape ] card Start -->
                        <div class="tab-pane fade" id="personal" role="tabpanel" aria-labelledby="personal-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2 text-center" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="2" style="background: #d6d6d6; text-align: center;">1.
                                                            Quality Manager or Management Representative</th>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2">
                                                            <table class="" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;">
                                                                <tr>
                                                                    <th>Quality Manager Name</th>
                                                                    <th>Quality Manager Designation</th>
                                                                </tr>
                                                                <tr>
                                                                    <td>{{ $personnel_info->quality_manager_name }}
                                                                    </td>
                                                                    <td>{{ $personnel_info->quality_manager_designation }}
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-2" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">2.
                                                                    Personnel for Voluntary Certification Scheme</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Location</th>
                                                                            <th>Managerial Staff</th>
                                                                            <th>Evaluators</th>
                                                                            <th>Support Staff</th>
                                                                            <th>Technical Staff</th>
                                                                            <th>Total</th>
                                                                        </tr>
                                                                        @foreach ($certificate_schemes as $certificate_scheme)
                                                                            <tr>
                                                                                <td>{{ $certificate_scheme->location }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->managerial_staff }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->evaluators }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->support_staff }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->technical_experts }}
                                                                                </td>
                                                                                <td>{{ $certificate_scheme->total }}</td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="PI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_PI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate1" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_PI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="adequate1">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate1" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_PI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate1">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_PI ? $scrutiny_PI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- varient [ 2 ][ cover shape ] card end -->
                        <!-- varient [ footer color ] card Start -->
                        <div class="tab-pane fade" id="other" role="tabpanel" aria-labelledby="other-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2 text-center" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    {{-- <tr>
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align: center;">Other Information</th>
                                                        </tr> --}}
                                                    <tr>
                                                        <table class="text-center mt-1" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">1.
                                                                    NABCB member body accreditation</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Certificate Number</th>
                                                                            <th>Validity Period from</th>
                                                                            <th>Validity Period to</th>
                                                                        </tr>
                                                                        @foreach ($nabcb_bodies as $nabcb_body)
                                                                            <tr>
                                                                                <td>{{ $nabcb_body->nabcb_name }}</td>
                                                                                <td>{{ $nabcb_body->nabcb_cert_no }}</td>
                                                                                <td>{{ $nabcb_body->nabcb_valid_from }}
                                                                                </td>
                                                                                <td>{{ $nabcb_body->nabcb_valid_to }}
                                                                                </td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-1" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">2.
                                                                    other IAF member body accreditation</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Certificate Number</th>
                                                                            <th>Validity Period from</th>
                                                                            <th>Validity Period to</th>
                                                                        </tr>
                                                                        @foreach ($iaf_member_bodies as $iaf_member_body)
                                                                            <tr>
                                                                                <td>{{ $iaf_member_body->iaf_name }}</td>
                                                                                <td>{{ $iaf_member_body->iaf_cert_no }}
                                                                                </td>
                                                                                <td>{{ $iaf_member_body->iaf_valid_from }}
                                                                                </td>
                                                                                <td>{{ $iaf_member_body->iaf_valid_to }}
                                                                                </td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-1" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th style="background: #d6d6d6; text-align: center;">3.
                                                                    Other Approval(s) from Govt. or Regulatory Bodies</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Certificate Number</th>
                                                                            <th>Validity Period from</th>
                                                                            <th>Validity Period to</th>
                                                                        </tr>
                                                                        @foreach ($other_approvals as $other_approval)
                                                                            <tr>
                                                                                <td>{{ $other_approval->other_name }}
                                                                                </td>
                                                                                <td>{{ $other_approval->other_cert_no }}
                                                                                </td>
                                                                                <td>{{ $other_approval->other_valid_from }}
                                                                                </td>
                                                                                <td>{{ $other_approval->other_valid_to }}
                                                                                </td>
                                                                            </tr>
                                                                        @endforeach
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                    <tr>
                                                        <table class="text-center mt-1" border="1" cellspacing="0"
                                                            align="Center" rules="all"
                                                            style="border-collapse:collapse;width: 100%;border: beige;">
                                                            <tr>
                                                                <th colspan="2"
                                                                    style="background: #d6d6d6; text-align: center;">4.
                                                                    Other Other activities</th>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <table class="" border="1" cellspacing="0"
                                                                        align="Center" rules="all"
                                                                        style="border-collapse:collapse;width: 100%;">
                                                                        <tr>
                                                                            <th>Other activities within the same legal
                                                                                entity</th>
                                                                            <th>Related Organization(s), if any, and their
                                                                                activities</th>
                                                                            <th>Major Clients</th>
                                                                            <th>No. of Certificates issued for applied scope
                                                                            </th>
                                                                            <th>Total No. of Certificates issued</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>{{ @$other_information->other_activities }}
                                                                            </td>
                                                                            <td>{{ @$other_information->related_org }}
                                                                            </td>
                                                                            <td>{{ @$other_information->major_clients }}
                                                                            </td>
                                                                            <td>{{ @$other_information->no_of_certificates }}
                                                                            </td>
                                                                            <td>{{ @$other_information->total_certificate_issued }}
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="OI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_OI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate2" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_OI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="adequate2">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate2" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_OI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate2">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_OI ? $scrutiny_OI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- varient [ footer color ] card end -->
                        <!-- varient [ Profile ] card Start -->
                        <div class="tab-pane fade" id="financial" role="tabpanel" aria-labelledby="financial-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2 text-center" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="2" style="background: #d6d6d6; text-align: center;">
                                                            Financial Performance</th>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2">
                                                            <table class="" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;">
                                                                <tr>
                                                                    <th>Financial Year</th>
                                                                    <th>Total Income</th>
                                                                    <th>Income from certification</th>
                                                                    <th>Net Profit</th>
                                                                </tr>
                                                                @foreach ($financial_performances as $financial_performance)
                                                                    <tr>
                                                                        <td>{{ $financial_performance->financial_year }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->total_income }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->income_from_certification }}
                                                                        </td>
                                                                        <td>{{ $financial_performance->net_profit }}</td>
                                                                    </tr>
                                                                @endforeach
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="FI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_FI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate3" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_FI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="adequate3">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate3" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_FI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate3">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_FI ? $scrutiny_FI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- varient [ Profile ] card End -->
                        <!-- user card [ 3 ] Start -->
                        <div class="tab-pane fade" id="annexed" role="tabpanel" aria-labelledby="annexed-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12">
                                                <table class="mt-2" border="1" cellspacing="0" align="Center"
                                                    rules="all" style="border-collapse:collapse;width: 100%;border: beige;">
                                                    <tr>
                                                        <th colspan="3" style="background: #d6d6d6; text-align: center;">
                                                            Annexed Information
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <td width="7%">(1)</td>
                                                        <td width="75%">
                                                            Organization Registration Certificate & Memorandum / Articles of
                                                            Association (copy only)
                                                        </td>
                                                        <td width="18%">
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(2)</td>
                                                        <td>
                                                            Master List of Documents reference of voluntary certification
                                                            scheme (with issue and/or revision status)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(3)</td>
                                                        <td>
                                                            Quality Manual by applicable accreditation standard i.e. ISO/IEC
                                                            17065, ISO/IEC 17021,ISO/IEC17024 etc.
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(4)</td>
                                                        <td>
                                                            Documentation relating to voluntary certification scheme
                                                            (Procedures, Competence Criteria, Formats, Checklists etc.)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(5)</td>
                                                        <td>
                                                            Branch Office(s) with activities to be covered under approval
                                                            (list per format in Table – A)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(6)</td>
                                                        <td>
                                                            List of Managerial Personnel, Auditors & Technical Experts (list
                                                            as per format in Table – B)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(7)</td>
                                                        <td>
                                                            Other Documents (annex list)
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>(8)</td>
                                                        <td>
                                                            Reference of any voluntary certification scheme
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td>
                                                            Any other relevant information
                                                        </td>
                                                        <td>
                                                            <a href="#" class="text-success"><i
                                                                    class="fa fa-eye"></i> view</a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-12 my-5 mx-5">
                                                <form action="{{ route('adminuser.scrutiny') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="scrutiny_for" value="AI">
                                                    <input type="hidden" name="id" value="{{ @$scrutiny_AI->id }}">
                                                    {{-- @if (Session::has('success'))
                                                        <span
                                                            class=" alert alert-success error">{{ Session('success') }}</span>
                                                    @endif --}}
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5 class="mt-2">Scrutiny Report</h5>
                                                            <hr>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="adequate4" name="option"
                                                                    value="Adequate"
                                                                    {{ @$scrutiny_AI->option == 'Adequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="adequate4">Adequate</label>
                                                            </div>
                                                            <div class="custom-control custom-radio mb-2">
                                                                <input type="radio" id="InAdequate4" name="option"
                                                                    value="InAdequate"
                                                                    {{ @$scrutiny_AI->option == 'InAdequate' ? 'checked' : '' }}
                                                                    class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                    for="InAdequate4">InAdequate</label>
                                                            </div>
                                                            @error('option')
                                                                <span class="alert alert-danger">{{ $message }}</span>
                                                            @enderror
                                                            <div class="form-group remark">
                                                                <textarea name="remark" id="remark" cols="60" rows="5" placeholder="Remark"
                                                                    style="padding: 10px;">{{ $scrutiny_AI ? $scrutiny_AI->remark : '' }}</textarea>
                                                            </div>
                                                            <div>
                                                                <button type="submit"
                                                                    class="btn btn-primary has-ripple">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- user card [ 3 ] end -->
                        <div class="tab-pane fade" id="final" role="tabpanel" aria-labelledby="final-tab">
                            <div class="row mb-n4">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card user-card">
                                        <div class="card-body pt-4">
                                            <div class="col-md-12 my-2 mx-5">
                                                <form action="{{ route('sendtocb') }}" method="POST">
                                                    @csrf
                                                    @php
                                                        $alloted_user_id = Session('userRole');
                                                    @endphp
                                                    <input type="hidden" name="alloted_user_id"
                                                        value="{{ $alloted_user_id->id }}">
                                                    <input type="hidden" name="org_id"
                                                        value="{{ $general_info->org_id }}">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h5>Final Report</h5>
                                                            <hr>
                                                            {{-- <div class="form-group">
                                                                <textarea name="" id="" cols="60" rows="5" placeholder="Remark" style="padding: 10px;"></textarea>
                                                            </div> --}}
                                                            {{-- @php

                                                                $scrutiny_GI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'GI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_PI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'PI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_OI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'OI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_FI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'FI')
                                                                    ->where('isActive', 0)
                                                                    ->first();
                                                                $scrutiny_AI = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('scrutiny_for', 'AI')
                                                                    ->where('isActive', 0)
                                                                    ->first();

                                                                    $scrutiny = \App\AppScrutiny::where('org_id', $user->org_id)
                                                                    ->where('option', 'Adequate')
                                                                    ->where('isActive', 0)
                                                                    ->get();
                                                            @endphp --}}
                                                            @php
                                                                 $scrutiny = \App\AppScrutiny::where('org_id', $general_info->org_id)
                                                                    ->where('option', 'Adequate')
                                                                    ->where('isActive', 0)
                                                                    ->get();
                                                            @endphp
                                                        {{-- {{ dd($scrutiny->count()) }} --}}
                                                            <div>
                                                                @if ($scrutiny->count() == 5)
                                                                <a href="{{ route('scrutiny.close', [$general_info->org_id]) }}"
                                                                    class="btn btn-primary has-ripple">Scrutiny
                                                                    Close</a>
                                                                   @else 
                                                                   <button type="submit" class="btn btn-primary has-ripple">Send this report
                                                                                         to CB</button>
                                                                @endif
                                                                {{-- @if (@$scrutiny_GI->option = 'Adequate')
                                                                    @if (@$scrutiny_PI->option = 'Adequate')
                                                                        @if (@$scrutiny_OI->option = 'Adequate')
                                                                            @if (@$scrutiny_FI->option = 'Adequate')
                                                                                @if (@$scrutiny_AI->option = 'Adequate')
                                                                                    <a href="{{ route('scrutiny.close', [$general_info->org_id]) }}"
                                                                                        class="btn btn-primary has-ripple">Scrutiny
                                                                                        Close</a>
                                                                                @else
                                                                                    <button type="submit"
                                                                                        class="btn btn-primary has-ripple">Report
                                                                                        Send to CB</button>
                                                                                @endif
                                                                            @endif
                                                                        @endif
                                                                    @endif
                                                                @endif --}}

                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div> 
    </div>
    </div>
    </div>
    </div>
@endsection

@section('script')
<script>
    $(document).ready(function () {
        $("#general-tab").addClass("active");
    });

    window.onload = function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'InAdequate') {
                $(".remark").show();
            } else {
                $(".remark").hide();
            }
        };
    $(".option").change(function() {
            if ($(this).is(":checked")) {
                var val = $(this).val();
                if (val == "InAdequate") {
                    $('.remark').show();
                } else {
                    $('.remark').hide();
                }
            }
        });
</script>
@endsection
