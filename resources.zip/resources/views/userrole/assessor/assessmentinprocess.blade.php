@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Assessor Not Alloted</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Assessor Not Alloted</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <h5 class="card-header text-center">
                            Assessor Allotment Pending
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm float-right has-ripple"><i class="feather icon-arrow-left"></i> Back</a>
                        </h5>
                        <div class="card-body">
                            <div class="dt-responsive table-responsive">
                                    <table id="example"  class="table nowrap table-striped table-bordered"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%">S.No.</th>
                                                <th style="width: 10%">Username</th>
                                                <th style="width: 15%">Org Name</th>
                                                <th style="width: 38%">Scheme</th>
                                                <th style="width: 18%">Level</th>
                                                <th style="width: 8%">Preview</th>
                                                <th style="width: 8%">Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Username</th>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                {{-- <th>Assessor Name</th> --}}
                                                <th>Preview</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @php
                                                $i = 1;
                                            @endphp
                                            @foreach ($allotments as $itemA)
                                                @php
                                                    if (!$itemA == null) {
                                                        $applications = \App\ApplicationStatus::where('id', $itemA->app_id)
                                                            ->where('user_id', $itemA->org_id)
                                                            ->whereNotIn('stage', array('2','2A','2B','2C','2D'))
                                                            ->where('isDeleted', 0)
                                                            ->get();
                                                    } else {
                                                        $applications = [];
                                                    }
                                                @endphp
                                                @foreach ($applications as $item)
                                                    @php
                                                        $loginuser = Session('userRole');
                                                        $applicant = \App\User::where('id', $item->user_id)->first();
                                                        $scheme = \App\AppScheme::where('id', $item->scheme)->first();
                                                        $checkStage = ['2', '2B', '2D'];
                                                    @endphp
                                                    @if ($applications != null)
                                                        <tr>
                                                            <td>{{ $i }}</td>
                                                            <td>
                                                                <div class="handsontable">{{ $applicant->username }}
                                                            </td>
                                                            <td>
                                                                <div class="handsontable">{{ $applicant->org_name }}
                                                            </td>
                                                            <td>
                                                                <div class="handsontable">{{ $scheme->scheme_name }}
                                                            </td>
                                                            <td>
                                                                <div class="handsontable">{{ $item->level }}
                                                            </td>
                                                            {{-- <td>{{ @$alloted_user->name }}</td> --}}
                                                            <td><a class="text-success handsontable"
                                                                    href="{{ route('application.preview', [$item->id]) }}"
                                                                    target="_blank"><i class="feather icon-eye"></i> preview</a>
                                                            </td>
                                                            <td>
                                                                <div class="handsontable">
                                                                    @if ($item->stage == '2')
                                                                        <span
                                                                            class="badge badge-light-warning handsontable">Allot
                                                                            Assessor</span>
                                                                        <a href="{{ route('allot.assessor', [$item->id]) }}"
                                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                                            <i class="feather icon-check-circle"></i> </a>
                                                                    @elseif ($item->stage == '2A')
                                                                        <span
                                                                            class="badge badge-light-success handsontable">Assessor
                                                                            Alloted</span>
                                                                    @elseif ($item->stage == '2B')
                                                                        <span
                                                                            class="handsontable badge badge-light-{{ $assessment->assessor_action == 'reject' ? 'danger' : 'primary' }}">{{ $assessment->assessor_action }}
                                                                            from ORG Side</span>
                                                                        <a href="{{ route('allot.assessor', [$item->id]) }}"
                                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                                            <i class="feather icon-check-circle"></i> </a>
                                                                    @elseif ($item->stage == '2C')
                                                                        <span
                                                                            class="badge badge-light-primary handsontable">Sent
                                                                            to
                                                                            ORG for Acceptance</span>
                                                                    @elseif ($item->stage == '2D')
                                                                        <span
                                                                            class="handsontable badge badge-light-{{ $assessment->cb_action == 'reject' ? 'danger' : 'primary' }}">{{ $assessment->cb_action }}
                                                                            from ORG Side</span>
                                                                        <a href="{{ route('allot.assessor', [$item->id]) }}"
                                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                                            <i class="feather icon-check-circle"></i> </a>
                                                                    @elseif ($item->stage == '2E')
                                                                        <span
                                                                            class="badge badge-light-primary handsontable">Assessment
                                                                            Started</span>
                                                                    @elseif ($item->stage == '2F')
                                                                        <span class="badge badge-light-primary handsontable">NC
                                                                            Sent
                                                                            to ORG</span>
                                                                        <a href="{{ route('ncreplies', [$item->id]) }}"
                                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                                            <i class="feather icon-check-circle"></i> </a>
                                                                    @elseif ($item->stage == '2G')
                                                                        <span
                                                                            class="badge badge-light-primary handsontable">Reply
                                                                            sent to Assessor</span>
                                                                        <a href="{{ route('ncreplies', [$item->id]) }}"
                                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                                            <i class="feather icon-check-circle"></i> </a>
                                                                    @else
                                                                        <span
                                                                            class="badge badge-light-success handsontable">Assessor
                                                                            Alloted</span>
                                                                    @endif
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endif
                                                    @php
                                                        $i++;
                                                    @endphp
                                                @endforeach
                                            @endforeach
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });

            //popup
            // $('body').on('click', '.allotmentUser', function() {
            //     var id = $(this).data('id');
            //     $('#userAllotmentModel').modal('show');

            // });

        });
    </script>
@endsection
