@extends('layouts.adminuser')
@section('content')
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Allotment Process</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ route('adminuser.dashboard') }}"><i class="feather icon-home"></i></a></li>
                                {{-- <li class="breadcrumb-item"><a href="#!">Allotment</a></li> --}}
                                <li class="breadcrumb-item"><a href="#!">Allotment Process</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                @php
                    $loginuser = Session('userRole');
                    $status = \App\ApplicationStatus::where('id',$app_id)->where('user_id',$org->id)->first();
                    $allotment = \App\AppUserAllotment::where('org_id',$org->id)->where('app_id',$status->id)->where('alloted_to',$loginuser->id)->where('isActive',0)->first();
                    $check_assessor = \App\AppUserAllotment::where('org_id',$org->id)->where('app_id',$status->id)->where('alloted_by',$loginuser->id)->first();
                    if ($check_assessor != null) {
                        @$assessor = \App\AdminUser::where('id',$check_assessor->alloted_to)->first();
                        @$assessment = \App\AppAssessment::where('org_id',$org->id)->where('app_id',$status->id)->Where('assessor_id',$assessor->id)->where('isActive',0)->first() ;
                        @$assessment_rejects = \App\AppAssessment::where('org_id',$org->id)->where('app_id',$status->id)->Where('assessor_id',$assessor->id)->where('isActive',1)->get() ;
                    }
                @endphp
                @if ($status->stage == '2' || $status->stage == '2C' || $status->stage == '2D' )
                <div class="col-lg-6">
                    <div class="card user-profile-list">
                        <h5 class="card-header text-center">
                            Allotment of Assessor
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm float-right">back</a>
                        </h5>
                        <div class="card-body mb-2">
                            <form action="{{ route('allotment.assessor') }}" method="POST" id="userForm">
                                @csrf
                                <input type="hidden" name="org_id" id="org_id" value="{{ $org->id }}">
                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                <input type="hidden" name="alloted_by" id="alloted_by"  value="{{ $loginuser->id }}">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Assessment from</label>
                                            <input type="date" name="from_date" id="from_date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Assessment to</label>
                                            <input type="date" name="to_date" id="to_date"  class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Select User</label>
                                            <select class="form-control" name="alloted_to" id="alloted_to" style="width:100%"
                                                required>
                                                <option value="" selected>Select User for Allotment</option>
                                                @foreach ($role_users as $user)
                                                    <option value="{{ $user->id }}" style="z-index: 9999;">
                                                        {{ $user->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Select Assessment Type</label>
                                            <select class="form-control" name="assessment_type" id="assessment_type" style="width:100%"
                                                required>
                                                <option value="" selected>Select Type of Assessment</option>
                                                <option value="Office Assessment">Office Assessment</option>
                                                <option value="Follow Up Assessment">Follow Up Assessment</option>
                                                <option value="Witness Assessment">Witness Assessment</option>
                                                <option value="Surveillance Assessment">Surveillance Assessment</option>
                                                <option value="Extension Assessment">Extension Assessment</option>
                                                <option value="Special Assessment">pecial Assessment (Change in Name/Scope/Address etc. Complaint Verification/Validation)</option>
                                                <option value="Document Assessment">Document Assessment </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-12">
                                        <button type="submit" name="submit" class="btn btn-primary" id="SaveBtn"> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @endif
                
                <div class="col-lg-6">
                    @if ($status->stage == '2C')
                    <div class="card">
                        <h5 class="card-header text-center">
                            Assessor Acceptance Status
                        </h5>
                        
                        <div class="card-body">
                            <table class="table nowrap table-bordered" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th>Assessor name</th>
                                        <th>Action</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach (@$assessment_rejects as $assessment_rejected)
                                    <tr>
                                        <td>{{ @$assessor->name }}</td>
                                        <td>{{ @$assessment_rejected->assessor_action?$assessment_rejected->assessor_action:'Acceptance Pending' }}</td>
                                        <td>{{ @$assessment_rejected->assessor_remark?$assessment_rejected->assessor_remark:'' }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                                
                            </table>
                            <div class="text-center">
                                <h5 class="text-danger">* Reject from assessor Side</h5>
                            </div>                           
                        </div>
                    </div>
                    @endif
                    @if ($status->stage == '2D')
                        <div class="card">
                            <h5 class="card-header text-center">
                                ORG Acceptance Status
                            </h5>
                            <div class="card-body">
                                <table class="table nowrap table-bordered" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>ORG name</th>
                                            <th>Action</th>
                                            <th>Remark</th>
                                        </tr>
                                    </thead>
                                    @php
                                        $user = \App\User::where('id', $org->id)->first();
                                    @endphp
                                    <tbody>
                                        <tr>
                                            <td>{{ $user->username }}</td>
                                            <td>{{ @$assessment->cb_action?$assessment->cb_action:'Acceptance Pending' }}</td>
                                            <td>{{ @$assessment->cb_remark?$assessment->cb_remark:'' }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="text-center">
                                    <h5 class="text-danger">* Reject from ORG Side</h5>
                                </div>  
                            </div>
                        </div>
                        {{-- <div class="col-lg-">
                            <div class="card">
                                <h5 class="card-header text-center">
                                    Assessor Acceptance
                                </h5>
                                <div class="card-body">
                                    <table class="table nowrap table-bordered" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th>Assessor name</th>
                                                <th>Action</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>{{ @$assessor->name }}</td>
                                                <td>{{ @$assessment->assessor_action?$assessment->assessor_action:'Acceptance Pending' }}</td>
                                                <td>{{ @$assessment->assessor_remark?$assessment->assessor_remark:'' }}</td>
                                            </tr>
                                        </tbody>
                                        
                                    </table>
                                    @if ($status->stage == '2B' || $status->stage == '2C')
                                        @if ($assessment->assessor_action == 'Accept')
                                            <div class="text-center">
                                               <a href="#" class="btn btn-primary btn-sm">Send to ORG for Acceptance</a>
                                            </div>
                                            @else
                                            <div class="text-center">
                                                <h5 class="text-danger">* Reject from assessor Side</h5>
                                            </div>
                                        @endif
                                        @endif
                                    @if ($status->stage == '2D')
                                        <div class="text-center">
                                                <a href="#" class="btn btn-primary btn-sm">Assessment Start</a>
                                        </div>
                                    @endif                                
                                </div>
                            </div>
                        </div> --}}
                    @endif
                    @if ($status->stage == '2B' || $status->stage == '2D')
                    <div class="col-lg-">
                        <div class="card">
                            <h5 class="card-header text-center">
                                Assessor Acceptance Status
                                <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm float-right">back</a>
                            </h5>
                            <div class="card-body">
                                <table class="table nowrap table-bordered" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>Assessor name</th>
                                            <th>Action</th>
                                            <th>Remark</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>{{ @$assessor->name }}</td>
                                            <td>{{ @$assessment->assessor_action?$assessment->assessor_action:'Acceptance Pending' }}</td>
                                            <td>{{ @$assessment->assessor_remark?$assessment->assessor_remark:'' }}</td>
                                        </tr>
                                    </tbody>
                                    
                                </table>
                                @if ($status->stage == '2B' || $status->stage == '2C')
                                    @if ($assessment->assessor_action == 'Accept')
                                        <div class="text-center">
                                            {{-- <a href="{{ route('sendorgforacceptance',[$org->id]) }}" class="btn btn-primary btn-sm">Send to ORG for Acceptance</a> --}}
                                            <a href="#" class="btn btn-primary btn-sm">Send to ORG for Acceptance</a>
                                        </div>
                                        @else
                                        <div class="text-center">
                                            <h5 class="text-danger">* Reject from assessor Side</h5>
                                        </div>
                                    @endif
                                    @endif
                                @if ($status->stage == '2D')
                                    {{-- @if ($assessment->cb_action == 'Accept') --}}
                                        <div class="text-center">
                                            {{-- <a href="{{ route('send.confirmation',[$org->id]) }}" class="btn btn-primary btn-sm">Send Confirmation to start Assessment</a> --}}
                                            {{-- <a href="#" class="btn btn-primary btn-sm">Assessment Start</a> --}}
                                        </div>
                                    {{-- @endif --}}
                                @endif                                
                            </div>
                        </div>
                    </div>
                    
                    @endif
                    {{-- @if ($status->stage == '2C' )

                    <div class="text-center">
                        <h5 class="text-danger">* Reject from assessor Side</h5>
                    </div>
                    @endif --}}
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function() {
            $('#to_date').on('change', function() {
                
            var start_date = $('#from_date').val();
            var end_date = $('#to_date').val();
            // alert(end_date)
            if(end_date <= start_date){
                alert("Please ensure that the End Date is greater than or equal to the Start Date.");
               document.getElementById("to_date").value = ' ';
            }
            });
        });
</script>
{{-- <script language="javascript">
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0');
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;
    $('#from_date').attr('min',today);
    $('#to_date').attr('min',today);
</script> --}}
@endsection
