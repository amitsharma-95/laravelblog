@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Alloted Application</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Alloted Applications</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <h5 class="card-header text-center">
                            <b>Scrutiny Completed Assessor Allotment</b>
                            {{-- <a href="{{ route('allotedassessor') }}" class="btn btn-success float-right has-ripple"><i class="feather mr-2 icon-check-circle"></i> Allotted</a>
                                    <a href="{{ route('not.allotedassessor') }}" class="btn btn-warning float-right has-ripple mr-1"><i class="feather mr-2 icon-alert-triangle"></i> Not Allotted</a>
                                    <a href="{{ route('assessmentinprocess') }}" class="btn btn-primary float-right has-ripple mr-1"><i class="feather mr-2 icon-check-circle"></i> In Process</a> --}}
                        </h5>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-4"></div>
                                <div class="col-sm-4"></div>
                                <div class="col-sm-4">
                                    <div class="form-group fill text-right">
                                        <label for="Email"
                                            style="top: -10px;
                                        font-size: 16px;
                                        font-weight: 600;
                                        color: #263e76;">Filter
                                            By: &nbsp;</label>
                                        <select name="filter" id="filter">
                                            <option value="">Alloted Applications</option>
                                            <option value="Allotted">Allotted</option>
                                            <option value="Not Allotted">Not Allotted</option>
                                            <option value="In Process">In Process</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="dt-responsive table-responsive">
                                    <table id="example"  class="table nowrap table-striped table-bordered"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%">S.No.</th>
                                                <th style="width: 8%">Username</th>
                                                <th style="width: 12%">App No.</th>
                                                <th style="width: 15%">Org Name</th>
                                                <th style="width: 36%">Scheme</th>
                                                <th style="width: 18%">Level</th>
                                                <th style="width: 8%">Preview</th>
                                                <th style="width: 8%">Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Username</th>
                                                <th>App No.</th>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                {{-- <th>Assessor Name</th> --}}
                                                <th>Preview</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        @php
                                            $i=1;
                                        @endphp
                                        @foreach ($allotments as $allotment)
                                                @php
                                                    if (!$allotment == null) {
                                                            $applications = \App\ApplicationStatus::where('id', $allotment->app_id)->where('user_id', $allotment->org_id)->where('isDeleted',0)->get();
                                                        } else {
                                                            $applications = [];
                                                        } 
                                                @endphp
                                            @foreach ($applications as $item)
                                            @php
                                                $loginAssessor = Session('userRole');
                                                $applicant = \App\User::where('id',$item->user_id)->first() ;
                                                // $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                                // $alloted_to = \App\AppUserAllotment::where('org_id', $item->id)->where('isActive',0)->first();
                                                $alloted_user = \App\AdminUser::where('id', $loginAssessor->alloted_to)->first();
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                                $assessment = \App\AppAssessment::where('app_id',$item->id)->where('org_id',$item->user_id)->Where('assessor_id',$loginAssessor->id)->where('isActive',0)->first() ;
                                                $checkStage = array('2','2B','2D');
                                            @endphp
                                                <tr>
                                                    <td>{{ $i }}</td>
                                                    <td><div class="handsontable">{{ $applicant->username }}</td>
                                                    <td><div class="handsontable">{{ $item->application_no }}</td>
                                                    <td><div class="handsontable">{{ $applicant->org_name }}</td>
                                                    <td><div class="handsontable">{{ $scheme->scheme_name }}</td>
                                                    <td><div class="handsontable">{{ $item->level }}</td>
                                                    {{-- <td>{{ @$alloted_user->name }}</td> --}}
                                                    <td><a class="text-success handsontable" href="{{ route('application.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td>
                                                        <div class="handsontable">
                                                        @if ($item->stage == '2' )
                                                        <span class="badge badge-light-warning handsontable">Allot Assessor</span>
                                                        {{-- <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a> --}}
                                                        @elseif ($item->stage == '2A' )
                                                        <span class="badge badge-light-success handsontable">Assessor Alloted</span>
                                                        @elseif ($item->stage == '2B' )
                                                        <span class=" handsontable badge badge-light-primary">
                                                           Sent to ORG for Acceptance</span>
                                                           @elseif ($item->stage == '2D')
                                                        <span class="handsontable badge badge-light-primary">
                                                           Reject from ORG Side</span>
                                                        {{-- <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a> --}}
                                                        @elseif ($item->stage == '2C')
                                                        <span class="handsontable badge badge-light-primary">
                                                           Reject from Assessor Side</span>
                                                        <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        {{-- @elseif ($item->stage == '2C' )
                                                        <span class="badge badge-light-primary handsontable">Sent to ORG for Acceptance</span> --}}
                                                        @elseif ($item->stage == '2D' )
                                                        <span class="handsontable badge badge-light-{{ $assessment->cb_action=='reject'?'danger':'primary' }}">{{ $assessment->cb_action }} from ORG Side</span>
                                                        {{-- <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a> --}}
                                                        @elseif ($item->stage == '2E' )
                                                        <span class="badge badge-light-primary handsontable">Assessment Start</span>
                                                        @elseif ($item->stage == '2F' )
                                                        <span class="badge badge-light-primary handsontable">NC Sent to ORG</span>
                                                       
                                                        @elseif ($item->stage == '2G' )
                                                        <span class="badge badge-light-primary handsontable">Reply sent to Assessor</span>
                                                        @elseif ($item->stage == '3' )
                                                        <span class="badge badge-light-success handsontable">Assessment Completed</span>
                                                        @elseif ($item->stage == '4' )
                                                        <span class="badge badge-light-success handsontable">Application Closed</span>
                                                        <a href="{{ route('ncreplies', [$item->id]) }}"  data-toggle="tooltip" data-placement="top" data-original-title="Assessment & Replies"
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        <a href="{{ route('clerification', [$item->id]) }}" data-toggle="tooltip" data-placement="top" data-original-title="Clerification"
                                                                class="btn btn-icon btn-warning edit allotmentUser">
                                                                <i class="fas fa-file-signature"></i> </a>
                                                        @else
                                                        <span class="badge badge-light-success handsontable">Assessment Completed</span>
                                                        {{-- <a href="{{ route('ncreplies', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a> --}}
                                                        @endif
                                                        @if (in_array($item->stage, $checkStage))
                                                       <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                        class="btn btn-icon btn-warning edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($item->stage == '2F' || $item->stage == '2G')
                                                        <a href="{{ route('ncreplies', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($item->stage == '3')
                                                        <a href="{{ route('closure',[$item->id]) }}" 
                                                            class="btn btn-icon btn-warning">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        @else
                                                       @endif
                                                    </div>
                                                    {{-- <div class="overlay-edit"> --}}
                                                        
                                                       {{-- @if (in_array($application->stage, $checkStage))
                                                       <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                        class="btn btn-icon btn-warning edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($application->stage == '2F' || $application->stage == '2G')
                                                        <a href="{{ route('ncreplies', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        @else
                                                       @endif --}}

                                                    {{-- </div> --}}
                                                </td>
                                                </tr>
                                                @php
                                                    $i++;
                                                @endphp
                                            @endforeach
                                            @endforeach
                                        {{-- <tbody>
                                            @foreach ($applicants as $item)
                                            @php
                                                $application = \App\ApplicationStatus::where('user_id',$item->id)->first();
                                                $allotment = \App\AppUserAllotment::where('user_id_of_allotment',$item->id)->where('type', 'Assessor')->first() ;
                                                if ($allotment != null) {
                                                    $assessor = \App\AdminUser::where('id',$allotment->alloted_to)->first() ;
                                                }
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                                
                                            @endphp
                                                <tr>
                                                    <td>{{ $item->org_name }}</td>
                                                    <td>{{ $scheme->scheme_name }}</td>
                                                    <td>{{ $item->level }}</td>
                                                    <td>{{ $item->username }}</td>
                                                    <td>{{ @$assessor->name }}</td>
                                                    <td><a class="text-success" href="{{ route('application.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td>
                                                       @if ($application->stage == '2' )
                                                        <span class="badge badge-light-primary">Allot Assessor</span>
                                                        @elseif ($application->stage == '2A' )
                                                        <span class="badge badge-light-success">Assessor Alloted</span>
                                                        @elseif ($application->stage == '1B' )
                                                        <span class="badge badge-light-success">Again for Scrutiny</span>
                                                        @elseif ($application->stage == '2' )
                                                        <span class="badge badge-light-success">Scrutiny Close</span>
                                                        @endif
                                                    <div class="overlay-edit">
                                                        
                                                       @if ($application->stage == '2' )
                                                       <a href="{{ route('allot.assessor', [$item->id]) }}" 
                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($application->stage == '1C')
                                                        <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                       @endif
                                                        
                                                    </div>
                                                </td>
                                                </tr>
                                            @endforeach
                                        </tbody> --}}
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });
        });

        $('#filter').change(function() {
            var $option = $(this).find('option:selected');
            var value = $option.val();
            if (value == "Allotted") {
                window.location.href="{{ route('allotedassessor') }}";
            } else if (value == "Not Allotted") {
                window.location.href="{{ route('not.allotedassessor') }}";
            } else if (value == "In Process") {
                window.location.href="{{ route('assessmentinprocess') }}";
            }
        });
    </script>
@endsection
