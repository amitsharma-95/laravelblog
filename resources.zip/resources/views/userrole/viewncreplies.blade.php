@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Assessment</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Assessment </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center py-3" style="border-top: 4px solid #ffa900;">
                            <b>NC Reports</b>
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm"><i
                                    class="fa fa-arrow-left"></i> Go Back</a>
                        </div>
                        <div class="card-body table-border-style">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>NC For</th>
                                            <th>NC Type</th>
                                            <th>NC Topic</th>
                                            <th>Last Reply</th>
                                            <th>Reply By</th>
                                            <th>Date</th>
                                            <th>View</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($all_ncs as $nc)
                                            @php
                                                $reply = \App\AppNcReply::where('nc_id',$nc->id)->orderBy('id','desc')->first();
                                            @endphp
                                            <tr>
                                                <td><div class="handsontable">{{ $nc->nc_for }}</div></td>
                                                <td><div class="handsontable">{{ $nc->type }}</div></td>
                                                <td><div class="handsontable">{{ $nc->topic }}</div></td>
                                                <td><div class="handsontable">{{ @$reply->reply }}</div></td>
                                                <td><div class="handsontable">{{ @$reply->reply_by }}</div></td>
                                                <td><div class="handsontable">{{ @$reply->created_at }}</div></td>
                                                <td>
                                                    <a href="{{ route('viewreplies',[$nc->id]) }}" class="btn btn-success handsontable"><i class="fa fa-eye"></i> replies</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center py-3" style="border-top: 4px solid #ffa900;">
                            <b>Assessment Reports</b>
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm"><i
                                    class="fa fa-arrow-left"></i> Go Back</a>
                        </div>
                        <div class="card-body table-border-style">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ORG Name</th>
                                            <th>Assessor name</th>
                                            <th>Document Name</th>
                                            <th>Document</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($assessment_reports as $assessment_report)
                                            @php
                                                $Org = \App\User::where('id',$org_id)->first();
                                                $assessor = \App\AdminUser::where('id',$allotment->alloted_to)->first();
                                            @endphp
                                            <tr>
                                                <td>{{ $Org->name }}</td>
                                                <td>{{ $assessor->name }}</td>
                                                <td>{{ $assessment_report->doc_name }}</td>
                                                <td>
                                                    <a href="{{ url('public/assets/assessments') }}/{{ $assessment_report->doc_file }}" target="_blank">view</a>
                                                </td>
                                                <td>{{ $assessment_report->created_at }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection