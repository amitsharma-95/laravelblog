@extends('layouts.adminuser')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Replies</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Applications Replies</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            @php
                $assessment_nc = \App\AppAssessmentNC::where('id', $nc_id)->first();
            @endphp
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <h5 class="card-header justify-content-between align-items-center text-center py-3"
                            style="border-top: 4px solid #ffa900;">
                            <b>NC Topic - <span class="text-primary">{{ $assessment_nc->topic }}</span></b>
                            <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm float-right"><i
                                    class="fa fa-arrow-left"></i> Go Back</a>
                        </h5>
                        <div class="card-body">
                            <div class="row mb-5">
                                <div class="col-md-6 text-right px-5">
                                    <h5><b>NC For </b></h5>
                                    <h5><b>NC Type </b></h5>
                                    <h5><b>Findings of Assessment </b></h5>
                                </div>
                                <div class="col-md-6 text-left px-3">
                                    <h5><b><span class="text-primary">{{ $assessment_nc->nc_for }}</span></b></h5>
                                    <h5><b><span class="text-primary">{{ $assessment_nc->type }}</span></b></h5>
                                    <h5><b><span
                                                class="text-primary">{{ $assessment_nc->findings_of_assessment }}</span></b>
                                    </h5>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header justify-content-between text-center align-items-center py-3"
                                    style="border-top: 4px solid #ffa900;">
                                    <b>CB/Assessor Replies</b>
                                    {{-- <a href="{{ route('assessor.allotment') }}" class="btn btn-dark btn-sm"><i
                                            class="fa fa-arrow-left"></i> Go Back</a> --}}
                                </div>
                                <div class="card-body">
                                    @foreach ($replies as $reply)
                                        @if ($reply->reply_by == 'Applicant')
                                            <div class="d-flex flex-row justify-content-start">
                                                <img src="{{ asset('assets/img/team/org_avatar.png') }}" alt="avatar 1"
                                                    style="width: 45px; height: 100%;">
                                                <div class="p-3 me-3 border"
                                                    style="border-radius: 15px; margin-left: 10px; background-color: #f5f6f7;">
                                                    <p class="small mb-0">
                                                        {{ $reply->reply_by == 'Applicant' ? $reply->reply : '.......' }}</p>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between mb-5">
                                                <p class="small mb-1">{{ $reply->reply_by }}</p>
                                                <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                        aria-hidden="true"></i>
                                                    {{ $reply->created_at->format('d-m-y') }}</p>
                                            </div>
                                        @endif
                                        @if ($reply->reply_by == 'Assessor')
                                            <div class="d-flex flex-row justify-content-end pt-1">
                                                <div class="p-3 ms-3 mr-2"
                                                    style="border-radius: 15px; margin-right: 10px; background-color: rgba(57, 192, 237,.2);">
                                                    <p class="small mb-0">
                                                        {{ $reply->reply_by == 'Assessor' ? $reply->reply : '.......' }}
                                                    </p>
                                                </div>
                                                <img src="{{ asset('assets/img/team/assessor_avatar.png') }}" alt="avatar 1"
                                                    style="width: 45px; height: 100%;">
                                            </div>
                                            <div class="d-flex justify-content-between mb-5">
                                                <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                        aria-hidden="true"></i>
                                                    {{ $reply->updated_at->format('d-m-y') }}</p>
                                                <p class="small mb-1">Assessor</p>
                                            </div>
                                        @endif
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endsection
