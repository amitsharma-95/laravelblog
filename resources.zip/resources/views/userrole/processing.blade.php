@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Processing Alloted Application</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Processing Alloted Applications</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <h5 class="card-header text-center">
                            Processing Applications
                           <a href="{{ route('alloted.application') }}" class="btn btn-dark btn-sm float-right has-ripple"><i class="feather icon-arrow-left"></i> Back</a>
                       </h5>
                        <div class="card-body">
                            {{-- <div class="row">
                                <div class="col-md-8 offset-md-2 text-center">
                                    <a href="{{ route('pending') }}" class="btn btn-danger has-ripple"><i class="feather icon-slash"></i> Pending</a>
                                    <button class="btn btn-warning has-ripple"><i class="feather icon-info"></i> Processing</button>
                                    <button class="btn btn-success has-ripple"><i class="feather mr-2 icon-check-circle"></i> Closed</button>
                                </div>
                            </div> --}}
                            <div class="dt-responsive table-responsive">
                                    <table id="example"  class="table nowrap table-striped table-bordered"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%">S.No.</th>
                                                <th style="width: 10%">Username</th>
                                                <th style="width: 15%">Org Name</th>
                                                <th style="width: 38%">Scheme</th>
                                                <th style="width: 18%">Level</th>
                                                <th style="width: 8%">Preview</th>
                                                <th style="width: 8%">Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Username</th>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                <th>Preview</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @php
                                                $i = 1;
                                            @endphp
                                            @foreach ($allotments as $item)
                                                @php
                                                    if (!$item == null) {
                                                            $applicants = \App\ApplicationStatus::where('id', $item->app_id)->where('user_id', $item->org_id)->whereIn('stage', array('1B','1C'))->get();
                                                        } else {
                                                            $applicants = [];
                                                        } 
                                                @endphp
                                            @foreach ($applicants as $item)
                                            @php
                                                $user = \App\User::where('id',$item->user_id)->first() ;
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                            @endphp
                                                <tr>
                                                    <td>{{ $i }}</td>
                                                    <td><div class="handsontable">{{ $user->username }}</div></td>
                                                    <td><div class="handsontable">{{ $user->org_name }}</div></td>
                                                    <td><div class="handsontable">{{ $scheme->scheme_name }}</div></td>
                                                    <td><div class="handsontable">{{ $item->level }}</div></td>
                                                    <td><a class="text-success handsontable" href="{{ route('application.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td>
                                                        @if ($item->stage == '1A' )
                                                        <span class="badge badge-light-danger handsontable">start Scrutiny</span>
                                                        @elseif ($item->stage == '1B' )
                                                        <span class="badge badge-light-warning handsontable">Sent to CB for Review</span>
                                                        @elseif ($item->stage == '1C' )
                                                        <span class="badge badge-light-info handsontable">Again for Scrutiny</span>
                                                        @elseif ($item->stage == '2' )
                                                        <span class="badge badge-light-success handsontable">Scrutiny Close</span>
                                                        @else
                                                        <span class="badge badge-light-success handsontable">Scrutiny Close</span>
                                                        @endif
                                                    <div class="text-center">
                                                        
                                                       @if ($item->stage == '1A' )
                                                       <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                        class="btn btn-icon btn-warning edit allotmentUser">
                                                        <i class="fas fa-edit"></i> </a>
                                                        @elseif ($item->stage == '1C')
                                                        <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                            <i class="fas fa-edit"></i> </a>
                                                       @endif

                                                    </div>
                                                </td>
                                                </tr>
                                                @php
                                                    $i++;
                                                @endphp
                                            @endforeach
                                            @endforeach
                                            {{-- @php
                                                $application = \App\ApplicationStatus::where('user_id',$item->id)->first() ;
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                            @endphp
                                                <tr>
                                                    <td>{{ $item->org_name }}</td>
                                                    <td>{{ $scheme->scheme_name }}</td>
                                                    <td>{{ $item->level }}</td>
                                                    <td>{{ $item->username }}</td>
                                                    <td><a class="text-success" href="{{ route('application.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td>
                                                        @if ($application->stage == '1A' )
                                                        <span class="badge badge-light-success">Scrutiny</span>
                                                        @elseif ($application->stage == '1B' )
                                                        <span class="badge badge-light-success">Sent to CB</span>
                                                        @elseif ($application->stage == '1C' )
                                                        <span class="badge badge-light-success">Again for Scrutiny</span>
                                                        @elseif ($application->stage == '2' )
                                                        <span class="badge badge-light-success">Scrutiny Close</span>
                                                        @endif
                                                    <div class="overlay-edit">
                                                        
                                                       @if ($application->stage == '1A' )
                                                       <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($application->stage == '1C')
                                                        <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                       @endif

                                                    </div>
                                                </td>
                                                </tr>
                                            @endforeach --}}
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });

            //popup
            // $('body').on('click', '.allotmentUser', function() {
            //     var id = $(this).data('id');
            //     $('#userAllotmentModel').modal('show');

            // });

        });
    </script>
@endsection
