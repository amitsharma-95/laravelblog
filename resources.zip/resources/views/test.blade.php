<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{ asset('admin') }}/assets/css/style.css">
</head>

<body>

    <style type="text/css">
        body {
            font-family: "Open Sans", sans-serif;
            font-size: 14px;
            color: #000000;
            font-weight: 500;
            background: #ffffff;
            position: relative;
        }

        table {}

        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            padding: 8px 12px;
        }

    </style>


    <div class="content-wrapper" style="min-height: 323px;">

        <section class="content">
            <section class="main-section">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12 mt-5">
                            <div class="box">
                                <section style="background: #ffffff; border:1px solid rgb(180, 175, 175); padding: 5px;">
                                    <div class="container-fluid">
                                        <div class="row" style="margin-top: 10px;">
                                            <div class="col-md-1 text-center">
                                                <img id="MainContent_img"
                                                    src="https://qcin.org/public/img/QCI-Logo.png">
                                            </div>
                                            <div class="col-md-11 text-center">
                                                <h3><strong style="color: #0450d9e6;">QUALITY COUNCIL OF INDIA
                                                        (QCI)</strong></h3>
                                                <h6>2nd Floor, Institution of Engineers Building, Bahadur Shah Zafar
                                                    Marg, New Delhi – 110002</h6>
                                                <h6>Phone: +91-11-2337 8056 / 57; Fax: +91-11-2337 8678; E-mail:
                                                    ajita@qcin.org; Web: www.qcin.org</h6>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <!-- forms tart -->
                                <!-- =================================== -->
                                <div class="">
                                    <!-- <div class="form-header">
                                        <h4>Preview Report
                                        </h4> -->
                                    <div class="container-fluid mt-1 mb-1">
                                        <!-- <button onclick="getPDF()" id="downloadbtn" class="btn btn-warning" style="float: right;"><b>Download PDF</b></button><br> -->

                                    </div>
                                    <div class="canvas_div_pdf">
                                        <div class="container-fluid">
                                            <div class="row form-group mt-3">

                                                <div class="col-md-12 " style="font-size: 15px;">
                                                    <table class="" border="1" cellspacing="0"
                                                        align="Center" rules="all"
                                                        style="border-collapse:collapse;width: 100%;border: beige;">
                                                        <tr>
                                                            <th colspan="2" style="background: #11a3d4;color: #fff;">
                                                                Application Form
                                                                Details</th>
                                                        </tr>
                                                        <tr>
                                                            {{-- <th style="background: #d6d6d6;width: 50%;">
                                                                Details
                                                            </th> --}}
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align:center">
                                                                General Information
                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" style="width:50%">
                                                                Name of the Organization
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Contact Number
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Email Address
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Address of Main Office
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                State
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                City
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Pincode
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Web
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Ownership Details
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Legal Registration Status
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Registration Number
                                                            </td>
                                                            <td align="left">
                                                                <br>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Date of Registration
                                                            </td>
                                                            <td align="left">
                                                                <br>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Registration Authority
                                                            </td>
                                                            <td align="left">

                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Place of Registration
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Chief Executive Name
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Chief Executive Designation
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align: center;">Primary
                                                                Contact Person</th>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Name
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Designation
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Mobile No.
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                E-mail
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-2" border="1" cellspacing="0"
                                                        align="Center" rules="all"
                                                        style="border-collapse:collapse;width: 100%;border: beige;">
                                                        <tr>
                                                            <th style="background: #d6d6d6; text-align: center;">Address
                                                                of Branch Office/Offices</th>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <table class="" border="1" cellspacing="0"
                                                                    align="Center" rules="all"
                                                                    style="border-collapse:collapse;width: 100%;">
                                                                    <tr>
                                                                        <th>Branch Name</th>
                                                                        <th> Address of Branch Office</th>
                                                                        <th>State</th>
                                                                        <th>City</th>
                                                                        <th>Pincode</th>
                                                                        <th>Contact Person</th>
                                                                        <th>Designation</th>
                                                                        <th>Email</th>
                                                                        <th>Mobile</th>
                                                                        
                                                                    </tr>
                                                                    <tr>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                        </tr>
                                                    </table>

                                                    <table class="mt-2 text-center" border="1" cellspacing="0"
                                                        align="Center" rules="all"
                                                        style="border-collapse:collapse;width: 100%;border: beige;">
                                                        <tr>
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align: center;">Personal Information</th>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" width="50%">
                                                                Quality Manager Name
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right">
                                                                Quality Manager Designation
                                                            </td>
                                                            <td align="left">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-2" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;border: beige;">
                                                                <tr>
                                                                    <th style="background: #d6d6d6; text-align: center;"> Personnel for Voluntary Certification Scheme</th>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <table class="" border="1" cellspacing="0"
                                                                            align="Center" rules="all"
                                                                            style="border-collapse:collapse;width: 100%;">
                                                                            <tr>
                                                                                <th>Location</th>
                                                                                <th>Managerial Staff</th>
                                                                                <th>Evaluators</th>
                                                                                <th>Support Staff</th>
                                                                                <th>Technical Staff</th>
                                                                                <th>Total</th>
                                                                            </tr>
                                                                            <tr>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </tr>
                                                    </table>

                                                    <table class="mt-2 text-center" border="1" cellspacing="0"
                                                        align="Center" rules="all"
                                                        style="border-collapse:collapse;width: 100%;border: beige;">
                                                        <tr>
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align: center;">Other Information</th>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-1" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;border: beige;">
                                                                <tr>
                                                                    <th style="background: #d6d6d6; text-align: center;">1. NABCB member body accreditation</th>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <table class="" border="1" cellspacing="0"
                                                                            align="Center" rules="all"
                                                                            style="border-collapse:collapse;width: 100%;">
                                                                            <tr>
                                                                                <th>Name</th>
                                                                                <th>Certificate Number</th>
                                                                                <th>Validity Period from</th>
                                                                                <th>Validity Period to</th>
                                                                            </tr>
                                                                            <tr>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-1" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;border: beige;">
                                                                <tr>
                                                                    <th style="background: #d6d6d6; text-align: center;">2. other IAF member body accreditation</th>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <table class="" border="1" cellspacing="0"
                                                                            align="Center" rules="all"
                                                                            style="border-collapse:collapse;width: 100%;">
                                                                            <tr>
                                                                                <th>Name</th>
                                                                                <th>Certificate Number</th>
                                                                                <th>Validity Period from</th>
                                                                                <th>Validity Period to</th>
                                                                            </tr>
                                                                            <tr>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-1" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;border: beige;">
                                                                <tr>
                                                                    <th style="background: #d6d6d6; text-align: center;">3. Other Approval(s) from Govt. or Regulatory Bodies</th>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <table class="" border="1" cellspacing="0"
                                                                            align="Center" rules="all"
                                                                            style="border-collapse:collapse;width: 100%;">
                                                                            <tr>
                                                                                <th>Name</th>
                                                                                <th>Certificate Number</th>
                                                                                <th>Validity Period from</th>
                                                                                <th>Validity Period to</th>
                                                                            </tr>
                                                                            <tr>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </tr>
                                                        <tr>
                                                            <table class="text-center mt-1" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;border: beige;">
                                                                <tr>
                                                                    <th colspan="2" style="background: #d6d6d6; text-align: center;">4. Other Other activities</th>
                                                                </tr>
                                                                <tr>
                                                                    <td align="right" style="width:50%">
                                                                        Other activities within the same legal entity
                                                                    </td>
                                                                    <td align="left">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="right" style="width:50%">
                                                                        Related Organization(s), if any, and their activities
                                                                    </td>
                                                                    <td align="left">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="right" style="width:50%">
                                                                        Major Clients
                                                                    </td>
                                                                    <td align="left">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="right" style="width:50%">
                                                                        No. of Certificates issued for applied scope
                                                                    </td>
                                                                    <td align="left">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="right" style="width:50%">
                                                                        Total No. of Certificates issued
                                                                    </td>
                                                                    <td align="left">
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </tr>
                                                    </table>

                                                    <table class="mt-2 text-center" border="1" cellspacing="0"
                                                        align="Center" rules="all"
                                                        style="border-collapse:collapse;width: 100%;border: beige;">
                                                        <tr>
                                                            <th colspan="2"
                                                                style="background: #d6d6d6; text-align: center;">Financial Performance</th>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <table class="" border="1" cellspacing="0"
                                                                    align="Center" rules="all"
                                                                    style="border-collapse:collapse;width: 100%;">
                                                                    <tr>
                                                                        <th>Financial Year</th>
                                                                        <th>Total Income</th>
                                                                        <th>Income from certification</th>
                                                                        <th>Net Profit</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                    <div class="row">
                                                        <!-- if data inserted from App show this one -->
                                                        <div class="col-md-12 mt-4" style="font-size: 15px;">
                                                            <table class="" border="1" cellspacing="0"
                                                                align="Center" rules="all"
                                                                style="border-collapse:collapse;width: 100%;">
                                                                <tr>
                                                                    <th colspan="3" style="background: #d6d6d6; text-align: center;">
                                                                        Annexed Information
                                                                    </th>
                                                                </tr>
                                                                <tr>
                                                                    <td>(1)</td>
                                                                    <td>
                                                                        Organization Registration Certificate & Memorandum / Articles of Association (copy only)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(2)</td>
                                                                    <td>
                                                                        Master List of Documents reference of voluntary certification scheme (with issue and/or revision status)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(3)</td>
                                                                    <td>
                                                                        Quality Manual by applicable accreditation standard i.e. ISO/IEC 17065, ISO/IEC 17021,ISO/IEC17024 etc.
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(4)</td>
                                                                    <td>
                                                                        Documentation relating to voluntary certification scheme (Procedures, Competence Criteria, Formats, Checklists etc.)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(5)</td>
                                                                    <td>
                                                                        Branch Office(s) with activities to be covered under approval (list per format in Table – A)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(6)</td>
                                                                    <td>
                                                                        List of Managerial Personnel, Auditors & Technical Experts (list as per format in Table – B)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(7)</td>
                                                                    <td>
                                                                        Other Documents (annex list)
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(8)</td>
                                                                    <td>
                                                                        Reference of any voluntary certification scheme
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>
                                                                        Any other relevant information
                                                                    </td>
                                                                    <td>
                                                                        <a href="#" class="text-success"><i class="fa fa-eye"></i> view</a> &nbsp;  &nbsp; 
                                                                        <a href="#" class="text-primary"><i class="fa fa-download"></i> download</a>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>

                                                        {{-- <div class="row">
                                                            <div class="col-md-12" style="font-size: 15px;">
                                                                <h4 style="margin: 20px 0px">We declare that,</h4>
                                                                <ol>
                                                                    <li>We agree to comply with procedure of this
                                                                        scheme, pay charges for assessment
                                                                        irrespective of the result.
                                                                    </li>
                                                                    <li>
                                                                        We agree to co-operate with the assessment
                                                                        team appointed by NABL for examination of
                                                                        all relevant documents by them and their
                                                                        visits to those parts of the laboratory that
                                                                        are part of the applied scope.
                                                                    </li>
                                                                    <li>
                                                                        We satisfy all national, regional and local
                                                                        regulatory requirements for operating a
                                                                        laboratory.
                                                                    </li>
                                                                    <li>
                                                                        We agree to comply with the terms &
                                                                        conditions mentioned in NABL 128 (Procedure
                                                                        for Quality Assurance Scheme for Basic
                                                                        Composite Medical Laboratories (Entry Level)
                                                                    </li>
                                                                    <li>
                                                                        All information provided in this application
                                                                        is true.
                                                                        Signature of Technical Head/ Laboratory
                                                                        Director
                                                                    </li>


                                                                </ol>
                                                                <div class="form-group">
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox"
                                                                        value="1" name="accept" id="accept" checked
                                                                        disabled> <label for="accept"
                                                                        style="font-weight: 900;color: green">I DR
                                                                        HARESH KOTHARI, Pathologist- Laboratory
                                                                        Director Accept the above term & conditions.
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div> --}}

                                                    </div>

                                                    <!-- second table end -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
    </div>
</body>

</html>
