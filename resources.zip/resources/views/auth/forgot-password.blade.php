@extends('layouts.main')
@section('content')
    <section id="contact" class="contact mt-2">
        <div class="container my-5" data-aos="fade-down">
          
          <div class="row">
            <div class="col-md-8 offset-md-2">
              @if (Session::has("success"))
                  <div class="alert alert-success alert-dismissible fade show">
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      {{ Session::get('success') }}
                  </div>
              @elseif (Session::has("failed"))
                  <div class="alert alert-danger alert-dismissible fade show">
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      {{ Session::get('failed') }}
                  </div>
              @endif
            </div>
            <div class="col-lg-6 offset-lg-3 mt-5 mt-lg-0 d-flex align-items-stretch">
              {{-- <form action="#" method="post" role="form" class="php-email-form"> --}}
                <form action="{{ route('forgot-password') }}" method="post" class="php-email-form" autocomplete="off">
                  @csrf
                <div class="section-title">
                    <h2>Forgot Password</h2>
                    <p></p>
                  </div>
                <div class="row">
                  <div class="col-md-8 offset-md-2">
                  {{-- <div class="form-group">
                    <label for="name">Username</label>
                    <input type="text" name="username" class="form-control" id="username" placeholder="Username">
                  </div> --}}
                  <div class="form-group">
                    <label for="email">Email-Id</label>
                    {{-- <input type="email" class="form-control" name="email" id="email" placeholder="Email Address" > --}}
                    <input type="email" name="email" class="form-control {{$errors->first('email') ? 'is-invalid' : ''}}" value="{{ old('email') }}" placeholder="Your Email">
                                    {!! $errors->first('email', '<div class="invalid-feedback">:message</div>') !!}
                  </div>
              </div>
            </div>
                <div class="text-center"><button type="submit" class="btn btn-sm">Reset Password &nbsp; <i class="bi bi-send-fill"></i></button>
                  {{-- <button type="submit" class="btn btn-sm btn-warning" style="color: antiquewhite; background-color:tomato">Reset</button></div> --}}
                <div class="row my-4">
                    <div class="col-md-6 pt-2">
                      <a href="{{ url('login') }}">Try to login again ?</a>
                    </div>
                    <div class="col-md-6">
                        <div class="text-right pt-2">
                          <a href="{{ url('register') }}" style="text-align: right;">Want to create new account? Register </a>
                        </div>
                    </div>
                </div>
              </form>
              
            </div>
  
          </div>
  
        </div>
      </section>
@endsection