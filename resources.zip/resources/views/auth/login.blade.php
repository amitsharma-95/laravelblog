@extends('layouts.main')
@section('content')
    <section id="contact" class="contact mt-2">
        <div class="container mt-2" data-aos="fade-down">
            <div class="row">
                <div class="col-lg-5 d-flex align-items-stretch">
                    <div class="info">
                        <h4 class="my-3">To apply for QCI</h4>
                        <div class="address">
                            <i class="bi bi-person-circle"></i>
                            <h4>Step-1 :</h4>
                            <p>Register with new account</p>
                        </div>

                        <div class="email">
                            <i class="bi bi-card-heading"></i>
                            <h4>Step-2:</h4>
                            <p>General Information</p>
                        </div>

                        <div class="phone">
                            <i class="bi bi-receipt-cutoff"></i>
                            <h4>Step-3:</h4>
                            <p>Other Information</p>
                        </div>
                        <div class="phone">
                            <i class="bi bi-files"></i>
                            <h4>Step-4:</h4>
                            <p>Annexed Information</p>
                        </div>
                        <div class="phone">
                            <i class="bi bi-list-check"></i>
                            <h4>Step-5:</h4>
                            <p>Declaration</p>
                        </div>

                    </div>
                </div>
                <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
                    {{-- <form action="{{ route('login') }}" method="post" role="form" class="php-email-form"> --}}
                    <form action="#" method="post" role="form" class="php-email-form">
                        @csrf
                        <div class="section-title">
                            <h2>Login</h2>
                            <p>Enter your account details to log in.</p>
                        </div>
                        @if (Session::has('success'))
                            <div class="alert alert-success alert-dismissible fade show">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                {{ Session::get('success') }}
                            </div>
                        @elseif (Session::has('failed'))
                            <div class="alert alert-danger alert-dismissible fade show">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                {{ Session::get('failed') }}
                            </div>
                        @endif
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" name="username" class="form-control" id="username"
                                        placeholder="Username" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="password" id="password"
                                        placeholder="Password" required>
                                </div>
                                <div class="form-group">
                                    {!! NoCaptcha::renderJs() !!}
                                    {!! app('captcha')->display() !!}
                                    @if ($errors->has('g-recaptcha-response'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                {{-- <div class="form-group">
                  <label for="name">Enter Captcha</label>
                  <input id="captcha" type="text" class="form-control" placeholder="Enter Captcha" name="captcha">
                </div>
                <div class="form-group">
                  <label for="name">Captcha</label>
                      <div class="captcha">
                          <span>{!! captcha_img('flat') !!}</span>
                          <button type="button" class="btn btn-refresh" style="color: #fff;
                          background-color: #3d4d6a;
                          border-color: #3d4d6a;"><i class="bi bi-arrow-repeat"></i></button>
                          </div>
                          @if ($errors->has('captcha'))
                              <span class="text-danger error">
                                  {{ $errors->first('captcha') }}
                              </span>
                          @endif
                </div> --}}
                            </div>
                        </div>
                        <div class="text-center mt-2">
                            <button type="button" id="reset" name="reset" class="btn btn-sm btn-warning"
                                style="padding: 12px 34px; border-radius: 50px; color: antiquewhite; background-color:tomato"><i
                                    class="bi bi-arrow-repeat"></i>
                                Reset</button>
                            <button type="submit" class="btn btn-sm"><i class="bi bi-box-arrow-right"></i>
                                Login</button>
                        </div>
                        <div class="row my-4">
                            <div class="col-md-6 pt-2">
                                <a href="{{ url('forgot-password') }}">Forgot Password? </a>
                            </div>
                            <div class="col-md-6">
                                <div class="text-right pt-2">
                                    <a href="{{ url('register') }}" style="text-align: right;">Want to create new account?
                                        Register </a>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>

            </div>

        </div>
    </section>
@endsection
