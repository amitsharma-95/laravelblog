@extends('layouts.main')
@section('content')
    <section id="contact" class="contact mt-2">
        <div class="container mt-2" data-aos="fade-down">
  
          <div class="row">
            <div class="col-lg-6 offset-lg-3 mt-5 mt-lg-0 d-flex align-items-stretch">
              {{-- <form action="#" method="post" role="form" class="php-email-form"> --}}
                <form action="{{ route('reset-password') }}" method="post" class="php-email-form" autocomplete="off">
                    @csrf
                    @method('PUT')
                <div class="section-title">
                    <h2>Change Password</h2>
                    <p></p>
                  </div>
                <div class="row">
                  <div class="col-md-8 offset-md-2">
                    <input type="hidden" name="username" value="{{ $username }} "/>
                  <div class="form-group">
                    <label for="name">Password</label>
                    {{-- <input type="text" name="username" class="form-control" id="username" placeholder="Username"> --}}
                    <input type="password" name="password" class="form-control {{$errors->first('password') ? 'is-invalid' : ''}}" value="{{ old('password') }}" placeholder="New Password">
                                    {!! $errors->first('password', '<div class="invalid-feedback">:message</div>') !!}
                  </div>
                  <div class="form-group">
                    <label for="email">Confirm Password</label>
                    {{-- <input type="email" class="form-control" name="email" id="email" placeholder="Email Address" > --}}
                    <input type="password" name="confirm_password" class="form-control {{$errors->first('confirm_password') ? 'is-invalid' : ''}}" value="{{ old('confirm_password') }}" placeholder="Confirm Password">
                                {!! $errors->first('confirm_password', '<div class="invalid-feedback">:message</div>') !!}
                  </div>
              </div>
            </div>
                <div class="text-center"><button type="submit" class="btn btn-sm">Change Password &nbsp; <i class="bi bi-send-fill"></i></button>
                 
              </form>
              
            </div>
  
          </div>
  
        </div>
      </section>
@endsection