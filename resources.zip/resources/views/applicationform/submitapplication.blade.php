@extends('layouts.orgdashboard')
@section('content')
    <style>
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }

        .cb_remark {
            display: none;
        }
    </style>
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Status</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Status</a></li>
                                    {{-- <li class="breadcrumb-item"><a href="#!">{{ $user->name }}</a></li> --}}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <a href="{{ route('dashboard') }}" class="btn btn-dark"><i class="fa fa-arrow-left"></i> Go Back</a>
                        <div class="card">
                            <div class="card-body">
                                <div class="dt-responsive table-responsive">
                                    <table id="example" class="table nowrap table-striped table-bordered"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center;"><div class="handsontable">Username</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Application No.</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Organization Name</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Scheme</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Level</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Contact Person</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Contact No.</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Email Id</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Preview</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Action</div></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php
                                                $scheme = \App\AppScheme::where('id', $app->scheme)->first();
                                                $application = \App\ApplicationStatus::where('id', $app->id)
                                                    ->where('user_id', $user->id)
                                                    ->first();
                                                $assessment = \App\AppAssessment::where('app_id', $app->id)
                                                    ->where('org_id', $user->id)
                                                    ->where('isActive', 0)
                                                    ->first();
                                                @$assessor = \App\AdminUser::where('id', $assessment->assessor_id)->first();
                                                $stage = ['0', '1', '1A', '1B', '1C', '2', '2A', '2B', '2C', '2D', '2E'];
                                            @endphp
                                            <tr>
                                                <td>
                                                    <div class="handsontable">{{ $user->username }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ @$application->application_no }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $user->org_name }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $scheme->scheme_name }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $application->level }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $user->name }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $user->mobile }}</div>
                                                </td>
                                                <td>
                                                    <div class="handsontable">{{ $user->email }}</div>
                                                </td>
                                                <td><a class="text-success"
                                                        href="{{ route('myapplication.preview', [$app->id]) }}"
                                                        target="_blank"><i class="fa fa-eye"></i> preview</a>
                                                    @if ($application->stage == '4')
                                                        <br /><a
                                                            href="http://paddscheme.7techies.com/certificate/index.php?id=<?php echo $app->id; ?>"
                                                            target="_blank" class="text-primary"><i class="fa fa-eye"></i>
                                                            Certificate</a>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($application->stage == '1')
                                                        <span class="handsontable badge badge-light-primary">Application
                                                            Submitted</span>
                                                    @elseif ($application->stage == '1A')
                                                        <span class="handsontable badge badge-light-primary">Dealing Officer
                                                            Alloted</span>
                                                    @elseif ($application->stage == '1C')
                                                        <span class="handsontable badge badge-light-success">Again for
                                                            Scrutiny</span>
                                                    @elseif ($application->stage == '2')
                                                        <span class="handsontable badge badge-primary">Scrutiny Close</span>
                                                    @elseif ($application->stage == '2A')
                                                        <span class="handsontable badge badge-light-success">Assessor
                                                            Alloted</span>
                                                    @elseif ($application->stage == '2B')
                                                        <span class="handsontable badge badge-light-success">Accept from
                                                            Assessor
                                                            side</span>
                                                    @elseif ($application->stage == '2C')
                                                        <span class="handsontable badge badge-light-success">Reject from
                                                            Assessor
                                                            side</span>
                                                    @elseif ($application->stage == '2D')
                                                        <span class="handsontable badge badge-light-success">Reject From
                                                            ORG</span>
                                                    @elseif ($application->stage == '2E')
                                                        <span class="handsontable badge badge-light-primary">Assessment in
                                                            Process</span>
                                                    @elseif ($application->stage == '3' || $application->stage == '4')
                                                        <a href="{{ route('reply.nc', [$application->id]) }}"
                                                            class="btn btn-primary btn-sm handsontable"><i
                                                                class="fa fa-eye"></i> View
                                                            NC</a><br />
                                                        <a href="{{ route('view.assessment', [$application->id]) }}"
                                                            class="btn btn-warning btn-sm my-2 handsontable"><i
                                                                class="fa fa-eye"></i> View
                                                            Assessment</a>
                                                    @elseif (!in_array($application->stage, $stage, true))
                                                        <a href="{{ route('reply.nc', [$application->id]) }}"
                                                            class="btn btn-primary btn-sm handsontable"><i
                                                                class="fa fa-eye"></i> View
                                                            NC</a><br />
                                                        <a href="{{ route('view.assessment', [$application->id]) }}"
                                                            class="btn btn-warning btn-sm my-2 handsontable"><i
                                                                class="fa fa-eye"></i> View
                                                            Assessment</a>
                                                    @else
                                                        <span
                                                            class="handsontable badge badge-light-success">Processing..</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                @if ($application->stage == '2B')
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5 class="text-center">Acceptance Action</h5>
                                                </div>
                                                <div class="card-body my-2">
                                                    @if (Session::has('success'))
                                                        <div class="alert alert-success">
                                                            {{ Session::get('success') }}
                                                        </div>
                                                    @endif
                                                    @error('cb_remark')
                                                        <span class="text-danger mb-5"
                                                            style="margin-bottom: 10px;">{{ $message }}</span>
                                                    @enderror
                                                    @php
                                                        $org_id = session('user_id');
                                                    @endphp
                                                    <form action="{{ route('cb.action') }}" method="POST"
                                                        id="userForm">
                                                        @csrf
                                                        <input type="hidden" name="org_id" id="org_id"
                                                            value="{{ $org_id }}">
                                                        <input type="hidden" name="app_id" id="app_id"
                                                            value="{{ $app->id }}">
                                                        <input type="hidden" name="assessor_id" id="assessor_id"
                                                            value="{{ @$assessor->id }}">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Assessor Name</label>
                                                                    <input type="text" class="form-control"
                                                                        value="{{ @$assessor->name }}" readonly />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Assessment Start From</label>
                                                                    <input type="dateTime" class="form-control"
                                                                        value="{{ @$assessment->from_date }}"
                                                                        readonly />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label>Assessment close to</label>
                                                                    <input type="dateTime" class="form-control"
                                                                        value="{{ @$assessment->to_date }}" readonly />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label for="user"
                                                                        style="color: #080d19;font-weight: 600;">Assessment
                                                                        Action <span class="text-danger">*</span></label>
                                                                    <select
                                                                        class="form-control @error('cb_action') is-invalid @enderror"
                                                                        name="cb_action" id="cb_action" required>
                                                                        <option value="">Accept/Reject</option>
                                                                        <option value="Accept">Accept</option>
                                                                        <option value="Reject">Reject</option>
                                                                    </select>
                                                                    @error('cb_action')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row cb_remark">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label for="user"
                                                                        style="color: #080d19;font-weight: 600;">Remark to
                                                                        Action <span class="text-danger">*</span></label>
                                                                    <textarea class="form-control @error('cb_remark') is-invalid @enderror" name="cb_remark" id="cb_remark"
                                                                        cols="30" rows="10" placeholder="Accept/Reject........"></textarea>
                                                                    @error('cb_remark')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row my-2">
                                                            <div class="col-md-12 text-center">
                                                                <button type="submit" name="submit"
                                                                    class="btn btn-primary" id="SaveBtn"> Save & Send to
                                                                    Officer
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
@endsection

@section('script')
    <script>
        $('#cb_action').change(function() {
            var $option = $(this).find('option:selected');
            var value = $option.val();
            if (value == 'Reject') {
                $('.cb_remark').show();
            } else {
                $('.cb_remark').hide();
            }
        });
    </script>
@endsection
