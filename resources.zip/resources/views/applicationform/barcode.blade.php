<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Barcode</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
    @php
        $app = \App\ApplicationStatus::first();
    @endphp
    <div class="container mt-4">
        <div class="mb-3">
            {{-- {!! DNS2D::getBarcodeHTML($app->application_no, 'QRCODE') !!} --}}
            @php
                echo DNS2D::getBarcodeHTML($app->application_no, 'QRCODE',3,3) ;
            @endphp
        </div>  
    </div>
</body>
</html>