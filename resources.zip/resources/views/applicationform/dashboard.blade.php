@extends('layouts.orgdashboard')
@section('content')
    <style>
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
    </style>
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Organization Dashboard</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Organization Dashboard</a></li>
                                    <li class="breadcrumb-item"><a href="#!">{{ $user->name }}</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                @if ($apps->count() != 0)
                    <div class="row">
                        <div class="col-lg-12">
                            <button type="button" class="btn  btn-primary" data-toggle="modal"
                                data-target="#createapp">Create Application</button>
                            <div class="card">
                                <div class="card-body">
                                    <div class="dt-responsive table-responsive">
                                        <table id="example" class="table nowrap table-striped table-bordered"
                                            style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th style="width:6%">S.no.</th>
                                                    {{-- <th><div class="handsontable">Application Number</div></th> --}}
                                                    <th>
                                                        <div class="handsontable">Username</div>
                                                    </th>
                                                    <th>
                                                        <div class="handsontable">Org Name</div>
                                                    </th>
                                                    <th>
                                                        <div class="handsontable">Scheme</div>
                                                    </th>
                                                    <th>
                                                        <div class="handsontable">Level</div>
                                                    </th>
                                                    <th style="width:12%">
                                                        <div class="handsontable">Created Date</div>
                                                    </th>
                                                    {{-- <th style="width:8%">Status</th> --}}
                                                    <th style="width:12%">
                                                        <div class="handsontable">Action</div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                    $i = 1;
                                                @endphp
                                                @foreach ($apps as $item)
                                                    @php
                                                        $scheme = \App\AppScheme::where('id', $item->scheme)->first();
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            <div class="handsontable">{{ $i }}</div>
                                                        </td>
                                                        {{-- <td><div class="handsontable">{{ @$item->application_no }}</div></td> --}}
                                                        <td>
                                                            <div class="handsontable">{{ $user->username }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $user->org_name }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $scheme->scheme_name }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $item->level }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $item->created_at }}</div>
                                                        </td>
                                                        {{-- <td><div class="handsontable">{{ $item->stage == '1'?'Application Submited' }}</div></td> --}}
                                                        <td>
                                                            @if ($item->stage == '0' || $item->stage == '1B')
                                                                <a href="{{ route('general.information', [$item->id]) }}"
                                                                    class="btn btn-primary btn-sm handsontable">Application
                                                                    Form</a>
                                                            @elseif ($item->stage != '0' || $item->stage != '1B')
                                                                <a href="{{ route('submitted.application', [$item->id]) }}"
                                                                    class="btn btn-primary btn-sm handsontable">Submitted
                                                                    Application</a>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    @php
                                                        $i++;
                                                    @endphp
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="row">
                        <div class="col-lg-12">
                            <button type="button" class="btn  btn-primary" data-toggle="modal"
                                data-target="#createapp">Create New Application</button>
                        </div>
                    </div>
                @endif
                <div id="createapp" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="createappLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="createappLabel">Create New Application</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                            <div class="modal-body">
                                <form action="{{ route('create.app') }}" method="POST" id="userForm">
                                    @csrf
                                    <input type="hidden" name="user_id" id="user_id" value="{{ $user->id }}" />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="confirm_password"
                                                    style="font-size: 13px;font-weight: 600;color: #263e76;">Select
                                                    Type of Scheme</label>
                                                <select class="form-control" name="scheme" id="scheme"
                                                    style="width:100%" required="">
                                                    <option selected="selected" value="">---Select Type of Scheme----
                                                    </option>
                                                    @foreach ($schemes as $item)
                                                        <option value="{{ $item->id }}">{{ $item->scheme_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="confirm_password"
                                                    style="font-size: 13px;font-weight: 600;color: #263e76;">Level</label>
                                                <select class="form-control" name="level" id="level"
                                                    style="width:100%" required="">
                                                    <option selected="selected" value="">---Level ----</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Save
                                        Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
@endsection

@section('script')
    <script>
        $('#scheme').on('change', function(e) {
            var scheme_id = e.target.value;
            console.log(scheme_id);
            $.get('/scheme-level?scheme_id=' + scheme_id,
                function(data) {
                    $('#level').html(data);
                });
        });
    </script>
@endsection
