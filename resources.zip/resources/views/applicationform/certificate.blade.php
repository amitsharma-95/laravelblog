<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/css?family=Amaranth|Courgette|Pacifico|Philosopher:700" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('certificate/style.css') }}">

</head>

<body>
    <div style="margin-top: 20px; margin-left:20px;">
        <a href="logout.php" style="color:#ffc107;">Go Back </a>
    </div>
    <div id="drConvert">
        @php
            $user = \App\User::where('id', 1)->first();
        @endphp

        <div id="drOutput">
            <?php 

$name = $user->name;

if($name==""){
  echo "<div class='dr-alert'>* All Fields are required!!!</div>";
}
else {
  ?>
            <?php
        
            // $imgsrc = '/public/certificate/mobile-photography.jpg';
            $imgsrc = 'http://paddscheme.7techies.com/public/certificate/mobile-photography.jpg';
            $createimg = imagecreatefromjpeg($imgsrc);
            // dd($createimg);
            $output = 'certificate.jpg';
            
            $black = imagecolorallocate($createimg, 180, 64, 121);
            $rotation = 0;
            $origin_x = 1650;
            $origin_y = 1420;
            $font_size = 55;
            
            $origin_x1 = 730;
            $origin_y1 = 1460;
            
            $origin_x2 = 1990;
            $origin_y2 = 1585;
            
            $origin_x3 = 795;
            $origin_y3 = 1585;
            $font_size1 = 45;
            
            $certificate_text = $name;
            //$certificate_text1 = $topic;
            //$certificate_text2 = $web_time;
            //$certificate_text3 = $topic_by;
            
            $drFont = dirname(realpath(__FILE__)) . '/public/certificate/dr-fonts/developer.ttf';
            $drFont = url('/public/certificate/dr-fonts/developer.ttf');
            // $drFont = 'public/certificate/fonts/developer.ttf';
            // dd($drFont);
            $text1 = imagettftext($createimg, $font_size, $rotation, $origin_x, $origin_y, $black, $drFont, $certificate_text);
            //$text2 = imagettftext($createimg, $font_size, $rotation, $origin_x1, $origin_y1, $black,$drFont, $certificate_text1);
            //$text3 = imagettftext($createimg, $font_size, $rotation, $origin_x2, $origin_y2, $black,$drFont, $certificate_text2);
            //$text4 = imagettftext($createimg, $font_size1, $rotation, $origin_x3, $origin_y3, $black,$drFont, $certificate_text3);
            
            // $text1 = imagettftext($createimg, $font_size, $rotation, $origin_x+2, $origin_y, $white, 'sans-serif', $text);
            imagepng($createimg, $output, 9);
            ?>
            <a href="<?php echo $output; ?>" title="Download Your Certificate" download>
                <img src="<?php echo $output; ?>" width="100%" height="auto;">
                <br> <br>

                <?php 
}

?>
        </div>

    </div>
</body>

</html>
