@extends('layouts.orgdashboard')
@section('content')
    <style>
        .new-location {
            display: none;
        }

        .addMore1 {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Form</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                            <div class="col-lg-12">
                                            {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong>Success!</strong> {{ Session('success') }}
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                            </div>
                                        </div>
                                        @endif
                                            @php
                                                $stage = \App\ApplicationStatus::where('id', $app_id)->first();
                                            @endphp

                                            @if ($stage->stage == '1B')
                                                @php
                                                    $check_Adequcy = \App\AppScrutiny::where('org_id', $stage->user_id)
                                                        ->where('app_id', $app_id)
                                                        ->where('scrutiny_for', 'GI')
                                                        ->where('isActive', 0)
                                                        ->first();
                                                    
                                                @endphp
                                                @if ($check_Adequcy->option == 'InAdequate')
                                                <div class="col-lg-12">
                                                    <div class="alert alert-danger" role="alert">
                                                        <h4 class="alert-heading"><b>Remark !</b></h4>
                                                        <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                            @endif
                                        </div>
                                        <form action="{{ url('general-information') }}" method="POST" class="row">
                                            @csrf
                                            <div class="col-lg-12">
                                                <h5 style="    background: antiquewhite; padding: 12px 10px;">
                                                    <b>1. Conformity Assessment Bodies</b>
                                                </h5>
                                            </div>
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Name of the Organization <span
                                                            class="text-danger">*</span></label>
                                                    {{-- <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name of the Organization "> --}}
                                                    <input type="text"
                                                        class="form-control @error('assessment_body_name') is-invalid @enderror"
                                                        name="assessment_body_name"
                                                        id="assessment_body_name"value="{{ $userData->org_name }}"
                                                        placeholder="Name of the Conformity Assessment Bodies" readonly>
                                                    {{-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> --}}
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    {{-- <label for="exampleInputPassword1">Password</label>
                                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"> --}}
                                                    <label for="name">Contact Number<span
                                                            class="text-danger">*</span></label>
                                                    <input type="number"
                                                        class="form-control @error('ab_mobile') is-invalid @enderror"
                                                        name="ab_mobile" id="ab_mobile" pattern="[0-9]{10}" maxlength="10"
                                                        oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                                                        min="0"
                                                        value="{{ $generalinformations ? $generalinformations->ab_mobile : '' }}"
                                                        placeholder="Contact Number" required />
                                                    @error('ab_mobile')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="name">Email Address <span
                                                        class="text-danger">*</span></label>
                                                <input type="email"
                                                    class="form-control  @error('ab_email') is-invalid @enderror"
                                                    name="ab_email" id="ab_email"
                                                    value="{{ $generalinformations ? $generalinformations->ab_email : '' }}"
                                                    placeholder="Email Address " required />
                                                @error('email')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>2. Address of
                                                        Main Office</b></h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Address of Main Office <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control  @error('main_ofc_address') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->main_ofc_address : '' }}"
                                                    name="main_ofc_address" id="main_ofc_address"
                                                    placeholder="Address of Main Office" required />
                                                @error('main_ofc_address')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">State <span class="text-danger">*</span></label>
                                                <select name="state" id="state" class="form-select form-control"
                                                    style="height: 44px;font-size: 14px;" required>
                                                    @if ($generalinformations ? $generalinformations->state : '')
                                                        <option
                                                            value="{{ $generalinformations ? $generalinformations->state : '' }}">
                                                            {{ $generalinformations ? $generalinformations->state : 'Select State' }}
                                                        </option>
                                                    @endif
                                                    <option value="">Select State</option>
                                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar
                                                        Islands
                                                    </option>
                                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                                    <option value="Assam">Assam</option>
                                                    <option value="Bihar">Bihar</option>
                                                    <option value="Chandigarh">Chandigarh</option>
                                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                                    <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli
                                                    </option>
                                                    <option value="Daman and Diu">Daman and Diu</option>
                                                    <option value="Delhi">Delhi</option>
                                                    <option value="Lakshadweep">Lakshadweep</option>
                                                    <option value="Puducherry">Puducherry</option>
                                                    <option value="Goa">Goa</option>
                                                    <option value="Gujarat">Gujarat</option>
                                                    <option value="Haryana">Haryana</option>
                                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                                    <option value="Jharkhand">Jharkhand</option>
                                                    <option value="Karnataka">Karnataka</option>
                                                    <option value="Kerala">Kerala</option>
                                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                                    <option value="Maharashtra">Maharashtra</option>
                                                    <option value="Manipur">Manipur</option>
                                                    <option value="Meghalaya">Meghalaya</option>
                                                    <option value="Mizoram">Mizoram</option>
                                                    <option value="Nagaland">Nagaland</option>
                                                    <option value="Odisha">Odisha</option>
                                                    <option value="Punjab">Punjab</option>
                                                    <option value="Rajasthan">Rajasthan</option>
                                                    <option value="Sikkim">Sikkim</option>
                                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                                    <option value="Telangana">Telangana</option>
                                                    <option value="Tripura">Tripura</option>
                                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                                    <option value="Uttarakhand">Uttarakhand</option>
                                                    <option value="West Bengal">West Bengal</option>

                                                </select>
                                                @error('state')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">City<span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('city') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->city : '' }}"
                                                    name="city" id="city" placeholder="City" required />
                                                @error('city')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Pincode <span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control  @error('pin') is-invalid @enderror"
                                                    min="6"
                                                                maxlength="6"
                                                                onkeypress="return /[0-9]/i.test(event.key)"
                                                    value="{{ $generalinformations ? $generalinformations->pin : '' }}"
                                                     name="pin" id="pin" placeholder="Pincode"
                                                    required />
                                                @error('pin')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Website (optional)</label>
                                                <input type="text" class="form-control"
                                                    value="{{ $generalinformations ? $generalinformations->web : '' }}"
                                                    name="web" id="web" placeholder="Web" />
                                            </div>
                                            <div class="form-group col-md-12">
                                                <h5
                                                    style="    background: antiquewhite;
                                                                                                    padding: 12px 10px;">
                                                    <b>3.
                                                        Ownership
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label class="control-label col-sm-4" for="details">Ownership
                                                    Details<span class="text-danger">*</span></label>
                                                <div class="col-sm-6 offset-col-1">
                                                    <input type="text"
                                                        class="form-control  @error('owneship_detail') is-invalid @enderror"
                                                        value="{{ $generalinformations ? $generalinformations->owneship_detail : '' }}"
                                                        name="owneship_detail" id="owneship_detail"
                                                        placeholder="Ownership Details" required />
                                                    @error('owneship_detail')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-12">
                                                <h5
                                                    style="    background: antiquewhite;
                                                                                                    padding: 12px 10px;">
                                                    <b>4.
                                                        Legal
                                                        Registration
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Status <span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control  @error('status') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->status : '' }}"
                                                    name="status" id="status" placeholder="Status" required />
                                                @error('status')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Registration No. <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('reg_no') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_no : '' }}"
                                                    name="reg_no" id="reg_no" placeholder="Registration  No."
                                                    required />
                                                @error('reg_no')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Date of Registration <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('reg_date') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_date : '' }}"
                                                    name="reg_date" id="reg_date" placeholder="Date of Registration "
                                                    onfocus="(this.type='date')" required />
                                                @error('reg_date')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Registration Authority <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('reg_authority') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_authority : '' }}"
                                                    name="reg_authority" id="reg_authority"
                                                    placeholder="Registration  Authority" required />
                                                @error('reg_authority')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Authority ">Place of Registration <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('reg_place') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_place : '' }}"
                                                    id="reg_place" name="reg_place" placeholder="Place of Registration "
                                                    required>
                                                @error('reg_place')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-lg-12">
                                                <h5
                                                    style="    background: antiquewhite;
                                                                                                    padding: 12px 10px;">
                                                    <b>5.
                                                        Chief
                                                        Executive
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Name ">Chief Executive Name
                                                    <span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('chief_name') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->chief_name : '' }}"
                                                    id="chief_name" name="chief_name" placeholder="Chief Executive Name"
                                                    required>
                                                @error('chief_name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Designation ">Chief Executive Designation
                                                    <span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('chief_designation') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->chief_designation : '' }}"
                                                    id="chief_designation" name="chief_designation"
                                                    placeholder="Chief Executive Designation" required>
                                                @error('chief_designation')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-lg-12">
                                                <h5 style="    background: antiquewhite;padding: 12px 10px;"><b>6.
                                                        Primary
                                                        Contact
                                                        Person
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Name ">Name
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control "
                                                    value="{{ $userData->name }}" id="name" name="name"
                                                    readonly />
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Designation "> Designation
                                                    <span class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('p_designation') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->p_designation : '' }}"
                                                    id="p_designation" name="p_designation" placeholder="Designation"
                                                    required>
                                                @error('p_designation')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Phone ">Phone</label>
                                                <input type="text"
                                                    class="form-control @error('p_phone') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->p_phone : '' }}"
                                                    id="p_phone" name="p_phone" placeholder="Phone">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Phone ">Mobile
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="mobile"
                                                    value="{{ $userData->mobile }}" id="mobile" name="mobile"
                                                    readonly />
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="email">Primary Contact Person E-mail
                                                    <span class="text-danger">*</span></label>
                                                <input type="email" class="form-control "
                                                    value="{{ $userData->email }}" id="email" name="email"
                                                    readonly />
                                            </div>
                                            <div class="form-group col-md-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>7. Address of
                                                        Branch Office (if any ?) &nbsp; &nbsp; &nbsp;</b>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input option" type="radio"
                                                            name="option" id="option" value="yes"
                                                            @if (@$generalinformations->option == 'yes') {{ 'checked' }} @endif
                                                            style="height: 15px; border-radious:50%;" />
                                                        <label class="form-check-label" for="inlineRadio1">Yes</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input option" type="radio"
                                                            name="option" id="option" value="no"
                                                            @if (@$generalinformations->option == 'yes') {{ 'disabled' }} @else {{ 'checked' }} @endif
                                                            style="height: 15px; border-radious:50%;" />
                                                        <label class="form-check-label" for="inlineRadio2">No</label>
                                                    </div>
                                                </h5>
                                            </div>
                                            <div class="addMore col-lg-12">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="text-right my-4 mb-3">
                                                            <div class="float-right px-5">
                                                                <a href="javascript:void(0)" class="pull-right addRow">
                                                                    <i class="fa fa-2x fa-plus-circle"
                                                                        aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {{-- <input type="hidden" value="1" name="totalRows" id="totalRows"> --}}
                                                    @php
                                                        $i = 1;
                                                    @endphp
                                                    @if ($branch_addressess->count() > 0)
                                                        @foreach ($branch_addressess as $item)
                                                            <div class="{{ $i > 1 ? 'remove' : '' }}">
                                                                <div class="row mx-2">
                                                                    <input type="hidden" name="branch_id[]"
                                                                        value="{{ $item->id }}" />
                                                                    <div class="form-group col-md-4">
                                                                        <label for="Name ">Branch Name
                                                                            <span class="text-danger">*</span></label>
                                                                        <input type="text" class="form-control "
                                                                            value="{{ $item ? $item->branch_name : '' }}"
                                                                            id="branch_name" name="branch_name[]"
                                                                            placeholder="Branch Name" required>
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="name">Branch Office Address <span
                                                                                class="text-danger">*</span></label>
                                                                        <input type="text" class="form-control"
                                                                            name="branch_address[]" id="branch_address[]"
                                                                            value="{{ $item->branch_address ? $item->branch_address : '' }}"
                                                                            placeholder="Address of Branch Office"
                                                                            required />
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="name">State <span
                                                                                class="text-danger">*</span></label>
                                                                        <select name="branch_state[]" id="branch_state[]"
                                                                            class="form-select form-control"
                                                                            style="height: 44px;font-size: 14px;" required>
                                                                            @if ($item->branch_state ? $item->branch_state : '')
                                                                                <option
                                                                                    value="{{ $item->branch_state ? $item->branch_state : '' }}">
                                                                                    {{ $item->branch_state ? $item->branch_state : '' }}
                                                                                </option>
                                                                            @endif
                                                                            <option value="">---- Select state ----
                                                                            </option>
                                                                            <option value="Andhra Pradesh">Andhra Pradesh
                                                                            </option>
                                                                            <option value="Andaman and Nicobar Islands">
                                                                                Andaman and
                                                                                Nicobar
                                                                                Islands
                                                                            </option>
                                                                            <option value="Arunachal Pradesh">Arunachal
                                                                                Pradesh
                                                                            </option>
                                                                            <option value="Assam">Assam</option>
                                                                            <option value="Bihar">Bihar</option>
                                                                            <option value="Chandigarh">Chandigarh</option>
                                                                            <option value="Chhattisgarh">Chhattisgarh
                                                                            </option>
                                                                            <option value="Dadar and Nagar Haveli">Dadar
                                                                                and Nagar
                                                                                Haveli
                                                                            </option>
                                                                            <option value="Daman and Diu">Daman and Diu
                                                                            </option>
                                                                            <option value="Delhi">Delhi</option>
                                                                            <option value="Lakshadweep">Lakshadweep
                                                                            </option>
                                                                            <option value="Puducherry">Puducherry</option>
                                                                            <option value="Goa">Goa</option>
                                                                            <option value="Gujarat">Gujarat</option>
                                                                            <option value="Haryana">Haryana</option>
                                                                            <option value="Himachal Pradesh">Himachal
                                                                                Pradesh
                                                                            </option>
                                                                            <option value="Jammu and Kashmir">Jammu and
                                                                                Kashmir
                                                                            </option>
                                                                            <option value="Jharkhand">Jharkhand</option>
                                                                            <option value="Karnataka">Karnataka</option>
                                                                            <option value="Kerala">Kerala</option>
                                                                            <option value="Madhya Pradesh">Madhya Pradesh
                                                                            </option>
                                                                            <option value="Maharashtra">Maharashtra
                                                                            </option>
                                                                            <option value="Manipur">Manipur</option>
                                                                            <option value="Meghalaya">Meghalaya</option>
                                                                            <option value="Mizoram">Mizoram</option>
                                                                            <option value="Nagaland">Nagaland</option>
                                                                            <option value="Odisha">Odisha</option>
                                                                            <option value="Punjab">Punjab</option>
                                                                            <option value="Rajasthan">Rajasthan</option>
                                                                            <option value="Sikkim">Sikkim</option>
                                                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                                                            <option value="Telangana">Telangana</option>
                                                                            <option value="Tripura">Tripura</option>
                                                                            <option value="Uttar Pradesh">Uttar Pradesh
                                                                            </option>
                                                                            <option value="Uttarakhand">Uttarakhand
                                                                            </option>
                                                                            <option value="West Bengal">West Bengal
                                                                            </option>

                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="name">City<span
                                                                                class="text-danger">*</span></label>
                                                                        <input type="text" class="form-control"
                                                                            name="branch_city[]" id="branch_city[]"
                                                                            value="{{ $item->branch_city ? $item->branch_city : '' }}"
                                                                            placeholder="City" required />
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="name">Pincode <span
                                                                                class="text-danger">*</span></label>
                                                                        <input type="text" min="0"
                                                                            class="form-control"
                                                                            onChange="return branch_pinValidation()"
                                                                            name="branch_pin[]" id="branch_pin[]"
                                                                            value="{{ $item->branch_pin ? $item->branch_pin : '' }}"
                                                                            placeholder="Pincode" min="6" required
                                                                            maxlength="6"
                                                                            onkeypress="return /[0-9]/i.test(event.key)" />
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="Name ">Contact Person Name
                                                                            <span class="text-danger">*</span></label>
                                                                        <input type="text" class="form-control "
                                                                            value="{{ $item->branch_p_name ? $item->branch_p_name : '' }}"
                                                                            id="branch_p_name" name="branch_p_name[]"
                                                                            placeholder="Contact Person Name">
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="Designation ">Contact Person
                                                                            Designation
                                                                            <span class="text-danger">*</span></label>
                                                                        <input type="text" class="form-control "
                                                                            value="{{ $item->branch_p_designation ? $item->branch_p_designation : '' }}"
                                                                            id="branch_p_designation"
                                                                            name="branch_p_designation[]"
                                                                            placeholder="Designation">
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="Phone ">Contact Person Mobile
                                                                            <span class="text-danger">*</span></label>
                                                                        <input type="text"
                                                                            class="form-control branch_p_mobile"
                                                                            value="{{ $item->branch_p_mobile ? $item->branch_p_mobile : '' }}"
                                                                            id="branch_p_mobile" name="branch_p_mobile[]"
                                                                            placeholder="Mobile" required min="10"
                                                                            maxlength="10"
                                                                            onkeypress="return /[0-9]/i.test(event.key)" />
                                                                    </div>
                                                                    <div class="form-group col-md-4">
                                                                        <label for="E-mail">Contact Person E-mail
                                                                            <span class="text-danger">*</span></label>
                                                                        <input type="email" class="form-control "
                                                                            value="{{ $item->branch_p_email ? $item->branch_p_email : '' }}"
                                                                            id="branch_p_email" name="branch_p_email[]"
                                                                            placeholder="E-mail Address" required>
                                                                    </div>
                                                                    <div class="text-right col-lg-12 mt-2">
                                                                        <div class="float-right px-5">
                                                                            <a onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                                href="{{ url('delete/branch/' . $item->id) }}"
                                                                                class='pull-right deleteRow'><i
                                                                                    class="fa fa-2x fa-times text-danger"></i></a>
                                                                        </div>
                                                                    </div>
                                                                    @php
                                                                        $i++;
                                                                    @endphp
                                                                </div>
                                                            </div>
                                                            </div>
                                                            <hr />
                                                        @endforeach
                                                    @else
                                                        <input type="hidden" name="branch_id[]" />
                                                        <div class="form-group col-md-4">
                                                            <label for="Name ">Branch Name
                                                                <span class="text-danger">*</span></label>
                                                            <input type="text"
                                                                class="form-control @error('branch_name') is-invalid @enderror"
                                                                id="branch_name" name="branch_name[]"
                                                                placeholder="Branch Name" onchange="">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="name">Branch Office Address <span
                                                                    class="text-danger">*</span></label>
                                                            <input type="text" class="form-control"
                                                                name="branch_address[]" id="branch_address[]"
                                                                placeholder="Address of Branch Office" />
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="name">State <span
                                                                    class="text-danger">*</span></label>
                                                            <select name="branch_state[]" id="branch_state[]"
                                                                class="form-select form-control"
                                                                style="height: 44px;font-size: 14px;">
                                                                <option value="">Select State</option>
                                                                <option value="Andhra Pradesh">Andhra Pradesh</option>
                                                                <option value="Andaman and Nicobar Islands">Andaman and
                                                                    Nicobar
                                                                    Islands
                                                                </option>
                                                                <option value="Arunachal Pradesh">Arunachal Pradesh
                                                                </option>
                                                                <option value="Assam">Assam</option>
                                                                <option value="Bihar">Bihar</option>
                                                                <option value="Chandigarh">Chandigarh</option>
                                                                <option value="Chhattisgarh">Chhattisgarh</option>
                                                                <option value="Dadar and Nagar Haveli">Dadar and Nagar
                                                                    Haveli
                                                                </option>
                                                                <option value="Daman and Diu">Daman and Diu</option>
                                                                <option value="Delhi">Delhi</option>
                                                                <option value="Lakshadweep">Lakshadweep</option>
                                                                <option value="Puducherry">Puducherry</option>
                                                                <option value="Goa">Goa</option>
                                                                <option value="Gujarat">Gujarat</option>
                                                                <option value="Haryana">Haryana</option>
                                                                <option value="Himachal Pradesh">Himachal Pradesh
                                                                </option>
                                                                <option value="Jammu and Kashmir">Jammu and Kashmir
                                                                </option>
                                                                <option value="Jharkhand">Jharkhand</option>
                                                                <option value="Karnataka">Karnataka</option>
                                                                <option value="Kerala">Kerala</option>
                                                                <option value="Madhya Pradesh">Madhya Pradesh</option>
                                                                <option value="Maharashtra">Maharashtra</option>
                                                                <option value="Manipur">Manipur</option>
                                                                <option value="Meghalaya">Meghalaya</option>
                                                                <option value="Mizoram">Mizoram</option>
                                                                <option value="Nagaland">Nagaland</option>
                                                                <option value="Odisha">Odisha</option>
                                                                <option value="Punjab">Punjab</option>
                                                                <option value="Rajasthan">Rajasthan</option>
                                                                <option value="Sikkim">Sikkim</option>
                                                                <option value="Tamil Nadu">Tamil Nadu</option>
                                                                <option value="Telangana">Telangana</option>
                                                                <option value="Tripura">Tripura</option>
                                                                <option value="Uttar Pradesh">Uttar Pradesh</option>
                                                                <option value="Uttarakhand">Uttarakhand</option>
                                                                <option value="West Bengal">West Bengal</option>

                                                            </select>
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="name">City<span
                                                                    class="text-danger">*</span></label>
                                                            <input type="text" class="form-control"
                                                                name="branch_city[]" id="branch_city[]"
                                                                placeholder="City" />
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="name">Pincode <span
                                                                    class="text-danger">*</span></label>
                                                            <input type="text" class="form-control pin"
                                                                name="branch_pin[]" id="branch_pin" placeholder="Pincode"
                                                                onChange="return branch_pinValidation()" min="6"
                                                                maxlength="6"
                                                                onkeypress="return /[0-9]/i.test(event.key)" />
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="Name ">Contact Person Name
                                                                <span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control "
                                                                id="branch_p_name" name="branch_p_name[]"
                                                                placeholder="Contact Person Name">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="Designation ">Contact Person Designation
                                                                <span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control "
                                                                id="branch_p_designation" name="branch_p_designation[]"
                                                                placeholder="Designation">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="Phone ">Contact Person Mobile
                                                                <span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control branch_p_mobile"
                                                                id="branch_p_mobile" name="branch_p_mobile[]"
                                                                min="10" maxlength="10"
                                                                onkeypress="return /[0-9]/i.test(event.key)"
                                                                placeholder="Mobile">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            <label for="E-mail">Contact Person E-mail
                                                                <span class="text-danger">*</span></label>
                                                            <input type="email" class="form-control "
                                                                id="branch_p_email" name="branch_p_email[]"
                                                                placeholder="E-mail Address">
                                                            @error('branch_p_email')
                                                                <div class="text-danger">{{ $message }}</div>
                                                            @enderror
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                            {{-- <div class="col-md-4">
                                            <div class="form-group form-check">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                            </div>
                                        </div> --}}
                                            {{-- <button type="submit" class="btn  btn-primary">Submit</button> --}}
                                            <div class="col-lg-12 my-4">
                                                <div class="text-center">
                                                    <button type="submit" name="save_changes" id="save_changes"
                                                        class="btn btn-primary"><i class="bi bi-save2"></i> Save
                                                        Changes</button>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 pt-4">
                                                    <p><i class="bi bi-chevron-double-right"></i> <span
                                                            class="text-danger">*</span>
                                                        Asterisks(*) Fields are mandatory .
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="profile" role="tabpanel"
                                        aria-labelledby="profile-tab">
                                        <p class="mb-0">Food truck fixie locavore, accusamus mcsweeney's marfa nulla
                                            single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR
                                            leggings next level wes anderson artisan four
                                            loko
                                            farm-to-table
                                            craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk
                                            aliquip jean shorts ullamco ad vinyl cillum PBR. accusamus tattooed echo park.
                                        </p>
                                    </div>
                                    <div class="tab-pane fade" id="contact" role="tabpanel"
                                        aria-labelledby="contact-tab">
                                        <p class="mb-0">Etsy mixtape wayfarers, ethical wes anderson tofu before they
                                            sold out mcsweeney's organic lomo retro fanny pack lo-fi farm-to-table
                                            readymade. Messenger bag gentrify pitchfork tattooed
                                            craft beer,
                                            iphone skateboard locavore carles etsy salvia banksy hoodie helvetica. DIY synth
                                            PBR banksy irony. Lnyl craft beer blog stumptown. Pitchfork sustainable tofu
                                            synth chambray yr.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection





@section('script')
    <script>
        window.onload = function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'yes') {
                $(".addMore").show();
            } else {
                $(".addMore").hide();
            }
        };

        $(".option").click(function() {
            var val = $(".option:checked").val();
            console.log(val);
            if (val == 'yes') {
                $(".addMore").show();
            } else {
                $(".addMore").hide();
            }
        });

        $('.addMore').on('click', '.addRow', function() {
            var totalRows = $('#totalRows').val();
            var add = "<hr/>" +
                "<div class='remove'>" +
                "<div class='row'>" +
                "<input type='hidden' class='form-control' name='branch_id[]' value='0'  />" +
                "<div class='form-group col-md-4'>" +
                "<label for='address'>Branch Name <span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_name[]' id='branch_name' placeholder='Branch Name' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='address'>Branch Office Address <span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_address[]' id='branch_address[]' placeholder='Address of Branch Office' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='state'>State <span class='text-danger'>*</span></label>" +
                "<select name='branch_state[]' id='branch_state[]' class='form-select form-control' style='height: 44px;font-size: 14px;' required>" +
                "<option value=''>Select State</option>" +
                "<option value='Andhra Pradesh'>Andhra Pradesh</option>" +
                "<option value='Andaman and Nicobar Islands'>Andaman and Nicobar Islands</option>" +
                "<option value='Arunachal Pradesh'>Arunachal Pradesh</option>" +
                "<option value='Assam'>Assam</option>" +
                "<option value='Bihar'>Bihar</option>" +
                "<option value='Chandigarh'>Chandigarh</option>" +
                "<option value='Chhattisgarh'>Chhattisgarh</option>" +
                "<option value='Dadar and Nagar Haveli'>Dadar and NagarHaveli</option>" +
                "<option value='Daman and Diu'>Daman and Diu</option>" +
                "<option value='Delhi'>Delhi</option>" +
                "<option value='Lakshadweep'>Lakshadweep</option>" +
                "<option value='Puducherry'>Puducherry</option>" +
                "<option value='Goa'>Goa</option>" +
                "<option value='Gujarat'>Gujarat</option>" +
                "<option value='Haryana'>Haryana</option>" +
                "<option value='Himachal Pradesh'>Himachal Pradesh</option>" +
                "<option value='Jammu and Kashmir'>Jammu and Kashmir</option>" +
                "<option value='Jharkhand'>Jharkhand</option>" +
                "<option value='Karnataka'>Karnataka</option>" +
                "<option value='Kerala'>Kerala</option>" +
                "<option value='Madhya Pradesh'>Madhya Pradesh</option>" +
                "<option value='Maharashtra'>Maharashtra</option>" +
                "<option value='Manipur'>Manipur</option>" +
                "<option value='Meghalaya'>Meghalaya</option>" +
                "<option value='Mizoram'>Mizoram</option>" +
                "<option value='Nagaland'>Nagaland</option>" +
                "<option value='Odisha'>Odisha</option>" +
                "<option value='Punjab'>Punjab</option>" +
                "<option value='Rajasthan'>Rajasthan</option>" +
                "<option value='Sikkim'>Sikkim</option>" +
                "<option value='Tamil Nadu'>Tamil Nadu</option>" +
                "<option value='Telangana'>Telangana</option>" +
                "<option value='Tripura'>Tripura</option>" +
                "<option value='Uttar Pradesh'>Uttar Pradesh</option>" +
                "<option value='Uttarakhand'>Uttarakhand</option>" +
                "<option value='West Bengal'>West Bengal</option>" +
                "</select>" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='city'>City<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_city[]' id='branch_city[]' placeholder='city' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='pincode'>Pincode<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_pin[]' id='branch_pin' placeholder='Pincode' maxlength='6' oninput='javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);' onChange='return branch_pinValidation()' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='name'>Contact Person Name<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_p_name[]' id='branch_p_name[]' placeholder='Contact person name' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='name'>Contact Person Designation<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' name='branch_p_designation[]' id='branch_p_designation[]' placeholder='Contact person designation' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='name'>Contact Person Mobile<span class='text-danger'>*</span></label>" +
                "<input type='text' maxlength='10' onkeypress='return /[0-9]/i.test(event.key)' class='form-control branch_p_mobile' name='branch_p_mobile[]' id='branch_p_mobile' placeholder='Contact person Mobile' required />" +
                "</div>" +
                "<div class='form-group col-md-4'>" +
                "<label for='name'>Contact Person Email Address<span class='text-danger'>*</span></label>" +
                "<input type='email' class='form-control' name='branch_p_email[]' id='branch_p_email[]' placeholder='Email Address' required />" +
                "</div>" +
                "</div>" +
                "<div class='row'>" +
                "<div class='text-right mt-2 col-lg-12'>" +
                "<div class='float-right px-5'>" +
                "<a href='javascript:void(0)' class='pull-right deleteRow'><i class='fa fa-times fa-2x text-danger'></i></a>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>"
            $('.addMore').append(add);
            // var news = totalRows++;
            $('#totalRows').val(news);
        });

        $(document).on('click', '.deleteRow', function() {
            $(this).parents('.remove').remove();
            // location.reload();
        });


        function branch_pinValidation() {
            branch_pin = document.getElementById('branch_pin').value;
            // alert('ok');
            var format = /^[0-9]+$/;
            if (branch_pin == '') {
                alert("Branch Pin must not be empty");
                document.getElementById('branch_pin').focus();
                return false;
            } else if (branch_pin != '') {
                if (!branch_pin.match(format)) {
                    alert("Please enter Numbers only");
                    document.getElementById('branch_pin').value = '';
                    document.getElementById('branch_pin').focus();
                    return false;
                } else if (branch_pin.length < 6 || branch_pin.length > 6) {
                    alert("Branch Pin Number must be 6 digits only.");
                    document.getElementById('branch_pin').value = '';
                    document.getElementById('branch_pin').focus();
                    return false;
                } else {
                    return true;
                }
            }
        }

        function mobileValidation() {
            alert('ok');
        }
    </script>
    @if (Session::has('success'))
        <script>
            swal("Great Job!", "{!! Session('success') !!}", "success", {
                button: "OK",
            })
        </script>
    @endif
@endsection
