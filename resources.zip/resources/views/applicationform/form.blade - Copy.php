@extends('layouts.admin')
@section('content')
    {{-- <php
 echo $generalinformations['assessment_body_name'];
?> --}}
    <style>
        .new-location {
            display: none;
        }
    </style>
    <section id="contact" class="contact mt-2">
        <div class="container mt-2" data-aos="fade-down">

            <div class="row">

                <ul class="nav nav-tabs">
                    <li class="active"><a href="{{ route('general.information') }}">General Information</a></li>
                    <li><a href="{{ route('personnel.Information') }}">Personnel Information</a></li>
                    <li><a href="{{ route('other.information') }}">Other Information</a></li>
                    <li><a href="{{ route('financial-performance') }}">Financial Performance</a></li>
                    <li><a href="{{ route('annexed.information') }}">Annexed Information</a></li>
                </ul>

                <div class="tab-content" style="padding: 0px;">
                    <div id="home" class="tab-pane fade in active">

                        <div class="container" data-aos="fade-down">
                            <div class="row">
                                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                                    <form action="{{ url('general-information') }}" method="POST" id="generalform"
                                        role="form" class="php-email-form"
                                        style="border-top:none; padding:20px; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);">
                                        @csrf
                                        {{-- <div class="section-title">
                                            <h2>GENERAL INFORMATION</h2>
                                        </div> --}}
                                        @if (Session::has('success'))
                                            <p class="text-success error">{{ Session('success') }}</p>
                                        @endif
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>1. Conformity
                                                        Assessment Bodies</b></h5>
                                            </div>

                                            {{-- <input type="hidden" id="org_id" name="org_id"
                                                value="{{ session('user_id') }}"> --}}
                                            {{-- <input type="hidden" id="app_id" name="app_id"
                                                value="{{ session('app_id') }}"> --}}
                                            {{-- <input type="hidden" id="app_id" name="app_id"
                                                value="2"> --}}
                                            <div class="form-group col-md-4">
                                                <label for="name">Name of the Conformity
                                                    Assessment Body <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('assessment_body_name') is-invalid @enderror" name="assessment_body_name"
                                                    id="assessment_body_name"
                                                    value="{{ $generalinformations ? $generalinformations->assessment_body_name : '' }}"
                                                    placeholder="Name of the Conformity Assessment Bodies">
                                                    @error('assessment_body_name')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Contact Number<span
                                                        class="text-danger">*</span></label>
                                                <input type="number" class="form-control @error('ab_mobile') is-invalid @enderror" name="ab_mobile" id="ab_mobile"
                                                    pattern="[0-9]{10}" maxlength="10" min="0"
                                                    value="{{ $generalinformations ? $generalinformations->ab_mobile : '' }}"
                                                    placeholder="Contact Number" />
                                                    @error('ab_mobile')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Email Address <span
                                                        class="text-danger">*</span></label>
                                                <input type="email" class="form-control  @error('ab_email') is-invalid @enderror" name="ab_email" id="ab_email"
                                                value="{{ $generalinformations ? $generalinformations->ab_email : '' }}"
                                                    placeholder="Email Address " />
                                                    @error('email')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>2. Address of
                                                        Main Office</b></h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Address of Main Office <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control  @error('main_ofc_address') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->main_ofc_address : '' }}"
                                                    name="main_ofc_address" id="main_ofc_address" placeholder="Address of Main Office" />
                                                    @error('main_ofc_address')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">State <span class="text-danger">*</span></label>
                                                {{-- <input type="text" class="form-control"
                                                    value="{{ $generalinformations ? $generalinformations->state : '' }}"
                                                    name="state" id="state" placeholder="State" /> --}}
                                                <select name="state" id="state" class="form-select"
                                                    style="height: 44px;font-size: 14px;" required>
                                                    @if ($generalinformations ? $generalinformations->state : '')
                                                        <option
                                                            value="{{ $generalinformations ? $generalinformations->state : '' }}">
                                                            {{ $generalinformations ? $generalinformations->state : '' }}
                                                        </option>
                                                    @endif
                                                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                                                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar
                                                            Islands
                                                        </option>
                                                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                                        <option value="Assam">Assam</option>
                                                        <option value="Bihar">Bihar</option>
                                                        <option value="Chandigarh">Chandigarh</option>
                                                        <option value="Chhattisgarh">Chhattisgarh</option>
                                                        <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli
                                                        </option>
                                                        <option value="Daman and Diu">Daman and Diu</option>
                                                        <option value="Delhi">Delhi</option>
                                                        <option value="Lakshadweep">Lakshadweep</option>
                                                        <option value="Puducherry">Puducherry</option>
                                                        <option value="Goa">Goa</option>
                                                        <option value="Gujarat">Gujarat</option>
                                                        <option value="Haryana">Haryana</option>
                                                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                                                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                                        <option value="Jharkhand">Jharkhand</option>
                                                        <option value="Karnataka">Karnataka</option>
                                                        <option value="Kerala">Kerala</option>
                                                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                                                        <option value="Maharashtra">Maharashtra</option>
                                                        <option value="Manipur">Manipur</option>
                                                        <option value="Meghalaya">Meghalaya</option>
                                                        <option value="Mizoram">Mizoram</option>
                                                        <option value="Nagaland">Nagaland</option>
                                                        <option value="Odisha">Odisha</option>
                                                        <option value="Punjab">Punjab</option>
                                                        <option value="Rajasthan">Rajasthan</option>
                                                        <option value="Sikkim">Sikkim</option>
                                                        <option value="Tamil Nadu">Tamil Nadu</option>
                                                        <option value="Telangana">Telangana</option>
                                                        <option value="Tripura">Tripura</option>
                                                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                                                        <option value="Uttarakhand">Uttarakhand</option>
                                                        <option value="West Bengal">West Bengal</option>
                                                    
                                                </select>
                                                @error('state')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">City<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control  @error('city') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->city : '' }}"
                                                    name="city" id="city" placeholder="City" />
                                                    @error('city')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">PIN <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control  @error('pin') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->pin : '' }}"
                                                    name="pin" id="pin" placeholder="PIN" />
                                                    @error('pin')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            {{-- <div class="form-group col-md-4">
                                                <label for="name">Fax</label>
                                                <input type="text" class="form-control"
                                                    name="fax" id="fax" placeholder="Fax" />
                                            </div> --}}
                                            <div class="form-group col-md-4">
                                                <label for="name">Web</label>
                                                <input type="text" class="form-control"
                                                    value="{{ $generalinformations ? $generalinformations->web : '' }}"
                                                    name="web" id="web" placeholder="Web" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>3. Ownership Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="details">Ownership Details<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-sm-6 offset-col-1">
                                                    <input type="text" class="form-control  @error('owneship_detail') is-invalid @enderror"
                                                        value="{{ $generalinformations ? $generalinformations->owneship_detail : '' }}"
                                                        name="owneship_detail" id="owneship_detail"
                                                        placeholder="Ownership Details" />
                                                        @error('owneship_detail')
                                                            <span class="text-danger">{{ $message }}</span>
                                                        @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>4. Legal Registration
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Status <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control  @error('status') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->status : '' }}"
                                                    name="status" id="status" placeholder="Status" />
                                                    @error('status')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Regn. No. <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('reg_no') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_no : '' }}"
                                                    name="reg_no" id="reg_no" placeholder="Regn. No." />
                                                    @error('reg_no')
                                                        <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Date of Regn. <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('reg_date') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_date : '' }}"
                                                    name="reg_date" id="reg_date"
                                                    placeholder="Date of Regn." onfocus="(this.type='date')" />
                                                @error('reg_date')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="name">Regn. Authority <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('reg_authority') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_authority : '' }}"
                                                    name="reg_authority" id="reg_authority" placeholder="Regn. Authority" />
                                                @error('reg_authority')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Authority ">Place of regn. <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('reg_place') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->reg_place : '' }}"
                                                    id="reg_place" name="reg_place" placeholder="Place of regn.">
                                                @error('reg_place')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>5. Chief Executive
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Name ">Chief Executive Name
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('chief_name') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->chief_name : '' }}"
                                                    id="chief_name" name="chief_name" placeholder="Chief Executive Name">
                                                @error('chief_name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Designation ">Chief Executive Designation
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('chief_designation') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->chief_designation : '' }}"
                                                    id="chief_designation" name="chief_designation"
                                                    placeholder="Chief Executive Designation">
                                                @error('chief_designation')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>6. Primary Contact Person
                                                        Details</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Name ">Name
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " value="{{ $userData->name }}"
                                                    id="name" name="name" readonly />
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Designation "> Designation
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('p_designation') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->p_designation : '' }}"
                                                    id="p_designation" name="p_designation" placeholder="Designation">
                                                @error('p_designation')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Phone ">Phone</label>
                                                <input type="text" class="form-control @error('p_phone') is-invalid @enderror"
                                                    value="{{ $generalinformations ? $generalinformations->p_phone : '' }}"
                                                    id="p_phone" name="p_phone" placeholder="Phone">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Phone ">Mobile
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="mobile"
                                                    value="{{ $userData->mobile }}" id="mobile" name="mobile" readonly />
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="email">Primary Contact Person E-mail
                                                    <span class="text-danger">*</span></label>
                                                <input type="email" class="form-control " value="{{ $userData->email }}"
                                                    id="email" name="email" readonly />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>7. Address of
                                                        Branch Office</b></h5>
                                            </div>
                                        </div>
                                        <div class="addMore">
                                            <div class="text-right mt-2">
                                                <div class="float-right px-5">
                                                    <a href="javascript:void(0)"
                                                        class="pull-right btn btn-primary btn-sm addRow">Add
                                                        more</a>
                                                </div>
                                            </div>
                                            {{-- <input type="hidden" value="1" name="totalRows" id="totalRows"> --}}
                                            @php
                                                $i = 1;
                                            @endphp
                                            @if ($branch_addressess->count() > 0)
                                                @foreach ($branch_addressess as $item)
                                                    <div class="{{ $i > 1 ? 'remove' : '' }}">
                                                        <div class="row">
                                                            <input type="hidden" name="branch_id[]"
                                                                value="{{ $item->id }}" />
                                                            <div class="form-group col-md-4">
                                                                <label for="Name ">Branch Name
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item ? $item->branch_name : '' }}" id="branch_name"
                                                                    name="branch_name[]" placeholder="Branch Name">
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="name">Branch Office Address <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    name="branch_address[]" id="branch_address[]"
                                                                    value="{{ $item->branch_address ? $item->branch_address : '' }}"
                                                                    placeholder="Address of Branch Office" />
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="name">State <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    name="branch_state[]" id="branch_state[]"
                                                                    value="{{ $item->branch_state ? $item->branch_state : '' }}"
                                                                    placeholder="State" />
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="name">City<span
                                                                        class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    name="branch_city[]" id="branch_city[]"
                                                                    value="{{ $item->branch_city ? $item->branch_city : '' }}"
                                                                    placeholder="City" />
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="name">PIN <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    name="branch_pin[]" id="branch_pin[]"
                                                                    value="{{ $item->branch_pin ? $item->branch_pin : '' }}"
                                                                    placeholder="PIN" />
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="Name ">Contact Person Name
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control "
                                                                    value="{{  $item->branch_p_name ? $item->branch_p_name : '' }}" id="branch_p_name"
                                                                    name="branch_p_name[]"
                                                                    placeholder="Contact Person Name">
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="Designation ">Contact Person Designation
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->branch_p_designation ? $item->branch_p_designation : '' }}" id="branch_p_designation"
                                                                    name="branch_p_designation[]" placeholder="Designation">
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="Phone ">Contact Person Mobile
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="number" class="form-control "
                                                                    pattern="[0-9]{10}" maxlength="10" min="0"
                                                                    value="{{ $item->branch_p_mobile ? $item->branch_p_mobile : '' }}" id="branch_p_mobile"
                                                                    name="branch_p_mobile[]" placeholder="Mobile">
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="E-mail">Contact Person E-mail
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="email" class="form-control "
                                                                    value="{{ $item->branch_p_email ? $item->branch_p_email : '' }}" id="branch_p_email"
                                                                    name="branch_p_email[]" placeholder="E-mail Address">
                                                            </div>

                                                        </div>
                                                        <div class="row">
                                                            {{-- @if ($i == 1)
                                                                <div class="text-right mt-2">
                                                                    <div class="float-right px-5">
                                                                        <a href="javascript:void(0)"
                                                                            class="pull-right btn btn-primary btn-sm addRow">Add
                                                                            more</a>
                                                                    </div>
                                                                </div>
                                                            @else --}}
                                                                <div class="text-right mt-2">
                                                                    <div class="float-right px-5">
                                                                        <a onclick="return confirm('Are you sure. you want to delete this ??')" href="{{ url('delete/branch/'.$item->id) }}"
                                                                            class='pull-right btn btn-danger btn-sm deleteRow'>Remove</a>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        @php
                                                            $i++;
                                                        @endphp
                                                    </div>
                                                    <hr />
                                                @endforeach
                                            @endif
                                        </div>
                                        <div class="row my-4">
                                            <div class="text-center">
                                                <button type="button" id="reset" name="reset"
                                                    class="btn btn-sm btn-warning"
                                                    style="padding: 12px 34px; border-radius: 50px; color: antiquewhite; background-color:tomato"><i
                                                        class="bi bi-arrow-repeat"></i>
                                                    Reset</button>
                                                <button type="submit" name="save_changes" id="save_changes"
                                                    class="btn btn-sm"><i class="bi bi-save2"></i> Save &
                                                    Next</button>
                                            </div>
                                        </div>
                                        <div class="row my-4">
                                            <div class="col-md-6 pt-4">
                                                <p><i class="bi bi-chevron-double-right"></i> <span
                                                        class="text-danger">*</span>
                                                    Asterisks(*) Fields are mandatory .
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="menu1" class="tab-pane fade">
                        <div class="container" data-aos="fade-down">
                            <div class="row">
                                <h2 class="text-center pt-5">Personnel Information</h2>

                                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                                    <form action="#" method="post" role="form" class="php-email-form"
                                        style="border-top:none; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);">
                                        <div class="row py-2">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>1. Quality
                                                        Manager or Management Representative</b></h5>
                                            </div>
                                            {{-- <div class="form-group">
                                                <label class="col-md-4 mt-2" for="name">Quality Manager Name <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control " id="" name=""
                                                        placeholder="Quality Manager Name">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div> --}}
                                            <div class="form-group col-md-4">
                                                <label for="Location">Quality Manager Name <span
                                                        class="text-danger">*</span></label>

                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Quality Manager Name ">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Managerial Staff">Quality Manager Designation
                                                    <span class="text-danger">*</span></label>

                                                <input type="text" class="form-control" id="" name=""
                                                    placeholder="Quality Manager Designation">

                                            </div>
                                        </div>
                                        <div class="row">
                                            {{-- <p><b>2. Personnel for Voluntary Certification Scheme </b></p> --}}
                                            <div class="form-group">
                                                <h5 style="    background: antiquewhite;
                                                                        padding: 12px 10px;"><b>2. Personnel for Voluntary
                                                        Certification
                                                        Scheme
                                                    </b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Location">Location <span
                                                        class="text-danger">*</span></label>

                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Location">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Managerial Staff">Managerial
                                                    Staff <span class="text-danger">*</span></label>

                                                <input type="text" class="form-control" id="" name=""
                                                    placeholder="Managerial Staff">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Evaluators">Evaluators
                                                    <span class="text-danger">*</span></label>

                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Evaluators">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Support Staff">Support
                                                    Staff <span class="text-danger">*</span></label>

                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Support Staff ">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Technical experts">Technical
                                                    experts <span class="text-danger">*</span></label>

                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Technical experts">

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Total ">Total
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Total">
                                            </div>
                                        </div>
                                        <div class="row py-2">
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-sm btn-warning"
                                                    style="color: antiquewhite; background-color:tomato"><i
                                                        class="bi bi-arrow-repeat"></i> Reset</button>
                                                <button type="submit" class="btn btn-sm"><i
                                                        class="bi bi-save2"></i> Save &
                                                    Next</button>
                                            </div>
                                        </div>
                                        <div class="row my-4">
                                            <div class="col-md-6 pt-4">
                                                <p><i class="bi bi-chevron-double-right"></i> <span
                                                        class="text-danger">*</span>
                                                    Asterisks(*) Fields are mandatory .
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="menu2" class="tab-pane fade">
                        <div class="container" data-aos="fade-down">
                            <div class="row">
                                <h2 class="text-center pt-5">Other Information</h2>

                                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                                    <form action="#" method="post" role="form" class="php-email-form"
                                        style="border-top:none; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);">
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>1. NABCB member
                                                        body accreditation</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            {{-- <p>(if yes then Please specify Accreditation Body’s )</p> --}}
                                            <div class="form-group col-md-3">
                                                <label for="name">Name <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name="" placeholder="Name">
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="Cert. No. ">Cert. No.
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Cert. No. ">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="State">Validity Period
                                                    from<span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period from">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="to">Validity Period to
                                                    <span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period to">
                                            </div>
                                            <div class="form-group col-md-2 py-5">
                                                <button type="button" name="add-location" id="add-location"
                                                    class="btn btn-sm btn-primary" style="    padding: 4px 18px;
                                                                        margin-left: 30px;
                                                                        border-radius: 50px;">Add More</button>
                                            </div>
                                        </div>
                                        {{-- <div class="row">
                                            <div class="text-right">
                                                <div class="form-group">
                                                    <button type="button" name="add-location" id="add-location"
                                                        class="btn btn-sm btn-primary" style="    padding: 4px 18px;
                                                        margin-left: 30px;
                                                        border-radius: 50px;">Add More</button>
                                                </div>
                                            </div>
                                        </div> --}}
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>2. other IAF
                                                        member body accreditation</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-3">
                                                <label for="name">Name <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name="" placeholder="Name">
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="Cert. No. ">Cert. No.
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Cert. No. ">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="State">Validity Period
                                                    from<span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period from">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="to">Validity Period to
                                                    <span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period to">
                                            </div>
                                            <div class="form-group col-md-2 py-5">
                                                <button type="button" name="add-location" id="add-location"
                                                    class="btn btn-sm btn-primary" style="    padding: 4px 18px;
                                                                        margin-left: 30px;
                                                                        border-radius: 50px;">Add More</button>
                                            </div>
                                        </div>
                                        {{-- <div class="row">
                                            <div class="text-right">
                                                <div class="form-group">
                                                    <button type="button" name="add-location" id="add-location"
                                                        class="btn btn-sm btn-primary" style="    padding: 4px 18px;
                                                        margin-left: 30px;
                                                        border-radius: 50px;">Add More</button>
                                                </div>
                                            </div>
                                        </div> --}}
                                        {{-- <div class="row my-2">
                                            <div class="form-group col-md-12">
                                                <label for="name"><b>Other Approval(s) from Govt. or
                                                    Regulatory Bodies, if any </b> <span class="text-danger">*</span></label>
                                                <div class="form-check form-check-inline mx-5">
                                                    <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                                        id="inlineRadio1" value="option1" style="height: 15px;">
                                                    <label class="form-check-label" for="inlineRadio1">yes</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                                        id="inlineRadio2" value="option2" style="height: 15px;">
                                                    <label class="form-check-label" for="inlineRadio2">no</label>
                                                </div>
                                            </div>
                                        </div> --}}
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>3. Other
                                                        Approval(s) from Govt. or
                                                        Regulatory Bodies</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-3">
                                                <label for="name">Name <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name="" placeholder="Name">
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="Cert. No. ">Cert. No.
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control " id="" name=""
                                                    placeholder="Cert. No. ">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="State">Validity Period
                                                    from<span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period from">
                                            </div>
                                            <div class="form-group col-md-2">
                                                <label for="to">Validity Period to
                                                    <span class="text-danger">*</span></label>
                                                <input type="date" class="form-control " id="" name=""
                                                    placeholder="Validity Period to">
                                            </div>
                                            <div class="form-group col-md-2 py-5">
                                                <button type="button" name="add-location" id="add-location"
                                                    class="btn btn-sm btn-primary" style="    padding: 4px 18px;
                                                                        margin-left: 30px;
                                                                        border-radius: 50px;">Add More</button>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;"><b>4. Other
                                                        Other activities</b></h5>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <label class="col-md-6 mt-2" for="name">Other activities within the same
                                                    legal entity <span class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                        placeholder="Other activities within the same legal entity"> --}}
                                                        <textarea class="form-control" id="" name="" rows="2" placeholder="Other activities within the same legal entity"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <label class="col-md-6 mt-2" for="name">Related Organization(s), if any,
                                                    and their activities <span class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                        placeholder="Related Organization(s), if any, and their activities "> --}}
                                                        <textarea class="form-control" name="" id="" rows="2" placeholder="Related Organization(s), if any, and their activities "></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <label class="col-md-6 mt-2" for="name">Major Clients <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                        placeholder="Major Clients"> --}}
                                                        <textarea class="form-control" name="" id="" rows="2" placeholder="Major Clients"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <label class="col-md-6 mt-2" for="name">No. of Certificates issued for
                                                    applied scope <span class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control" id="" name=""
                                                        placeholder="No. of Certificates issued for applied scope">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="form-group">
                                                <label class="col-md-6 mt-2" for="name">Total No. of Certificates issued
                                                    -<span class="text-danger">*</span></label>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control" id="" name=""
                                                        placeholder="Total No. of Certificates issued -">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="text-center my-3">
                                                <button type="submit" class="btn btn-sm btn-warning"
                                                    style="color: antiquewhite; background-color:tomato"><i
                                                        class="bi bi-arrow-left"></i> Previous</button>
                                                <button type="submit" class="btn btn-sm"><i
                                                        class="bi bi-save2"></i> Save &
                                                    Next</button>
                                            </div>
                                        </div>
                                        <div class="row my-4">
                                            <div class="col-md-6 pt-4">
                                                <p><i class="bi bi-chevron-double-right"></i> <span
                                                        class="text-danger">*</span>
                                                    Asterisks(*) Fields are mandatory .
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- <div id="menu3" class="tab-pane fade">
                        <div class="container" data-aos="fade-down">
                            <div class="row">
                                <h2 class="text-center pt-5">Financial Performance</h2>
                                <p class="text-center">(for last 5 financial years)</p>

                                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                                    <form action="#" method="post" role="form" class="php-email-form"
                                        style="border-top:none; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);">
                                        <div class="row">
                                            <div class="form-group py-2">
                                                <label class="col-md-2 text-right" for="Name">Financial Year <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" id="" name=""
                                                        placeholder="Financial Year">
                                                </div>
                                                <label class="col-md-2 text-right" for="Name">Total Income
                                                    <span class="text-danger">*</span></label>

                                                <div class="col-md-4">
                                                    <input type="text" class="form-control " id="" name=""
                                                        placeholder="Total Income">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-2">
                                                <label class="col-md-2 text-right" for="Name">Income from certification
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" id="" name=""
                                                        placeholder="Income from certification">
                                                </div>
                                                <label class="col-md-2 text-right" for="Name">Net Profit
                                                    <span class="text-danger">*</span></label>

                                                <div class="col-md-4">
                                                    <input type="text" class="form-control " placeholder="Net Profit"
                                                        id="" name="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="float-right px-5">
                                                <button class="pull-right btn btn-primary btn-sm">Add more</button>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="text-center py-5">
                                                <button type="submit" class="btn btn-sm btn-warning"
                                                    style="color: antiquewhite; background-color:tomato"><i
                                                        class="bi bi-arrow-left"></i> Previous</button>
                                                <button type="submit" class="btn btn-sm"><i
                                                        class="bi bi-save2"></i> Save
                                                </button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div> --}}
                    <div id="menu4" class="tab-pane fade">
                        <div class="container" data-aos="fade-down">
                            <div class="row">
                                <h2 class="text-center pt-5">Annexed Information</h2>
                                <p class="text-center">(upload documents)</p>
                                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                                    <form action="#" method="post" role="form" class="php-email-form"
                                        style="border-top:none; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);">
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">1. Organization Registration
                                                    Certificate & Memorandum /
                                                    Articles of Association (copy only) <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="file" class="form-control" id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">2. Master List of Documents
                                                    reference of
                                                    voluntary certification scheme (with issue and/or revision status)
                                                    <span class="text-danger">*</span></label>

                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">3. Quality Manual by
                                                    applicable
                                                    accreditation standard
                                                    i.e. ISO/IEC 17065, ISO/IEC 17021,ISO/IEC17024 etc.<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">4. Documentation relating to
                                                    voluntary certification scheme
                                                    (Procedures, Competence Criteria, Formats, Checklists etc.) <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">5. Branch Office(s) with
                                                    activities to be covered
                                                    under approval (list per format in Table – A) <span
                                                        class="text-danger">*</span>&nbsp; <br /> &nbsp;</label>

                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">6. List of Managerial Personnel,
                                                    Auditors &
                                                    Technical Experts (list as per format in Table – B)<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        {{-- <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">7. Application Fee - Amount,
                                                    Cheque / DD No., Date: <span class="text-danger">*</span></label>

                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div> --}}
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">7. Other Documents (annex
                                                    list)<span class="text-danger">*</span> &nbsp; <br /> &nbsp;</label>

                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">8. Reference of any voluntary
                                                    certification scheme<span class="text-danger">*</span> &nbsp; <br />
                                                </label>
                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group py-3">
                                                <label class="col-md-6" for="Name">Any other relevant
                                                    information <span class="text-danger">*</span></label>

                                                <div class="col-md-4">
                                                    <input type="file" class="form-control " id="" name="">
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="text-center py-5">
                                                <button type="submit" class="btn btn-sm btn-warning"
                                                    style="color: antiquewhite; background-color:tomato"><i
                                                        class="bi bi-arrow-left"></i> Previous</button>
                                                <button type="submit" class="btn btn-sm"><i
                                                        class="bi bi-save2"></i> Save
                                                </button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        </div>

        </div>

        </div>
    </section>
@endsection
@section('script')
    <script>
        $('.addMore').on('click', '.addRow', function() {
            var totalRows = $('#totalRows').val();

            var add = "<hr/>" +
                "<div class='remove'>" +
                "<div class='row'>" +
                    "<input type='hidden' class='form-control' name='branch_id[]' value='0'  />" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='address'>Branch Name <span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_name[]' id='branch_name[]' placeholder='Branch Name' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='address'>Branch Office Address <span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_address[]' id='branch_address[]' placeholder='Address of Branch Office' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='state'>State <span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_state[]' id='branch_state[]' placeholder='State' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='city'>City<span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_city[]' id='branch_city[]' placeholder='city' required />" +
                     "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='pincode'>Pincode<span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_pin[]' id='branch_pin[]' placeholder='Pincode' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='name'>Contact Person Name<span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_p_name[]' id='branch_p_name[]' placeholder='Contact person name' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='name'>Contact Person Designation<span class='text-danger'>*</span></label>" +
                        "<input type='text' class='form-control' name='branch_p_designation[]' id='branch_p_designation[]' placeholder='Contact person designation' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='name'>Contact Person Mobile<span class='text-danger'>*</span></label>" +
                        "<input type='number' min='0' maxlength='10' class='form-control' name='branch_p_mobile[]' id='branch_p_mobile[]' placeholder='Contact person Mobile' required />" +
                    "</div>" +
                    "<div class='form-group col-md-4'>" +
                        "<label for='name'>Contact Person Email Address<span class='text-danger'>*</span></label>" +
                        "<input type='email' class='form-control' name='branch_p_email[]' id='branch_p_email[]' placeholder='Email Address' required />" +
                    "</div>" +
                "</div>" +
                "<div class='row'>" +
                    "<div class='text-right mt-2'>" +
                        "<div class='float-right px-5'>" +
                            "<a href='javascript:void(0)' class='pull-right btn btn-danger btn-sm deleteRow'>Remove</a>" +
                        "</div>" +
                    "</div>" +
                "</div>" +
                "</div>"
            $('.addMore').append(add);
            // var news = totalRows++;
            $('#totalRows').val(news);
        });

        $(document).on('click', '.deleteRow', function() {
            $(this).parents('.remove').remove();
        });
    </script>
@endsection
