@extends('layouts.orgdashboard')
@section('content')

    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h6 class="m-b-10">Application Form</h6>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                                <div class="col-lg-12">
                                                    {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                                    <div class="alert alert-success alert-dismissible fade show"
                                                        role="alert">
                                                        <strong>Success!</strong> {{ Session('success') }}
                                                        <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    </div>
                                                </div>
                                            @endif
                                            @php
                                                $user_id = session('user_id');
                                                $stage = \App\ApplicationStatus::where('user_id', $user_id)->where('id', $app_id)->first();
                                            @endphp
                                            @if ($stage->stage == '1B')
                                                @php
                                                    $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)
                                                        ->where('scrutiny_for', 'AI')
                                                        ->where('isActive', 0)
                                                        ->first();
                                                    
                                                @endphp
                                                @if ($check_Adequcy->option == 'InAdequate')
                                                <div class="col-lg-12">
                                                    <div class="alert alert-danger" role="alert">
                                                        <h4 class="alert-heading"><b>Remark !</b></h4>
                                                        <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                            @endif
                                        </div>
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>1. Organization Registration
                                                        Certificate & Memorandum /
                                                        Articles of Association (copy only) 
                                                        <span class="text-danger">*</span></h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$org_reg_cert->id }}">
                                                    <input type="hidden" class="form-control" id="fname" name="fname" value="org_reg_cert">
                                                    <input type="hidden" name="type" id="type" value="Organization Registration Certificate and Memorandum or Articles of Association">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                </div>
                                                
                                                @if (@$org_reg_cert->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->ref_of_vol }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $org_reg_cert->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-originaltitle="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$org_reg_cert->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>2. Master List of Documents
                                                        reference of
                                                        voluntary certification scheme (with issue and/or revision status)
                                                        <span class="text-danger">*</span></h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$mstr_vcs->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="ref_of_vol">
                                                    <input type="hidden" name="type" id="type" value="Master List of Documents reference of voluntary certification scheme">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$mstr_vcs->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->ref_of_vol }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $mstr_vcs->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$mstr_vcs->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>  
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>3. Quality Manual by applicable accreditation standard i.e. ISO/IEC 17065, ISO/IEC 17021,ISO/IEC17024 etc.
                                                        <span class="text-danger">*</span></h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$qlty_manual->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="qlty_manual">
                                                    <input type="hidden" name="type" id="type" value="Quality Manual by applicable accreditation standard">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$qlty_manual->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->ref_of_vol }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $qlty_manual->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$qlty_manual->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>  
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>4. Documentation relating to voluntary certification scheme (Procedures, Competence Criteria, Formats, Checklists etc.)
                                                        <span class="text-danger">*</span></h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$vol_cert_scheme->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="vol_cert_scheme">
                                                    <input type="hidden" name="type" id="type" value="Documentation relating to voluntary certification scheme">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                </div>
                                               
                                                @if (@$vol_cert_scheme->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $vol_cert_scheme->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$vol_cert_scheme->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div> 
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>5. Branch Office(s) with activities to be covered under approval (list per format in Table – A) <span
                                                            class="text-danger">*</span> &nbsp; &nbsp; <a
                                                            href="{{ url('/assets/Table-A.docx') }}" target="_blank">Sample
                                                            Format</a> <br /> &nbsp;</h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$cov_undr_aprv->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="cov_undr_aprv">
                                                    <input type="hidden" name="type" id="type" value="Branch Office with activities to be covered under approval">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$cov_undr_aprv->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $cov_undr_aprv->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$cov_undr_aprv->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>  
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>6. List of Managerial Personnel,
                                                        Auditors &
                                                        Technical Experts (list as per format in Table – B)<span
                                                            class="text-danger">*</span> &nbsp; &nbsp; <a
                                                            href="{{ url('/assets/Table-B.docx') }}" target="_blank">Sample
                                                            Format</a> </h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$man_pers_audt->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="man_pers_audt">
                                                    <input type="hidden" name="type" id="type" value="List of Managerial Personnel, Auditors">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$man_pers_audt->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $man_pers_audt->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $man_pers_audt->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$man_pers_audt->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div> 
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>7. Other Documents (annex
                                                        list)</h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$otr_doc->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="otr_doc">
                                                    <input type="hidden" name="type" id="type" value="Other Documents">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$otr_doc->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $otr_doc->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$otr_doc->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div> 
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>8. Reference of any voluntary
                                                        certification scheme</h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$ref_vol_cert_sch->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="ref_vol_cert_sch">
                                                    <input type="hidden" name="type" id="type" value="Reference of any voluntary certification scheme">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$ref_vol_cert_sch->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $ref_vol_cert_sch->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $ref_vol_cert_sch->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$ref_vol_cert_sch->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>
                                        <div class="col-lg-12">
                                            <form action="{{ route('upload.file') }}" method="POST" class="form-inline"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                                <div class="form-group mb-2 col-md-5">
                                                    <h6>Any other relevant
                                                        information</h6>
                                                </div>
                                                <div class="form-group mt-2 mx-sm-3 mb-2 col-md-4">
                                                    <input type="hidden" name="id" id="id" value="{{ @$otr_rel_info->id }}">
                                                    <input type="hidden" name="fname" id="fname" value="otr_rel_info">
                                                    <input type="hidden" name="type" id="type" value="Any other relevant information">
                                                    <input type="file" class="form-control" id="filename" name="filename" required>
                                                    {{-- <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol"
                                                                {{ @$annexed_informations->ref_of_vol ? '' : 'required' }}>
                                                            <input type="hidden" class="form-control " id="ref_of_vol"
                                                                name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}"> --}}
                                                </div>
                                                
                                                @if (@$otr_rel_info->filename != '')
                                                    {{-- <a href="{{ url('public/assets/images/annexed') }}/{{ $otr_rel_info->filename }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; --}}
                                                    <a href="{{ url('public/assets/images/annexed') }}/{{ $otr_rel_info->filename }}"
                                                        class="btn btn-warning btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top"
                                                        title="view" target="_blank">
                                                        <i class="fa fa-eye" aria-hidden="true"></i> View
                                                    </a>
                                                    <a href="{{ route('annexed.delete',[$otr_rel_info->id ]) }}" class="btn btn-danger btn-sm mt-2 mb-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Remove">
                                                        <i class="fa fa-times" aria-hidden="true"></i> Remove
                                                    </a>
                                                    @else
                                                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2" data-toggle="tooltip"
                                                    data-placement="top" title="Upload file">
                                                    <i class="fas fa-cloud-upload-alt" aria-hidden="true"></i> Upload
                                                </button>
                                                @endif
                                            </form>
                                        </div>    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $("#technical_experts").on("keyup", function() {
                var a = parseInt($('#managerial_staff').val());
                var b = parseInt($('#evaluators').val());
                var c = parseInt($('#support_staff').val());
                var d = parseInt($('#technical_experts').val());
                var sum = a + b + c + d;
                console.log(sum);
                // alert(sum);
            })
        })
    </script>
    @if (Session::has('success'))
        <script>
            swal("Great Job!", "{!! Session('success') !!}", "success", {
                button: "OK",
            })
        </script>
    @endif
@endsection
