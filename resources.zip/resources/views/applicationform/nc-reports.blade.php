@extends('layouts.orgdashboard')
@section('content')
    <style>
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }

        .cb_remark {
            display: none;
        }
    </style>
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application NCS</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application NCS</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <a href="{{ route('submitted.application',[$application->id]) }}" class="btn btn-dark"><i class="fa fa-arrow-left"></i> Go Back</a>
                        <div class="card">
                            <div class="card-body">
                                @php
                            $org_id = session('user_id');
                            $app = \App\ApplicationStatus::where('id',$application->id)->where('user_id',$org_id)->first();
                            $all_nc =  \App\AppAssessmentNC::where('org_id', $org_id)->where('app_id',$app->id)->count();
                            $all_reply =  \App\AppNcReply::where('org_id',$org_id)->where('app_id',$app->id)->where('isActive',0)->count();
                            @endphp
                                <div class="dt-responsive table-responsive">
                                    <table id="example" class="table nowrap table-striped table-bordered"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center;"><div class="handsontable">NC For</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Type</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Topic</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Findings of Assessment</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Last Reply</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Reply By</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Last Reply Date</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Nc Created Date</div></th>
                                                <th style="text-align: center;"><div class="handsontable">Action</div></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            @foreach ($all_ncs as $nc)
                                                @php
                                                    $reply = \App\AppNcReply::where('org_id',$nc->org_id)->where('app_id',$nc->app_id)->where('nc_id',$nc->id)->orderBy('id','DESC')->first();
                                                @endphp
                                                
                                                <tr>
                                                    <td><div class="handsontable">{{ $nc->nc_for }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->type }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->topic }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->findings_of_assessment }}</div></td>
                                                    <td><div class="handsontable">{{ @$reply->reply }}</div></td>
                                                    <td><div class="handsontable">{{ @$reply->reply_by }}</div></td>
                                                    <td><div class="handsontable">{{ @$reply->created_at }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->created_at }}</div></td>
                                                    <td>
                                                        <a href="{{ route('nc.reply',[$nc->id ]) }}" class="handsontable btn btn-warning btn-sm"><i class="fa fa-reply"></i> Reply</a>
                                                        @if ( @$nc->status==1 )
                                                            <p class="text-success"><b>NC Closed</b></p>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                @if ($app->stage == '2F')
                                @if ($all_nc == $all_reply)
                                    <div class="text-center handsontable">
                                    <a href="{{ route('replytoassessor',[$application->id]) }}" class="btn btn-primary btn-sm">Send All Replies to Assessor</a>
                                </div>
                                @endif
                            @endif
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header bg-primary">
                  <h5 class="modal-title" id="Heading"><b>Reply to NC</b></h5>
              </div>
              <div class="modal-body px-5">
                  <form action="{{ route('submit.reply') }}" method="POST" id="ncform" enctype="multipart/form-data">
                      @csrf
                      <div class="row">
                          <input type="hidden" name="id" id="id">
                          <input type="hidden" name="org_id" id="org_id" value="{{ $org_id }}">
                          <input type="hidden" name="app_id" id="app_id" value="{{ $application->id }}">
                          <div class="col-sm-12">
                              <div class="form-group">
                                  <label class="floating-label" for="ref_doc">Referance Document (optional)</label>
                                  <input type="file" class="form-control" name="ref_doc" id="ref_doc" placeholder="" />
                              </div>
                          </div>
                          <div class="col-sm-12">
                              <div class="form-group">
                                  <label class="floating-label" for="reply">Reply to NC</label>
                                  <textarea name="reply" id="reply" rows="5" class="form-control" placeholder="Reply to NC ... .."></textarea>
                              </div>
                          </div>
                          <div class="col-sm-12 text-center my-4">
                              <input type="submit" class="btn btn-primary" id="saveBtn" value="Submit Reply">
                              <button class="btn btn-danger" class="close" data-dismiss="modal"
                                  aria-label="Close">Close</button>
                          </div>
                      </div>
                  </form>
              </div>
          </div>
        </div>
      </div>
@endsection
      @section('script')
          <script type="text/javascript">
              $(document).ready(function() {
      
                  $('body').on('click', '.replync', function() {
                      var id = $(this).data('id');
                      $.get("{{ url('nc-reply') }}" + '/' + id , function(data) {
                          $('#ncmodal').modal('show');
                          $('#id').val(data);
                      })
                  });
      
              });
          </script>
@endsection

