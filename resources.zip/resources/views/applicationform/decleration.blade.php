@extends('layouts.orgdashboard')
@section('content')
    <style>
        .new-location {
            display: none;
        }

        .addMore1 {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Form</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                                <div class="col-lg-12">
                                                    {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                                    <div class="alert alert-success alert-dismissible fade show"
                                                        role="alert">
                                                        <strong>Success!</strong> {{ Session('success') }}
                                                        <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    </div>
                                                </div>
                                            @endif
                                            @php
                                                $org_id = session('user_id');
                                                $app = \App\ApplicationStatus::where('id', $app_id)
                                                    ->where('user_id', $org_id)
                                                    ->first();
                                                $gen_info = \App\AppGeneralInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->count();
                                                $personnel_info = \App\AppPersonnelInformation::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->count();
                                                $other_info = \App\AppOtherInformation::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->count();
                                                $financial_infos = \App\AppFinancialPerformance::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)->where('isDeleted',0)
                                                    ->count();
                                                if ($financial_infos > 0) {
                                                    $financial_info = 1;
                                                } else {
                                                    $financial_info = 0;
                                                }
                                                $org_reg_cert = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'Organization Registration Certificate and Memorandum or Articles of Association')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $mstr_vcs = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'Master List of Documents reference of voluntary certification scheme')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $qlty_manual = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'Quality Manual by applicable accreditation standard')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $vol_cert_scheme = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'Documentation relating to voluntary certification scheme')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $cov_undr_aprv = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'Branch Office with activities to be covered under approval')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $man_pers_audt = \App\AppAnnexedInfo::where('org_id', $org_id)
                                                    ->where('app_id', $app->id)
                                                    ->where('type', 'List of Managerial Personnel, Auditors')
                                                    ->where('isActive', 0)
                                                    ->count();
                                                $annexed_infos = $org_reg_cert + $mstr_vcs + $qlty_manual + $vol_cert_scheme + $cov_undr_aprv + $man_pers_audt;
                                                // $annexed_infos = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->count();
                                                // dd( $annexed_infos);
                                                if ($annexed_infos == 6 || $annexed_infos >= 6) {
                                                    $annexed_info = 1;
                                                } else {
                                                    $annexed_info = 0;
                                                }
                                                $total_count = $gen_info + $personnel_info + $other_info + $financial_info + $annexed_info;
                                            @endphp
                                        </div>
                                        <form action="{{ route('declaration.submit') }}" method="post" role="form"
                                            class="php-email-form" enctype="multipart/form-data">
                                            @csrf
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                            @if (Session::has('success'))
                                                <p class="text-success error">{{ Session('success') }}</p>
                                            @endif
                                            <div class="col-lg-12">

                                                @if ($total_count != 5)
                                                    <div class="form-group">

                                                        <h5 style="background: antiquewhite; padding: 12px 10px;"><b>Check
                                                                List For Application form</b></h5>
                                                    </div>
                                                    <div class="table-responsive my-4">
                                                        <table class="table table-bordered" style="width: 100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>S.No.</th>
                                                                    <th>Form</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>1.</td>
                                                                    <td>General Information</td>
                                                                    <td>
                                                                        @if ($gen_info > 0)
                                                                            <h5 class="text-success"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-check fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @else
                                                                            <h5 class="text-danger"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-times fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>2.</td>
                                                                    <td>Personnel Information</td>
                                                                    <td>
                                                                        @if ($personnel_info > 0)
                                                                            <h5 class="text-success"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-check fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @else
                                                                            <h5 class="text-danger"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-times fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>3.</td>
                                                                    <td>Other Information</td>
                                                                    <td>
                                                                        @if ($other_info > 0)
                                                                            <h5 class="text-success"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-check fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @else
                                                                            <h5 class="text-danger"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-times fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>4.</td>
                                                                    <td>Financial Information</td>
                                                                    <td>
                                                                        @if ($financial_info > 0)
                                                                            <h5 class="text-success"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-check fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @else
                                                                            <h5 class="text-danger"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-times fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>5.</td>
                                                                    <td>Annexed Information</td>
                                                                    <td>
                                                                        @if ($annexed_info > 0)
                                                                            <h5 class="text-success"
                                                                                style="margin-left: 10px;"><i
                                                                                    class="fa fa-2x fa-check"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @else
                                                                            <h5 class="text-danger"><i
                                                                                    style="margin-left: 10px;"
                                                                                    class="fa fa-times fa-2x"
                                                                                    aria-hidden="true"></i></h5>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                @endif
                                                @if ($total_count == 5)
                                                    <div class="form-group">

                                                        <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                            <b>Decleration for Application</b></h5>
                                                    </div>
                                                    <div class="content py-5">
                                                        <p>I, the Authorized Representative on behalf of our Certification
                                                            Body (CB), agree to the
                                                            following Terms & Conditions of QCI as well as Rules and
                                                            Procedures for QCI Approval
                                                            under the Voluntary Certification Scheme for
                                                            <u><b>{{ $scheme->scheme_name }}</b></u> , and declare the
                                                            following:
                                                        </p>
                                                        <ol style="line-height: 30px;">
                                                            <li>All statements, information and documents provided along
                                                                with this application are correct to the best of our
                                                                knowledge and belief. </li>
                                                            <li>QCI criteria, requirements, procedures and documents have
                                                                been read, understood and implemented.
                                                            </li>
                                                            <li>Have adequate resources to undertake certification work
                                                                under the Voluntary Certification Scheme for
                                                                <u><b>{{ $scheme->scheme_name }}</b></u> , undergo
                                                                assessment as well as maintain conditions for approval, and
                                                                shall pay all necessary fee and charges (including any
                                                                applicable taxes) to QCI.
                                                            </li>
                                                            <li>Shall ensure that the operations, staff and procedures of
                                                                our Certification Body (CB) will always continue to comply
                                                                with the QCI Scheme requirements and procedures.
                                                            </li>
                                                            <li>Shall always maintain impartiality and integrity in
                                                                operations as well as in certification work.
                                                            </li>
                                                            <li>Shall always provide, or give access to, all documents,
                                                                records, information and facilities during the entire
                                                                assessment process to enable a thorough assessment of our
                                                                Certification Body (CB) and also later during the period of
                                                                approval.
                                                            </li>
                                                            <li>Shall take adequate and prompt corrective and/or preventive
                                                                action(s) as may be necessary on the issues raised by QCI.
                                                            </li>
                                                            <li>Shall immediately notify QCI of any significant changes in
                                                                organizational status / structure, operations, facilities,
                                                                main policies, procedures, staff or competence, which are
                                                                likely to affect our approval.
                                                            </li>
                                                            <li>Shall undertake routine assessments, surveillances &
                                                                reassessments as scheduled by QCI and also the verification
                                                                or surprise visits as decided by QCI.
                                                            </li>
                                                            <li>Any fee and charges payable by our Certification Body (CB)
                                                                and which remains unpaid shall be recovered from our
                                                                Certification Body (CB) with late payment charges as
                                                                appropriate and decided by QCI.
                                                            </li>
                                                            <li>If our Certification Body (CB) at any time is found not
                                                                complying with the above declaration or the requirements of
                                                                QCI or ISO/IEC 17065, ISO/IEC 17021,ISO/IEC17024 standard as
                                                                applicable or is found misrepresenting or misusing approval
                                                                or carrying out malpractices or bringing QCI into disrepute,
                                                                any action against our certification body may be taken
                                                                including suspension and withdrawal as deemed appropriate by
                                                                QCI.
                                                            </li>
                                                            <li>If any information given along with this application is
                                                                later found to be false, QCI may decide to cancel our
                                                                application/approval.
                                                            </li>
                                                            <li>We shall obtain NABCB accreditation as per ISO/IEC 17065,
                                                                ISO/IEC 17021, ISO/IEC17024 for the Scheme of
                                                                <u><b>{{ $scheme->scheme_name }}</b></u> within 3 years./
                                                                within a year.
                                                            </li>
                                                        </ol>
                                                    </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <form action="{{ route('SubmitForm') }}" method="get">
                                                    @csrf
                                                    <div class="form-group form-check">
                                                        <input type="checkbox" class="form-check-input" id="exampleCheck1"
                                                            style="height: 15px;width: 15px;" required>
                                                        <label class="form-check-label" for="exampleCheck1">“I hereby
                                                            declare that information furnished above is true and correct in
                                                            every respect and in case any information is found incorrect
                                                            even partially the candidature shall be liable to be
                                                            rejected.”</label>
                                                    </div>
                                                    <div class="text-center py-1 pb-5">
                                                        <button type="submit" class="btn btn-primary btn-sm"><i
                                                                class="bi bi-save2"></i> Submit Application
                                                        </button>
                                                    </div>
                                                </form>
                                                {{-- </div> --}}
                                            </div>
                                            @endif
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection




