<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Preview</title>
    <style type="text/css">
        body {
            font-family: "Open Sans", sans-serif;
            font-size: 14px;
            color: #000000;
            font-weight: 500;
            background: #ffffff;
            position: relative;
        }

        table th {
            padding: 8px;
            text-align: center;
        }

        table td {
            text-align: center;
            font-weight: 400;
            padding: 8px 12px;
        }

    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <table style="width:100%">
                <tr>
                    <td>
                        <img src="https://qcin.org/public/img/QCI-Logo.png" alt="QCI">
                    </td>
                </tr>
                <tr>
                    <td>
                        2nd Floor, Institution of Engineers Building, Bahadur Shah Zafar Marg, New Delhi – 110002
                    </td>
                </tr>
                {{-- <tr>
                    <td>Phone: +91-11-2337 8056 / 57; Fax: +91-11-2337 8678; E-mail: ajita@qcin.org; Web: www.qcin.org</td>
                </tr> --}}
            </table>
            <p style="text-align: center;">Aplication Number: &nbsp; {{ $app->application_no }}</p>
            <table style="margin-top: 20px; width:100%">
                <tr>
                    <th style="background: #d6d6d6; text-align:center">
                        General Information
                    </th>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">1. Conformity Assessment
                                Bodies</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Name of the Organization</th>
                                        <th>Name of the Scheme</th>
                                        <th>Scheme Level</th>
                                        <th>Contact Number</th>
                                        <th>Email Address</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$user->org_name }}</td>
                                        <td>{{ @$scheme->scheme_name }}</td>
                                        <td>{{ @$app->level }}</td>
                                        <td>{{ @$general_info->ab_mobile }}</td>
                                        <td>{{ @$general_info->ab_email }}</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">2. Address
                                of Main Office</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Address of Main Office</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Pincode</th>
                                        <th>Website</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$general_info->main_ofc_address }}
                                        </td>
                                        <td>{{ @$general_info->state }}
                                        </td>
                                        <td>{{ @$general_info->city }}
                                        </td>
                                        <td>{{ @$general_info->pin }}
                                        </td>
                                        <td>{{ @$general_info->web }}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">3. Ownership Details</th>
                        </tr>
                        <tr>
                            <td width="50%">Ownership Detail</td>
                            <td>{{ @$general_info->owneship_detail }}</td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">4. Legal Registration
                                Details</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Status</th>
                                        <th>Registration Number</th>
                                        <th>Date of Registration</th>
                                        <th>Registration Authority</th>
                                        <th>Place of Registration</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$general_info->status }}
                                        </td>
                                        <td>{{ @$general_info->reg_no }}
                                        </td>
                                        <td>{{ \Carbon\Carbon::parse($general_info->reg_date)->format('d-m-Y')}}
                                        </td>
                                        <td>{{ @$general_info->reg_authority }}
                                        </td>
                                        <td>{{ @$general_info->reg_place }}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">5. Chief Executive Details
                            </th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Chief Executive Name</th>
                                        <th>Chief Executive Designation</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$general_info->chief_name }}
                                        </td>
                                        <td>{{ @$general_info->chief_designation }}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">6. Primary Contact Person
                                Details</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Mobile Number</th>
                                        <th>Email Address</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$user->name }}
                                        </td>
                                        <td>{{ @$general_info->p_designation }}
                                        </td>
                                        <td>{{ @$user->mobile }}</td>
                                        <td>{{ @$user->email }}</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-2" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">7. Address
                                of Branch Office/Offices</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table width="100%" class="" border="1" cellspacing="0" align="Center"
                                    style="width: 100%;">
                                    <tr>
                                        <th>Branch</th>
                                        <th>Address</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Pincode</th>
                                        <th>Contact Person</th>
                                        <th>Designation</th>
                                        {{-- <th>Email</th> --}}
                                        <th>Mobile</th>
                                    </tr>
                                    @foreach ($branch_addresses as $branch_address)
                                        <tr>
                                            <td>{{ @$branch_address->branch_name }}
                                            </td>
                                            <td>{{ @$branch_address->branch_address }}
                                            </td>
                                            <td>{{ @$branch_address->branch_state }}
                                            </td>
                                            <td>{{ @$branch_address->branch_city }}
                                            </td>
                                            <td>{{ @$branch_address->branch_pin }}
                                            </td>
                                            <td>{{ @$branch_address->branch_p_name }}
                                            </td>
                                            <td>{{ @$branch_address->branch_p_designation }}
                                            </td>
                                            {{-- <td>{{ @$branch_address->branch_p_email }}
                                            </td> --}}
                                            <td>{{ @$branch_address->branch_p_mobile }}
                                            </td>
                                        </tr>
                                    @endforeach
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
            </table>
            <table style="margin-top: 20px; width:100%">
                <tr>
                    <th style="background: #d6d6d6; text-align:center;">
                        Personnal Information
                    </th>
                </tr>
                <tr>
                    <table class="mt-2 text-center" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">1. Quality Manager or
                                Management Representative</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Quality Manager Name</th>
                                        <th>Quality Manager Designation</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$personnel_info->quality_manager_name }}
                                        </td>
                                        <td>{{ @$personnel_info->quality_manager_designation }}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">2. Personnel for Voluntary
                                Certification Scheme</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        {{-- <th>Location</th> --}}
                                        <th>Managerial Staff</th>
                                        <th>Evaluators</th>
                                        <th>Support Staff</th>
                                        <th>Technical Staff</th>
                                        <th>Total</th>
                                    </tr>
                                    @foreach ($certificate_schemes as $certificate_scheme)
                                        <tr>
                                            {{-- <td>{{ @$certificate_scheme->location }}</td> --}}
                                            <td>{{ @$certificate_scheme->managerial_staff }}</td>
                                            <td>{{ @$certificate_scheme->evaluators }}</td>
                                            <td>{{ @$certificate_scheme->support_staff }}</td>
                                            <td>{{ @$certificate_scheme->technical_experts }}</td>
                                            <td>{{ @$certificate_scheme->total }}</td>
                                        </tr>
                                    @endforeach
                                </table>
                            </td>
                        </tr>
                    </table>

                </tr>
            </table>
            <table style="margin-top: 20px; width: 100%;">
                <tr>
                    <th style="background: #d6d6d6; text-align: center;">Other Information</th>
                </tr>
                <tr>
                    <table class="text-center mt-1" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">1. NABCB member body
                                accreditation</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Name</th>
                                        <th>Certificate Number</th>
                                        <th>Validity Period from</th>
                                        <th>Validity Period to</th>
                                    </tr>
                                    @foreach ($nabcb_bodies as $nabcb_body)
                                        <tr>
                                            <td>{{ @$nabcb_body->nabcb_name }}</td>
                                            <td>{{ @$nabcb_body->nabcb_cert_no }}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$nabcb_body->nabcb_valid_from)->format('d-m-Y')}}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$nabcb_body->nabcb_valid_to)->format('d-m-Y')}}</td>
                                        </tr>
                                    @endforeach
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-1" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">2. other IAF member body
                                accreditation</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Name</th>
                                        <th>Certificate Number</th>
                                        <th>Validity Period from</th>
                                        <th>Validity Period to</th>
                                    </tr>
                                    @foreach ($iaf_member_bodies as $iaf_member_body)
                                        <tr>
                                            <td>{{ @$iaf_member_body->iaf_name }}</td>
                                            <td>{{ @$iaf_member_body->iaf_cert_no }}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$iaf_member_body->iaf_valid_from)->format('d-m-Y')}}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$iaf_member_body->iaf_valid_to)->format('d-m-Y')}}</td>
                                        </tr>
                                    @endforeach
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-1" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">3. Other Approval(s) from
                                Govt. or Regulatory Bodies</th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Name</th>
                                        <th>Certificate Number</th>
                                        <th>Validity Period from</th>
                                        <th>Validity Period to</th>
                                    </tr>
                                    @foreach ($other_approvals as $other_approval)
                                        <tr>
                                            <td>{{ @$other_approval->other_name }}</td>
                                            <td>{{ @$other_approval->other_cert_no }}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$other_approval->other_valid_from)->format('d-m-Y')}}</td>
                                            <td>{{ \Carbon\Carbon::parse(@$other_approval->other_valid_to)->format('d-m-Y')}}</td>
                                        </tr>
                                    @endforeach
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
                <tr>
                    <table class="text-center mt-1" border="1" cellspacing="0" align="Center" rules="all"
                        style="border-collapse:collapse;width: 100%;border: beige;">
                        <tr>
                            <th colspan="2" style="background: #d6d6d6; text-align: center;">4. Other Other activities
                            </th>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table class="" border="1" cellspacing="0" align="Center" rules="all"
                                    style="border-collapse:collapse;width: 100%;">
                                    <tr>
                                        <th>Other activities within the same legal entity</th>
                                        <th>Related Organization(s), if any, and their activities</th>
                                        <th>Major Clients</th>
                                        <th>No. of Certificates issued for applied scope</th>
                                        <th>Total No. of Certificates issued</th>
                                    </tr>
                                    <tr>
                                        <td>{{ @$other_information->other_activities }}</td>
                                        <td>{{ @$other_information->related_org }}</td>
                                        <td>{{ @$other_information->major_clients }}</td>
                                        <td>{{ @$other_information->no_of_certificates }}</td>
                                        <td>{{ @$other_information->total_certificate_issued }}</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </tr>
            </table>
            <table style="margin-top: 20px; width:100%" border="1" cellspacing="0">
                <tr>
                    <th colspan="2" style="background: #d6d6d6; text-align: center;">Financial Performance</th>
                </tr>
                <tr>
                    <td colspan="2">
                        <table class="" border="1" cellspacing="0" align="Center" rules="all"
                            style="border-collapse:collapse;width: 100%;">
                            <tr>
                                <th>Financial Year</th>
                                <th>Total Income</th>
                                <th>Income from certification</th>
                                <th>Net Profit</th>
                            </tr>
                            @foreach ($financial_performances as $financial_performance)
                                <tr>
                                    <td>{{ @$financial_performance->financial_year }}</td>
                                    <td>{{ @$financial_performance->total_income }}</td>
                                    <td>{{ @$financial_performance->income_from_certification }}</td>
                                    <td>{{ @$financial_performance->net_profit }}</td>
                                </tr>
                            @endforeach
                        </table>
                    </td>
                </tr>
            </table>
            <table border="1" cellspacing="0" align="Center" rules="all"
                style="border-collapse:collapse;width: 100%;border: beige; margin-top:20px;">
                <tr>
                    <th colspan="3" style="background: #d6d6d6; text-align: center;">
                        Annexed Information
                    </th>
                </tr>
                <tr>
                    <td width="7%">(1)</td>
                    <td width="75%">
                        Organization Registration Certificate & Memorandum / Articles of Association (copy only)
                    </td>
                    <td width="18%">
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$org_reg_cert->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$org_reg_cert->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(2)</td>
                    <td>
                        Master List of Documents reference of voluntary certification scheme (with issue and/or revision
                        status)
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$ref_of_vol->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$ref_of_vol->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(3)</td>
                    <td>
                        Quality Manual by applicable accreditation standard i.e. ISO/IEC 17065, ISO/IEC
                        17021,ISO/IEC17024 etc.
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$applicable_acc_stand->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$applicable_acc_stand->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(4)</td>
                    <td>
                        Documentation relating to voluntary certification scheme (Procedures, Competence Criteria,
                        Formats, Checklists etc.)
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$related_to_vol->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$related_to_vol->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(5)</td>
                    <td>
                        Branch Office(s) with activities to be covered under approval (list per format in Table – A)
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$branch_activity->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$branch_activity->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(6)</td>
                    <td>
                        List of Managerial Personnel, Auditors & Technical Experts (list as per format in Table – B)
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$list_of_experts->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$list_of_experts->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(7)</td>
                    <td>
                        Other Documents (annex list)
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$other_cert->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$other_cert->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td>(8)</td>
                    <td>
                        Reference of any voluntary certification scheme
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$ref_of_any_vol->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$ref_of_any_vol->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        Any other relevant information
                    </td>
                    <td>
                        <a href="http://paddscheme.7techies.com/public/assets/images/annexed/{{ @$any_other_rel->filename }}"
                            target="_blank" class="text-success"
                            style="cursor: pointer;">{{ @$any_other_rel->filename ? 'view' : '' }}</a>
                    </td>
                </tr>
            </table>

        </div>
    </div>
</body>

</html>
