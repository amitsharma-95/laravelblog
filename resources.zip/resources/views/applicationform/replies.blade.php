@extends('layouts.orgdashboard')
@section('content')
    <style>
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }

        .cb_remark {
            display: none;
        }
    </style>
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application NCS</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application NCS</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        @php
                        $assessment_nc = \App\AppAssessmentNC::where('id', $nc_id)->first();
                    @endphp
                        <a href="{{ route('reply.nc',[$assessment_nc->app_id]) }}" class="btn btn-dark"><i class="fa fa-arrow-left"></i> Go Back</a>
                        <div class="card">

                            <div class="card-header  justify-content-between  py-3 text-center">
                                <b>NC Topic - <span class="text-primary">{{ $assessment_nc->topic }}</span></b>
                                {{-- <a href="{{ route('submitted.application') }}" class="btn btn-dark btn-sm float-right"><i class="fa fa-arrow-left"></i> Go Back</a> --}}
                            </div>
                            <div class="card-body">
                                <div class="row mb-5">
                                    <div class="col-md-6 text-right px-5">
                                        <h5><b>NC For </b></h5>
                                        <h5><b>NC Type </b></h5>
                                        <h5><b>Findings of Assessment </b></h5>
                                    </div>
                                    <div class="col-md-6 text-left px-3">
                                        <h5><b><span class="text-primary">{{ $assessment_nc->nc_for }}</span></b></h5>
                                        <h5><b><span class="text-primary">{{ $assessment_nc->type }}</span></b></h5>
                                        <h5><b><span class="text-primary">{{ $assessment_nc->findings_of_assessment }}</span></b></h5>
                                    </div>
                                </div>
                                <div class="row">
                                    @php
                                        $org_id = session('user_id');
                                        $status = \App\ApplicationStatus::where('id',$assessment_nc->app_id)->where('user_id', $org_id)->first();
                                    @endphp
                                    @if ($status->stage == '2F')
                                        <div class="col-md-6">
                                            <div class="card" style="border-top: 4px solid #ffa900;">
                                                <div class="card-header d-flex justify-content-between align-items-center py-3">
                                                    <b>Reply NC</b>
                                                    {{-- <a href="{{ route('submitted.application') }}" class="btn btn-dark btn-sm"><i
                                                        class="fa fa-arrow-left"></i> Go Back</a> --}}
                                                </div>
                                                <div class="card-body">
                                                    <form action="{{ route('submitto.reply') }}" method="POST" id="ncform"
                                                        enctype="multipart/form-data">
                                                        @csrf
                                                        <div class="row">
                                                            <input type="hidden" name="nc_id" id="nc_id"
                                                                value="{{ $nc_id }}">
                                                            <input type="hidden" name="org_id" id="org_id"
                                                                value="{{ $org_id }}">
                                                            <input type="hidden" name="app_id" id="app_id"
                                                                value="{{ $status->id }}">
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label for="ref_doc" style="    top: -10px;
                                                                    font-size: 0.75rem;
                                                                    color: #4680ff;">Referance Document
                                                                        (optional)</label>
                                                                    <input type="file" class="form-control" name="ref_doc"
                                                                        id="ref_doc" placeholder="" />
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label class="floating-label" for="reply">Reply to NC <span
                                                                            class="text-danger">*</span></label>
                                                                    <textarea name="reply" id="reply" rows="5" class="form-control" placeholder="Reply to NC ... .." required></textarea>
                                                                </div>
                                                            </div>
            
                                                            <div class="col-sm-12 text-center my-4">
                                                                <input type="submit" class="btn btn-primary" id="saveBtn"
                                                                    value="Submit Reply">
                                                                {{-- <button class="btn btn-danger" class="close" data-dismiss="modal"
                                                            aria-label="Close">Close</button> --}}
                                                            </div>
            
            
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-header d-flex justify-content-between align-items-center py-3"
                                                style="border-top: 4px solid #ffa900;">
                                                <b>CB/Assessor Replies</b>
                                                {{-- <a href="{{ route('submitted.application') }}" class="btn btn-dark btn-sm"><i
                                                    class="fa fa-arrow-left"></i> Go Back</a> --}}
                                            </div>
                                            <div class="card-body">
                                                @foreach ($replies as $reply)
                                                    @if ($reply->reply_by == 'Applicant')
                                                        <div class="d-flex flex-row justify-content-start">
                                                            <img src="{{ asset('assets/img/team/org_avatar.png') }}" alt="avatar 1"
                                                                style="width: 45px; height: 100%;">
                                                            <div class="p-3 me-3 border"
                                                                style="border-radius: 15px; margin-left: 10px; background-color: #f5f6f7;">
                                                                <p class="small mb-0">
                                                                    {{ $reply->reply_by == 'Applicant' ? $reply->reply : '.......' }}</p>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex justify-content-between mb-5">
                                                            <p class="small mb-1">{{ $reply->reply_by }}</p>
                                                            <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                                    aria-hidden="true"></i>
                                                                {{ $reply->created_at }}</p>
                                                        </div>
                                                    @endif
                                                    @if ($reply->reply_by == 'Assessor')
                                                        <div class="d-flex flex-row justify-content-end pt-1">
                                                            <div class="p-3 ms-3 mr-2"
                                                                style="border-radius: 15px; margin-right: 10px; background-color: rgba(57, 192, 237,.2);">
                                                                <p class="small mb-0">
                                                                    {{ $reply->reply_by == 'Assessor' ? $reply->reply : '.......' }}
                                                                </p>
                                                            </div>
                                                            <img src="{{ asset('assets/img/team/assessor_avatar.png') }}"
                                                                alt="avatar 1" style="width: 45px; height: 100%;">
                                                        </div>
                                                        <div class="d-flex justify-content-between mb-5">
                                                            <p class="small mb-1 text-muted"><i class="fa fa-clock-o"
                                                                    aria-hidden="true"></i>
                                                                {{ $reply->updated_at }}</p>
                                                            <p class="small mb-1">Assessor</p>
                                                        </div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
