@extends('layouts.orgdashboard')
@section('content')
    <style>
        .new-location {
            display: none;
        }

        .addMore1 {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Form</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                                <div class="col-lg-12">
                                                    {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                                    <div class="alert alert-success alert-dismissible fade show"
                                                        role="alert">
                                                        <strong>Success!</strong> {{ Session('success') }}
                                                        <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    </div>
                                                </div>
                                            @endif
                                            @php
                                                $user_id = session('user_id');
                                                $stage = \App\ApplicationStatus::where('id', $app_id)
                                                    ->where('user_id', $user_id)
                                                    ->first();
                                                // dd($stage);
                                            @endphp
                                            @if ($stage->stage == '1B')
                                                @php
                                                    $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)
                                                        ->where('scrutiny_for', 'FI')
                                                        ->where('isActive', 0)
                                                        ->first();
                                                    
                                                @endphp
                                                @if ($check_Adequcy->option == 'InAdequate')
                                                    <div class="col-lg-12">
                                                        <div class="alert alert-danger" role="alert">
                                                            <h4 class="alert-heading"><b>Remark !</b></h4>
                                                            <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                                        </div>
                                                    </div>
                                                @endif
                                            @endif
                                        </div>
                                        <form action="{{ route('financialPerformance') }}" method="POST" class="row">
                                            @csrf
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>1. Financial Year Performance</b>
                                                </h5>
                                            </div>
                                            <div class="addMore col-lg-12">
                                                @php
                                                    $i = 1;
                                                @endphp
                                                @if ($financial_details->count() > 0)
                                                    <div class="row">
                                                        <div class="float-right col-lg-12 px-5 my-3">
                                                            <a href="javascript:void(0)"
                                                                class="pull-right float-right addRow"><i
                                                                    class="fa fa-2x fa-plus-circle"
                                                                    aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                    @foreach ($financial_details as $item)
                                                        <input type="hidden" name="financial_address_id[]"
                                                            value="{{ @$item->id }}" />
                                                        <div class="form-group row py-2">
                                                            <label class="col-md-2 " for="financial_year">Financial
                                                                Year
                                                                <span class="text-danger">*</span></label>
                                                            <div class="col-md-4">
                                                                <input type="text"
                                                                    class="form-control @error('financial_year') is-invalid @enderror"
                                                                    id="financial_year" name="financial_year[]"
                                                                    value="{{ $item->financial_year }}"
                                                                    placeholder="Financial Year" required>
                                                                @error('financial_year')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                            <label class="col-md-2 " for="total_income">Total
                                                                Income
                                                                <span class="text-danger">*</span></label>

                                                            <div class="col-md-4">
                                                                <input type="text"
                                                                    class="form-control  @error('total_income') is-invalid @enderror"
                                                                    id="total_income" name="total_income[]"
                                                                    value="{{ $item->total_income }}"
                                                                    placeholder="Total Income" required>
                                                                @error('total_income')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        <div class="form-group row py-2">
                                                            <label class="col-md-2" for="income_from_certification">Income
                                                                from certification
                                                                <span class="text-danger">*</span></label>
                                                            <div class="col-md-4">
                                                                <input type="text"
                                                                    class="form-control @error('income_from_certification') is-invalid @enderror"
                                                                    id="income_from_certification"
                                                                    value="{{ $item->income_from_certification }}"
                                                                    name="income_from_certification[]"
                                                                    placeholder="Income from certification" required />
                                                                @error('income_from_certification')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                            <label class="col-md-2 " for="Name">Net Profit
                                                                <span class="text-danger">*</span></label>

                                                            <div class="col-md-4">
                                                                <input type="text"
                                                                    class="form-control  @error('net_profit') is-invalid @enderror"
                                                                    placeholder="Net Profit"
                                                                    value="{{ $item->net_profit }}" id="net_profit"
                                                                    name="net_profit[]" required />
                                                                @error('net_profit')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        {{-- <div class="mt-2"> --}}
                                                        <div class="float-right px-5">
                                                            <a onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                href="{{ url('delete/financial/' . $item->id) }}"
                                                                class='pull-right float-right deleteRow'><i
                                                                    class='fa fa-times fa-2x text-danger'></i></a>
                                                        </div>
                                                        {{-- </div> --}}
                                                    @endforeach
                                                @else
                                                    <div class="float-right col-lg-12 px-5">
                                                        <a href="javascript:void(0)"
                                                            class="pull-right float-right addRow">
                                                            <i class="fa fa-2x fa-plus-circle" aria-hidden="true"></i>
                                                        </a>
                                                    </div>
                                                    <input type="hidden" name="financial_address_id[]" value="" />
                                                    <div class="form-group row py-2">
                                                        <label class="col-md-2 " for="financial_year">Financial
                                                            Year
                                                            <span class="text-danger">*</span></label>
                                                        <div class="col-md-4">
                                                            <input type="number" maxlength='4' minlength='4'
                                                                class="form-control @error('financial_year[]') is-invalid @enderror"
                                                                id="financial_year" name="financial_year[]"
                                                                placeholder="Financial Year" required>
                                                            @error('financial_year[]')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                        <label class="col-md-2 " for="total_income">Total Income
                                                            <span class="text-danger">*</span></label>

                                                        <div class="col-md-4">
                                                            <input type="number" min="0"
                                                                class="form-control @error('total_income[]') is-invalid @enderror"
                                                                id="total_income" name="total_income[]"
                                                                placeholder="Total Income" required>
                                                            @error('total_income[]')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div
                                                        class="form-group row
                                                         py-2">
                                                        <label class="col-md-2 " for="income_from_certification">Income
                                                            from certification
                                                            <span class="text-danger">*</span></label>
                                                        <div class="col-md-4">
                                                            <input type="number" min="0"
                                                                class="form-control @error('income_from_certification[]') is-invalid @enderror"
                                                                id="income_from_certification"
                                                                name="income_from_certification[]"
                                                                placeholder="Income from certification" required>
                                                            @error('income_from_certification[]')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                        <label class="col-md-2 " for="Name">Net Profit
                                                            <span class="text-danger">*</span></label>

                                                        <div class="col-md-4">
                                                            <input type="number" min="0"
                                                                class="form-control @error('net_profit[]') is-invalid @enderror"
                                                                placeholder="Net Profit" id="net_profit"
                                                                name="net_profit[]" required>
                                                            @error('net_profit[]')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                @endif

                                            </div>
                                            <div class="col-lg-12 my-4">
                                                <div class="text-center">
                                                    <button type="submit" name="save_changes" id="save_changes"
                                                        class="btn btn-primary"><i class="bi bi-save2"></i> Save
                                                        Changes</button>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 pt-4">
                                                    <p><i class="bi bi-chevron-double-right"></i> <span
                                                            class="text-danger">*</span>
                                                        Asterisks(*) Fields are mandatory .
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection




@section('script')
    <script>
        $(document).ready(function() {
            $("#financial_year").each(function() {
                $("#financial_year").datepicker({
                    format: "yyyy",
                    viewMode: "years",
                    minViewMode: "years",
                    autoclose: true
                });
            });
        })

        $('.addMore').on('click', '.addRow', function() {
            var newrow = "<hr>" +
                "<div id='remove'>" +
                "<input type='hidden' name='financial_address_id[]' value='' />" +
                "<div class='form-group row py-2'>" +
                "<label class='col-md-2 ' for='financial_year'>Financial Year<span class='text-danger'>*</span></label>" +
                "<div class='col-md-4'>" +
                "<input type='text' class='form-control' id='financial_year' name='financial_year[]'' placeholder='Financial Year' required />" +
                "</div>" +
                "<label class='col-md-2 ' for='total_income'>Total Income<span class='text-danger'>*</span></label>" +
                "<div class='col-md-4'>" +
                "<input type='number' class='form-control' id='total_income' name='total_income[]' placeholder='Total Income' required />" +
                "</div>" +
                "</div>" +
                "<div class='form-group row py-2'>" +
                "<label class='col-md-2 ' for='income_from_certification'>Income from certification <span class='text-danger'>*</span></label>" +
                "<div class='col-md-4'>" +
                "<input type='number' class='form-control' id='income_from_certification' name='income_from_certification[]' placeholder='Income from certification' required />" +
                "</div>" +
                "<label class='col-md-2 ' for='Name'>Net Profit<span class='text-danger'>*</span></label>" +
                "<div class='col-md-4'>" +
                "<input type='number' class='form-control' placeholder='Net Profit' id='net_profit' name='net_profit[]' required />" +
                "</div>" +
                "</div>" +
                "<div class='float-right px-5'>" +
                "<a href='javascript:void(0)' class='pull-right float-right deleteRow'><i class='fa fa-times fa-2x text-danger'></i></a>" +
                "</div>" +
                "</div>" +
                "</div>"

            $('.addMore').append(newrow);
        });

        $(document).on('click', '.deleteRow', function() {
            $(this).parents('#remove').remove();
        });
    </script>
@endsection
