@extends('layouts.orgdashboard')
@section('content')
    <style>
        .new-location {
            display: none;
        }

        .addMore1 {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Form</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                                <div class="col-lg-12">
                                                    {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                                    <div class="alert alert-success alert-dismissible fade show"
                                                        role="alert">
                                                        <strong>Success!</strong> {{ Session('success') }}
                                                        <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    </div>
                                                </div>
                                            @endif
                                            @php
                                                $user_id = session('user_id');
                                                $stage = \App\ApplicationStatus::where('id', $app_id)
                                                    ->where('user_id', $user_id)
                                                    ->first();
                                            @endphp

                                            @if ($stage->stage == '1B')
                                                @php
                                                    $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)
                                                        ->where('scrutiny_for', 'OI')
                                                        ->where('isActive', 0)
                                                        ->first();
                                                    
                                                @endphp
                                                @if ($check_Adequcy->option == 'InAdequate')
                                                <div class="col-lg-12">
                                                    <div class="alert alert-danger" role="alert">
                                                        <h4 class="alert-heading"><b>Remark !</b></h4>
                                                        <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                            @endif
                                        </div>
                                        <form action="{{ route('other.information') }}" method="POST" class="row">
                                            @csrf
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>1. Quality Manager or Management Representative</b>
                                                </h5>
                                            </div>
                                            <div class="addNabcb col-lg-12">
                                                @php
                                                    $i = 1;
                                                @endphp
                                                @if ($nabcb_members->count() > 0)
                                                <div class="row">
                                                    <div class="float-right col-lg-12 px-5 mb-5">
                                                        <a href="javascript:void(0)" class="pull-right float-right addRow"><i
                                                                class="fa fa-2x fa-plus-circle" aria-hidden="true"></i></a>
                                                    </div>
                                                </div>
                                                    @foreach ($nabcb_members as $item)
                                                        <div class="row">
                                                            <input type='hidden' name='nabcb_id[]'
                                                                value="{{ @$item->id }}">
                                                            <div class="form-group col-md-3">
                                                                <label for="name">Name </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->nabcb_name }}" id="nabcb_name"
                                                                    name="nabcb_name[]" placeholder="Name">
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Certificate No. ">Certificate No.
                                                                </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->nabcb_cert_no }}" id="nabcb_cert_no"
                                                                    name="nabcb_cert_no[]" placeholder="Certificate No. ">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="State">Validity Period
                                                                    from</label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->nabcb_valid_from }}" id="start_date"
                                                                    name="nabcb_valid_from[]"
                                                                    placeholder="Validity Period from">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="to">Validity Period to
                                                                </label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->nabcb_valid_to }}" id="end_date"
                                                                    name="nabcb_valid_to[]"
                                                                    placeholder="Validity Period to">
                                                            </div>
                                                            <div class="form-group col-md-2 py-5">
                                                                <div class="float-right px-5">
                                                                    <a onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                        href="{{ url('delete/nabcb-bodies/' . $item->id) }}"
                                                                        class='pull-right deleteRow'><i
                                                                            class="fa fa-times fa-2x text-danger"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="row">
                                                        <input type='hidden' name='nabcb_id[]' value=''>
                                                        <div class="form-group col-md-3">
                                                            <label for="name">Name </label>
                                                            <input type="text" class="form-control " id="nabcb_name"
                                                                name="nabcb_name[]" placeholder="Name">
                                                        </div>
                                                        <div class="form-group col-md-3">
                                                            <label for="Certificate No. ">Certificate No.
                                                            </label>
                                                            <input type="text" class="form-control "
                                                                id="nabcb_cert_no" name="nabcb_cert_no[]"
                                                                placeholder="Certificate No. ">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="State">Validity Period
                                                                from</label>
                                                            <input type="date" class="form-control " id="start_date"
                                                                name="nabcb_valid_from[]"
                                                                placeholder="Validity Period from">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="to">Validity Period to
                                                            </label>
                                                            <input type="date" class="form-control " id="end_date"
                                                                name="nabcb_valid_to[]" placeholder="Validity Period to">
                                                        </div>
                                                        <div class="form-group col-lg-2 col-md-2 py-5">
                                                            <div class="float-right px-5">
                                                                <a href="javascript:void(0)" class="pull-right addRow"><i
                                                                        class="fa fa-2x fa-plus-circle"
                                                                        aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            </div>
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>2. Other IAF Member Body Accreditation</b>
                                                </h5>
                                            </div>
                                            <div class="addIaf col-lg-12">
                                                @php
                                                    $i = 1;
                                                @endphp
                                                @if ($iaf_members->count() > 0)
                                                    <div class="row">
                                                        <div class="float-right col-lg-12 px-5 mb-5">
                                                            <a href="javascript:void(0)" class="pull-right float-right addRow"><i
                                                                    class="fa fa-plus-circle fa-2x"
                                                                    aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                    @foreach ($iaf_members as $item)
                                                        <div class="row">
                                                            <input type='hidden' name='iaf_id[]'
                                                                value="{{ @$item->id }}">
                                                            <div class="form-group col-md-3">
                                                                <label for="name">Name </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->iaf_name }}" id="iaf_name"
                                                                    name="iaf_name[]" placeholder="Name">
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Certificate No. ">Certificate No.
                                                                </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->iaf_cert_no }}" id="iaf_cert_no"
                                                                    name="iaf_cert_no[]" placeholder="Certificate No. ">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="State">Validity Period
                                                                    from</label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->iaf_valid_from }}"
                                                                    id="iaf_valid_from" name="iaf_valid_from[]"
                                                                    placeholder="Validity Period from">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="to">Validity Period to
                                                                </label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->iaf_valid_to }}" id="iaf_valid_to"
                                                                    name="iaf_valid_to[]"
                                                                    placeholder="Validity Period to">
                                                            </div>
                                                            <div class="form-group col-md-2 py-5">
                                                                <div class="float-right px-5">
                                                                    <a onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                        href="{{ url('delete/iaf-bodies/' . $item->id) }}"
                                                                        class='pull-right deleteRow'><i
                                                                            class="fa fa-times fa-2x text-danger"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="row">
                                                        <input type='hidden' name='iaf_id[]' value=''>
                                                        <div class="form-group col-md-3">
                                                            <label for="name">Name </label>
                                                            <input type="text" class="form-control " id="iaf_name"
                                                                name="iaf_name[]" placeholder="Name">
                                                        </div>
                                                        <div class="form-group col-md-3">
                                                            <label for="Certificate No. ">Certificate No.
                                                            </label>
                                                            <input type="text" class="form-control " id="iaf_cert_no"
                                                                name="iaf_cert_no[]" placeholder="Certificate No. ">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="State">Validity Period
                                                                from</label>
                                                            <input type="date" class="form-control "
                                                                id="iaf_valid_from" name="iaf_valid_from[]"
                                                                placeholder="Validity Period from">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="to">Validity Period to
                                                            </label>
                                                            <input type="date" class="form-control " id="iaf_valid_to"
                                                                name="iaf_valid_to[]" placeholder="Validity Period to">
                                                        </div>
                                                        <div class="form-group col-md-2 py-5">
                                                            <div class="float-right px-5">
                                                                <a href="javascript:void(0)" class="pull-right addRow"><i
                                                                        class="fa fa-plus-circle fa-2x"
                                                                        aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            </div>
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>3. Other Approval(s) from Government or Regulatory Bodies</b>
                                                </h5>
                                            </div>
                                            <div class="addOther col-lg-12">
                                                @php
                                                    $i = 1;
                                                @endphp
                                                @if ($govt_other_approvals->count() > 0)
                                                    <div class="row">
                                                        <div class="float-right col-lg-12 px-5 mb-5">
                                                            <a href="javascript:void(0)" class="pull-right float-right addRow"><i
                                                                    class="fa fa-plus-circle fa-2x"
                                                                    aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                    @foreach ($govt_other_approvals as $item)
                                                        <div class="row">
                                                            <input type='hidden' name='govt_other_approvals_id[]'
                                                                value="{{ @$item->id }}">
                                                            <div class="form-group col-md-3">
                                                                <label for="name">Name </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->other_name }}"
                                                                    id="govt_other_approvals_name"
                                                                    name="govt_other_approvals_name[]" placeholder="Name">
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Certificate No. ">Certificate No.
                                                                </label>
                                                                <input type="text" class="form-control "
                                                                    value="{{ $item->other_cert_no }}"
                                                                    id="govt_other_approvals_cert_no"
                                                                    name="govt_other_approvals_cert_no[]"
                                                                    placeholder="Certificate No. ">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="State">Validity Period
                                                                    from</label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->other_valid_from }}"
                                                                    id="govt_other_approvals_valid_from"
                                                                    name="govt_other_approvals_valid_from[]"
                                                                    placeholder="Validity Period from">
                                                            </div>
                                                            <div class="form-group col-md-2">
                                                                <label for="to">Validity Period to
                                                                </label>
                                                                <input type="date" class="form-control "
                                                                    value="{{ $item->other_valid_to }}"
                                                                    id="govt_other_approvals_valid_to"
                                                                    name="govt_other_approvals_valid_to[]"
                                                                    placeholder="Validity Period to">
                                                            </div>
                                                            <div class="form-group col-md-2 py-5">
                                                                <div class="float-right px-5">
                                                                    <a onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                        href="{{ url('delete/other-approvals/' . $item->id) }}"
                                                                        class='pull-right deleteRow'><i
                                                                            class="fa fa-2x fa-times text-danger"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="row">
                                                        <input type='hidden' name='govt_other_approvals_id[]'
                                                            value=''>
                                                        <div class="form-group col-md-3">
                                                            <label for="name">Name </label>
                                                            <input type="text" class="form-control "
                                                                id="govt_other_approvals_name"
                                                                name="govt_other_approvals_name[]" placeholder="Name">
                                                        </div>
                                                        <div class="form-group col-md-3">
                                                            <label for="Certificate No. ">Certificate No.
                                                            </label>
                                                            <input type="text" class="form-control "
                                                                id="govt_other_approvals_cert_no"
                                                                name="govt_other_approvals_cert_no[]"
                                                                placeholder="Certificate No. ">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="State">Validity Period
                                                                from</label>
                                                            <input type="date" class="form-control "
                                                                id="govt_other_approvals_valid_from"
                                                                name="govt_other_approvals_valid_from[]"
                                                                placeholder="Validity Period from">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <label for="to">Validity Period to
                                                            </label>
                                                            <input type="date" class="form-control "
                                                                id="govt_other_approvals_valid_to"
                                                                name="govt_other_approvals_valid_to[]"
                                                                placeholder="Validity Period to">
                                                        </div>
                                                        <div class="form-group col-md-2 py-5">
                                                            <div class="float-right px-5">
                                                                <a href="javascript:void(0)" class="pull-right addRow"><i
                                                                        class="fa fa-2x fa-plus-circle"
                                                                        aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            </div>
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>4. Other Activities</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label class=" mt-2" for="name">Other Activities within the Same
                                                    Legal Entity </label>
                                                <div class="">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                            placeholder="Other activities within the same legal entity"> --}}
                                                    <textarea class="form-control" id="other_activities" name="other_activities" rows="2"
                                                        placeholder="Other activities within the same legal entity" required>{{ @$other_information->other_activities }}</textarea>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label class=" mt-2" for="name">Related Organization(s), if any,
                                                    and their Activities </label>
                                                <div class="">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                            placeholder="Related Organization(s), if any, and their activities "> --}}
                                                    <textarea class="form-control" name="related_org" id="related_org" rows="2"
                                                        placeholder="Related Organization(s), if any, and their activities " required>{{ @$other_information->related_org }}</textarea>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label class=" mt-2" for="name">Major Clients</label>
                                                <div class="">
                                                    {{-- <input type="text" class="form-control" id="" name=""
                                                            placeholder="Major Clients"> --}}
                                                    <textarea class="form-control" name="major_clients" id="major_clients" rows="2" placeholder="Major Clients"
                                                        required>{{ @$other_information->major_clients }}</textarea>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label class=" mt-2" for="name">No. of Certificates Issued for
                                                    Applied Scope </label>
                                                <div class="">
                                                    <input type="number" min="0" class="form-control"
                                                        id="no_of_certificates"
                                                        value="{{ @$other_information->no_of_certificates }}"
                                                        name="no_of_certificates"
                                                        placeholder="No. of Certificates issued for applied scope"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-4">
                                                <label class="mt-2" for="name">Total No. of Certificates Issued
                                                </label>
                                                <div class="">
                                                    <input type="number" min="0" class="form-control"
                                                        id="total_certificate_issued"
                                                        value="{{ @$other_information->total_certificate_issued }}"
                                                        name="total_certificate_issued"
                                                        placeholder="Total No. of Certificates issued -" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 my-4">
                                                <div class="text-center">
                                                    <button type="submit" name="save_changes" id="save_changes"
                                                        class="btn btn-primary"><i class="bi bi-save2"></i> Save
                                                        Changes</button>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 pt-4">
                                                    <p><i class="bi bi-chevron-double-right"></i> <span
                                                            class="text-danger">*</span>
                                                        Asterisks(*) Fields are mandatory .
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection




@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#end_date').on('change', function() {

                var start_date = $('#start_date').val();
                // alert(start_date)
                var end_date = $('#end_date').val();
                if (end_date <= start_date) {
                    alert("Please ensure that the End Date is greater than or equal to the Start Date.");
                    document.getElementById("end_date").value = ' ';
                }
            });

            $('#iaf_valid_to').on('change', function() {
                var iaf_valid_from = $('#iaf_valid_from').val();
                var iaf_valid_to = $('#iaf_valid_to').val();
                if (iaf_valid_to < iaf_valid_from) {
                    alert("Please ensure that the End Date is greater than or equal to the Start Date.");
                    document.getElementById("iaf_valid_to").value = ' ';
                }
            });

            $('#govt_other_approvals_valid_to').on('change', function() {
                var govt_other_approvals_valid_from = $('#govt_other_approvals_valid_from').val();
                var govt_other_approvals_valid_to = $('#govt_other_approvals_valid_to').val();
                if (govt_other_approvals_valid_to < govt_other_approvals_valid_from) {
                    alert("Please ensure that the End Date is greater than or equal to the Start Date.");
                    document.getElementById("govt_other_approvals_valid_to").value = ' ';
                }
            });
        });
    </script>
    <script>
        $('.addNabcb').on('click', '.addRow', function() {
            var newrow = "<div id='remove'>" +
                "<div class='row'>" +
                "<input type='hidden' name='nabcb_id[]' value=''>" +
                "<div class='form-group col-md-3'>" +
                "<label for='name'>Name <span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='nabcb_name' name='nabcb_name[]' placeholder='Name' required>" +
                "</div>" +
                "<div class='form-group col-md-3'>" +
                "<label for='Certificate No.'>Certificate No.<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='nabcb_cert_no' name='nabcb_cert_no[]' placeholder='Certificate No.' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='State'>Validity Period from<span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='nabcb_valid_from' name='nabcb_valid_from[]' placeholder='Validity Period from' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='to'>Validity Period to <span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='nabcb_valid_to' name='nabcb_valid_to[]' placeholder='Validity Period to' required>" +
                "</div>" +
                "<div class='form-group col-md-2 py-5'>" +
                "<div class='float-right px-5'>" +
                "<a href='javascript:void(0)' class='pull-right deleteRow'><i class='fa fa-times fa-2x text-danger'></i> </a>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>"

            $('.addNabcb').append(newrow);
        });

        $('.addIaf').on('click', '.addRow', function() {
            var newrow = "<div id='remove'>" +
                "<div class='row'>" +
                "<input type='hidden' name='iaf_id[]' value=''>" +
                "<div class='form-group col-md-3'>" +
                "<label for='name'>Name <span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='iaf_name' name='iaf_name[]' placeholder='Name' required>" +
                "</div>" +
                "<div class='form-group col-md-3'>" +
                "<label for='Certificate No.'>Certificate No.<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='iaf_cert_no' name='iaf_cert_no[]' placeholder='Certificate No.' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='State'>Validity Period from<span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='iaf_valid_from' name='iaf_valid_from[]' placeholder='Validity Period from' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='to'>Validity Period to <span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='iaf_valid_to' name='iaf_valid_to[]' placeholder='Validity Period to' required>" +
                "</div>" +
                "<div class='form-group col-md-2 py-5'>" +
                "<div class='float-right px-5'>" +
                "<a href='javascript:void(0)' class='pull-right deleteRow'><i class='fa fa-times fa-2x text-danger'></i> </a>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>"

            $('.addIaf').append(newrow);
        });

        $('.addOther').on('click', '.addRow', function() {
            var newrow = "<div id='remove'>" +
                "<div class='row'>" +
                "<input type='hidden' name='govt_other_approvals_id[]' value=''>" +
                "<div class='form-group col-md-3'>" +
                "<label for='name'>Name <span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='govt_other_approvals_name' name='govt_other_approvals_name[]' placeholder='Name' required>" +
                "</div>" +
                "<div class='form-group col-md-3'>" +
                "<label for='Certificate No.'>Certificate No.<span class='text-danger'>*</span></label>" +
                "<input type='text' class='form-control' id='govt_other_approvals_cert_no' name='govt_other_approvals_cert_no[]' placeholder='Certificate No.' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='State'>Validity Period from<span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='govt_other_approvals_valid_from' name='govt_other_approvals_valid_from[]' placeholder='Validity Period from' required>" +
                "</div>" +
                "<div class='form-group col-md-2'>" +
                "<label for='to'>Validity Period to <span class='text-danger'>*</span></label>" +
                "<input type='date' class='form-control ' id='govt_other_approvals_valid_to' name='govt_other_approvals_valid_to[]' placeholder='Validity Period to' required>" +
                "</div>" +
                "<div class='form-group col-md-2 py-5'>" +
                "<div class='float-right px-5'>" +
                "<a href='javascript:void(0)' class='pull-right deleteRow'><i class='fa fa-times fa-2x text-danger'></i> </a>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>"

            $('.addOther').append(newrow);
        });

        $(document).on('click', '.deleteRow', function() {
            $(this).parents('#remove').remove();
        });
    </script>
@endsection
