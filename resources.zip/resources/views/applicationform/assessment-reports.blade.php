@extends('layouts.orgdashboard')
@section('content')
    <style>
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }

        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }

        .cb_remark {
            display: none;
        }
    </style>
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Assessment Report</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Assessment Report</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a href="{{ route('submitted.application',[$app_id]) }}" class="btn btn-dark"><i class="fa fa-arrow-left"></i> Go Back</a>
                        <div class="card ">
                            <h4 class="card-header d-flex justify-content-between align-items-center">
                                <b>Assessment Report</b>
                              </h4>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-bordered text-center" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center;">Document Name</th>
                                                <th style="text-align: center;">Document File</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($assessment_reports as $assessment_report)
                                                <tr>
                                                    <td>{{ $assessment_report->doc_name }}</td>
                                                    <td>
                                                        <a href="{{ url('public/assets/assessments') }}/{{ $assessment_report->doc_file }}" target="_blank">view</a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

