@extends('layouts.orgdashboard')
@section('content')
    <style>
        .new-location {
            display: none;
        }

        .addMore1 {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-block">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="page-header-title">
                                    <h5 class="m-b-10">Application Form</h5>
                                </div>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}"><i
                                                class="feather icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="#!">Application Form</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                @include('applicationform.tab-navigation')
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">
                                        <div class="row">
                                            @if (Session::has('success'))
                                                <div class="col-lg-12">
                                                    {{-- <p class="alert alert-success error">{{ Session('success') }}</p> --}}
                                                    <div class="alert alert-success alert-dismissible fade show"
                                                        role="alert">
                                                        <strong>Success!</strong> {{ Session('success') }}
                                                        <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    </div>
                                                </div>
                                            @endif
                                            @php
                                                $user_id = session('user_id');
                                                $stage = \App\ApplicationStatus::where('id', $app_id)
                                                    ->where('user_id', $user_id)
                                                    ->first();
                                            @endphp

                                            @if ($stage->stage == '1B')
                                                @php
                                                    $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)
                                                        ->where('scrutiny_for', 'PI')
                                                        ->where('isActive', 0)
                                                        ->first();
                                                    
                                                @endphp
                                                @if ($check_Adequcy->option == 'InAdequate')
                                                <div class="col-lg-12">
                                                    <div class="alert alert-danger" role="alert">
                                                        <h4 class="alert-heading"><b>Remark !</b></h4>
                                                        <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                            @endif
                                        </div>
                                        <form action="{{ route('create.personel_info') }}" method="POST" class="row">
                                            @csrf
                                            <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                            <div class="col-lg-12">
                                                <h5 style="background: antiquewhite; padding: 12px 10px;">
                                                    <b>1. Quality Manager or Management Representative</b>
                                                </h5>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Location">Quality Manager Name <span
                                                        class="text-danger">*</span></label>
                                                <input type="text"
                                                    class="form-control @error('quality_manager_name') is-invalid @enderror"
                                                    id="quality_manager_name" name="quality_manager_name"
                                                    value="{{ $personnel_infos ? $personnel_infos->quality_manager_name : '' }}"
                                                    placeholder="Quality Manager Name" required />
                                                @error('quality_manager_name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror

                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="Managerial Staff">Quality Manager Designation
                                                    <span class="text-danger">*</span></label>

                                                <input type="text"
                                                    class="form-control @error('quality_manager_designation') is-invalid @enderror"
                                                    id="quality_manager_designation" name="quality_manager_designation"
                                                    value="{{ $personnel_infos ? $personnel_infos->quality_manager_designation : '' }}"
                                                    placeholder="Quality Manager Designation" required />
                                                @error('quality_manager_designation')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror

                                            </div>
                                            <div class="col-lg-12">
                                                <h5 style="    background: antiquewhite; padding: 12px 10px;">
                                                    <b>2. Personnel for Voluntary Certification Scheme</b>
                                                </h5>
                                            </div>
                                            @if ($branch_address->count() > 0)
                                            <div class="col-lg-12">
                                                <h6>Scheme for Branch : <span class="text-primary">Main Office</span>
                                                </h6>
                                            </div>
                                                    <input type="hidden" name="branch_id[]"
                                                        value="{{ @$certification_scheme_main->branch_id }}" />
                                                    <input type="hidden" name="scheme_id[]"
                                                        value="{{ @$certification_scheme_main->id }}">
                                                    {{-- <div class="form-group col-md-4">
                                        <label for="Location">Location <span class="text-danger">*</span></label> --}}

                                                    <input type="hidden" class="form-control " id="location"
                                                        name="location[]" value="" placeholder="Location" required />

                                                    {{-- </div> --}}
                                                <div class="form-group col-md-4">
                                                    <label for="Managerial Staff">Managerial
                                                        Staff <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control txtCal" id="managerial_staff"
                                                        name="managerial_staff[]"
                                                        value="{{ @$certification_scheme_main->managerial_staff }}"
                                                        placeholder="Managerial Staff" required>

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Evaluators">Evaluators
                                                        <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control txtCal" id="evaluators"
                                                        name="evaluators[]"
                                                        value="{{ @$certification_scheme_main->evaluators }}"
                                                        placeholder="Evaluators" required />

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Support Staff">Support
                                                        Staff <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control txtCal" id="support_staff"
                                                        name="support_staff[]"
                                                        value="{{ @$certification_scheme_main->support_staff }}"
                                                        placeholder="Support Staff " required />

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Technical experts">Technical
                                                        experts <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control txtCal"
                                                        id="technical_experts" name="technical_experts[]"
                                                        value="{{ @$certification_scheme_main->technical_experts }}"
                                                        placeholder="Technical experts" required />

                                                </div>
                                                {{-- <div class="form-group col-md-4">
                                                    <label for="Total ">Total</label>
                                                    <br />
                                                    <input type="number" min="0" class="form-control "
                                                        id="total" name="total[]"
                                                        value="{{ @$certification_scheme_main->total }}"
                                                        placeholder="Total" required />
                                                </div> --}}
                                                @for ($i = 0; $i < $branch_address->count(); $i++)
                                                <div class="col-lg-12">
                                                    <h6>Scheme for Branch : <span class="text-primary">{{ $branch_address[$i]->branch_name }}</span></h6>
                                                </div>
                                                    <input type="hidden" name="branch_id[]"
                                                        value="{{ @$branch_address[$i]->id }}" />
                                                    <input type="hidden" name="scheme_id[]"
                                                        value="{{ @$certification_scheme[$i]->id }}">
                                                    {{-- <div class="form-group col-md-4">
                                                <label for="Location">Location <span class="text-danger">*</span></label> --}}

                                                    <input type="hidden" class="form-control " id="location"
                                                        name="location[]"
                                                        value="{{ @$certification_scheme[$i]->location }}"
                                                        placeholder="Location" required />
                                                    {{-- </div> --}}
                                                    <div class="form-group col-md-4">
                                                        <label for="Managerial Staff">Managerial
                                                            Staff <span class="text-danger">*</span></label>

                                                        <input type="number" class="form-control txtCal1"
                                                            id="managerial_staff" name="managerial_staff[]"
                                                            value="{{ @$certification_scheme[$i]->managerial_staff }}"
                                                            placeholder="Managerial Staff" required>

                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="Evaluators">Evaluators
                                                            <span class="text-danger">*</span></label>

                                                        <input type="number" class="form-control txtCal1"
                                                            id="evaluators" name="evaluators[]"
                                                            value="{{ @$certification_scheme[$i]->evaluators }}"
                                                            placeholder="Evaluators" required />

                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="Support Staff">Support
                                                            Staff <span class="text-danger">*</span></label>

                                                        <input type="number" class="form-control txtCal1"
                                                            id="support_staff" name="support_staff[]"
                                                            value="{{ @$certification_scheme[$i]->support_staff }}"
                                                            placeholder="Support Staff " required />

                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="Technical experts">Technical
                                                            experts <span class="text-danger">*</span></label>

                                                        <input type="number" class="form-control txtCal1"
                                                            id="technical_experts" name="technical_experts[]"
                                                            value="{{ @$certification_scheme[$i]->technical_experts }}"
                                                            placeholder="Technical experts" required />

                                                    </div>
                                                    {{-- <div class="form-group col-md-4">
                                                        <label for="Total ">Total</label><br />
                                                        <input type="number" min="0" class="form-control "
                                                            id="total" name="total[]"
                                                            value="{{ @$certification_scheme[$i]->total }}"
                                                            placeholder="Total" required />
                                                    </div> --}}
                                                @endfor
                                            @else
                                            <div class="col-lg-12">
                                                <h6>Scheme for Branch : <span class="text-primary">Office</span></h6>
                                            </div>
                                                    <input type="hidden" name="branch_id[]"
                                                        value="{{ @$certification_scheme_main->branch_id }}" />
                                                    <input type="hidden" name="scheme_id[]"
                                                        value="{{ @$certification_scheme_main->id }}">
                                                    {{-- <div class="form-group col-md-4">
                                        <label for="Location">Location <span class="text-danger">*</span></label> --}}

                                                    <input type="hidden" class="form-control " id="location"
                                                        name="location[]" value="" placeholder="Location"
                                                        required />

                                                    {{-- </div> --}}
                                                <div class="form-group col-md-4">
                                                    <label for="Managerial Staff">Managerial
                                                        Staff <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control" id="managerial_staff"
                                                        name="managerial_staff[]"
                                                        value="{{ @$certification_scheme_main->managerial_staff }}"
                                                        placeholder="Managerial Staff" required>

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Evaluators">Evaluators
                                                        <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control " id="evaluators"
                                                        name="evaluators[]"
                                                        value="{{ @$certification_scheme_main->evaluators }}"
                                                        placeholder="Evaluators" required />

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Support Staff">Support
                                                        Staff <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control " id="support_staff"
                                                        name="support_staff[]"
                                                        value="{{ @$certification_scheme_main->support_staff }}"
                                                        placeholder="Support Staff " required />

                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label for="Technical experts">Technical
                                                        experts <span class="text-danger">*</span></label>

                                                    <input type="number" class="form-control " id="technical_experts"
                                                        name="technical_experts[]"
                                                        value="{{ @$certification_scheme_main->technical_experts }}"
                                                        placeholder="Technical experts" required />

                                                </div>
                                                {{-- <div class="form-group col-md-4">
                                                    <label for="Total ">Total</label><br />
                                                    <input type="number" min="0" class="form-control "
                                                        id="total" name="total[]"
                                                        value="{{ @$certification_scheme_main->total }}"
                                                        placeholder="Total" required />
                                                </div> --}}
                                            @endif
                                            <div class="col-lg-12 my-4">
                                                <div class="text-center">
                                                    <button type="submit" name="save_changes" id="save_changes"
                                                        class="btn btn-primary"><i class="bi bi-save2"></i> Save
                                                        Changes</button>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 pt-4">
                                                    <p><i class="bi bi-chevron-double-right"></i> <span
                                                            class="text-danger">*</span>
                                                        Asterisks(*) Fields are mandatory .
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $("#technical_experts").on("keyup", function() {
                var a = parseInt($('#managerial_staff').val());
                var b = parseInt($('#evaluators').val());
                var c = parseInt($('#support_staff').val());
                var d = parseInt($('#technical_experts').val());
                var sum = a + b + c + d;
                console.log(sum);
                // alert(sum);
            })
        })
        // $(document).ready(function() {
        //     $("#addnew").click(function() {
        //         // alert('ok');
        //         // $('#addnewform').modal('show');
        //             $('#personnel-form').trigger("reset");
        //             $('#Heading').html("Add New Record");
        //             $('#myModal').modal('show');
        //         });

        //     });
        // $(document).ready(function() {
        //     $(".txtCal").on('input', function() {
        //         var calculated_total_sum = 0;

        //         $(".txtCal").each(function() {
        //             var get_textbox_value = $(this).val();
        //             if ($.isNumeric(get_textbox_value)) {
        //                 calculated_total_sum += parseFloat(get_textbox_value);
        //                 console.log(calculated_total_sum);
        //             }
        //         });
        //         $("#total_sum_value").html(calculated_total_sum);
        //     });

        //     $(".txtCal1").on('input', function() {
        //         var calculated_total_sum = 0;

        //         $(".txtCal1").each(function() {
        //             var get_textbox_value = $(this).val();
        //             // alert(get_textbox_value);
        //             if ($.isNumeric(get_textbox_value)) {
        //                 calculated_total_sum += parseFloat(get_textbox_value);
        //                 console.log(calculated_total_sum);
        //             }
        //         });
        //         $("#total_sum").html(calculated_total_sum);
        //     });
        // });
    </script>
    @if (Session::has('success'))
        <script>
            swal("Great Job!", "{!! Session('success') !!}", "success", {
                button: "OK",
            })
        </script>
    @endif
@endsection
