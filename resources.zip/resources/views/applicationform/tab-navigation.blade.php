<style>
    .nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link {
    color: #ffffff;
    background-color: #4680ff;
    border-color: #dee2e6 #dee2e6 #fff;
}
</style>
<ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
    @php
        $user_id = session('user_id');
        $stage = \App\ApplicationStatus::where('user_id',$user_id)->where('id', $app_id)->first();
    @endphp
    @if ($stage->stage == '1B')
        @php
            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'GI')->where('isActive',0)->first();
        @endphp
        @if (@$check_Adequcy->option == 'InAdequate')
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('general.information',[$app_id]) }}" >General Information</a>
        </li>
        {{-- <li class="active"><a href="{{ route('general.information',[$app_id]) }}">General Information</a></li> --}}
        @endif
        @php
            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'PI')->where('isActive',0)->first();
        @endphp
        @if (@$check_Adequcy->option == 'InAdequate')
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('personnel.Information',[$app_id]) }}" >Personnel Information</a>
        </li>
        {{-- <li class="active"><a href="{{ route('personnel.Information',[$app_id]) }}">Personnel Information</a></li> --}}
        @endif
        @php
            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'OI')->where('isActive',0)->first();
        @endphp
        @if (@$check_Adequcy->option == 'InAdequate')
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('other.info',[$app_id]) }}" >Other Information</a>
        </li>
        {{-- <li  class="active"><a href="{{ route('other.info',[$app_id]) }}">Other Information</a></li> --}}
        @endif
        @php
            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'FI')->where('isActive',0)->first();
        @endphp
        @if (@$check_Adequcy->option == 'InAdequate')
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('financialinfo',[$app_id]) }}" >Financial Performance</a>
        </li>
        {{-- <li class="active"><a href="{{ route('financialinfo',[$app_id]) }}">Financial Performance</a></li> --}}
        @endif
        @php
            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'AI')->where('isActive',0)->first();
        @endphp
        @if (@$check_Adequcy->option == 'InAdequate')
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('annexed.information',[$app_id]) }}" >Annexed Information</a>
        </li>
        {{-- <li class="active"><a href="{{ route('annexed.information',[$app_id]) }}">Annexed Information</a></li> --}}
        @endif
        <li class="nav-item">
            <a class="nav-link active text-uppercase" href="{{ route('sendback',[$app_id]) }}" >Send Back</a>
        </li>
        {{-- <li><a href="{{ route('sendback',[$app_id]) }}">Send Back</a></li> --}}
    @else
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'application-form'?'active':'' }} text-uppercase" href="{{ route('general.information',[$app_id]) }}" >General Information</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'personnel-information'?'active':'' }} text-uppercase" href="{{ route('personnel.Information',[$app_id]) }}" >Personnel Information</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'other-information'?'active':'' }} text-uppercase" href="{{ route('other.info',[$app_id]) }}" >Other Information</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'financial-performance'?'active':'' }} text-uppercase" href="{{ route('financialinfo',[$app_id]) }}" >Financial Performance</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'annexed-information'?'active':'' }} text-uppercase" href="{{ route('annexed.information',[$app_id]) }}" >Annexed Information</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Request::segment(1) == 'declaration'?'active':'' }} text-uppercase" href="{{ route('declaration',[$app_id]) }}" >Declaration</a>
    </li>
    {{-- <li class="{{ Request::segment(1) == 'application-form'?'active':'' }}">
        <a href="{{ route('general.information',[$app_id]) }}">General Information</a>
    </li> --}}
    {{-- <li class="{{ Request::segment(1) == 'personnel-information'?'active':'' }}"><a href="{{ route('personnel.Information',[$app_id]) }}">Personnel Information</a></li> --}}
    {{-- <li class="{{ Request::segment(1) == 'other-information'?'active':'' }}"><a href="{{ route('other.info',[$app_id]) }}">Other Information</a></li>
    <li class="{{ Request::segment(1) == 'financial-performance'?'active':'' }}"><a href="{{ route('financialinfo',[$app_id]) }}">Financial Performance</a></li> --}}
    {{-- <li class="{{ Request::segment(1) == 'annexed-information'?'active':'' }}"><a href="{{ route('annexed.information',[$app_id]) }}">Annexed Information</a></li>
    <li class="{{ Request::segment(1) == 'declaration'?'active':'' }}"><a href="{{ route('declaration',[$app_id]) }}">Declaration</a></li> --}}
    @endif 
</ul>
