@extends('layouts.admin')
@section('content')
    <section id="contact" class="contact mt-2">
        <div class="container mt-2" data-aos="fade-down">
            
            <div class="row">
                @include('applicationform.tab-navigation')
                <div class="container" data-aos="fade-down">
                    <div class="row">
                        <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" style="padding: 0px;">
                            <form action="{{ route('annexed.store') }}" method="post" role="form" class="php-email-form"
                                style="border-top:none; box-shadow:0 24px 24px 0 rgb(0 0 0 / 12%);" enctype="multipart/form-data">
                                @csrf
                                {{-- <h2 class="text-center pt-5">Annexed Information</h2>
                                <p class="text-center">(upload documents)</p> --}}
                                @if (Session::has('success'))
                                    <p class="text-success error">{{ Session('success') }}</p>
                                @endif
                                <div class="row">
                                    @php
                                        $user_id = session('user_id');
                                        $stage = \App\ApplicationStatus::where('user_id', $user_id)->first();
                                    @endphp
    
                                    @if ($stage->stage == '1B')
                                        @php
                                            $check_Adequcy = \App\AppScrutiny::where('org_id', $user_id)
                                                ->where('scrutiny_for', 'AI')
                                                ->where('isActive', 0)
                                                ->first();
                                                
                                        @endphp
                                        @if ($check_Adequcy->option == 'InAdequate')
                                        <div class="alert alert-danger" role="alert">
                                            <h4 class="alert-heading"><b>Remark !</b></h4>
                                            <p><b>*</b> {{ $check_Adequcy->remark }}</p>
                                            {{-- <hr> --}}
                                            {{-- <p class="mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p> --}}
                                          </div>
                                        @endif
                                    @endif
                                </div>
                                <div class="form-group">
                                    <h5 style="background: antiquewhite; padding: 12px 10px;"><b> Required documents for upload
                                        </b>
                                    </h5>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">1. Organization Registration
                                            Certificate & Memorandum /
                                            Articles of Association (copy only) <span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-4">
                                            <input type="file" class="form-control" id="org_reg_cert" name="org_reg_cert" {{ @$annexed_informations->org_reg_cert?'':'required' }}>
                                            <input type="hidden" class="form-control" id="org_reg_cert" name="old_org_reg_cert" value="{{ @$annexed_informations->org_reg_cert }}">
                                        </div>
                                        @error('org_reg_cert')
                                            <div class="text-danger">{{ $message }}</div>
                                        @enderror
                                        <div class="col-md-2">
                                            {{-- <a href=""><i class="fa fa-trash text-danger" aria-hidden="true"></i></a> --}}
                                            @if (@$annexed_informations->org_reg_cert != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->org_reg_cert }}" class="text-primary" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">2. Master List of Documents
                                            reference of
                                            voluntary certification scheme (with issue and/or revision status)
                                            <span class="text-danger">*</span></label>

                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="ref_of_vol" name="ref_of_vol" {{ @$annexed_informations->ref_of_vol?'':'required' }}>
                                            <input type="hidden" class="form-control " id="ref_of_vol" name="old_ref_of_vol" value="{{ @$annexed_informations->ref_of_vol }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->ref_of_vol != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->ref_of_vol }}" target="_blank"><i class="fa fa-eye"></i> view</a> &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">3. Quality Manual by
                                            applicable
                                            accreditation standard
                                            i.e. ISO/IEC 17065, ISO/IEC 17021,ISO/IEC17024 etc.<span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="applicable_acc_stand" name="applicable_acc_stand" {{ @$annexed_informations->applicable_acc_stand?'':'required' }}>
                                            <input type="hidden" class="form-control " id="applicable_acc_stand" name="old_applicable_acc_stand" value="{{ @$annexed_informations->applicable_acc_stand }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->applicable_acc_stand != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->applicable_acc_stand }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">4. Documentation relating to
                                            voluntary certification scheme
                                            (Procedures, Competence Criteria, Formats, Checklists etc.) <span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="related_to_vol" name="related_to_vol" {{ @$annexed_informations->related_to_vol?'':'required' }}>
                                            <input type="hidden" class="form-control " id="related_to_vol" name="old_related_to_vol" value="{{ @$annexed_informations->related_to_vol }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->related_to_vol != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->related_to_vol }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">5. Branch Office(s) with
                                            activities to be covered
                                            under approval (list per format in Table – A) <span
                                                class="text-danger">*</span> &nbsp;   &nbsp; <a href="{{ url('/assets/Table-A.docx') }}" target="_blank">Sample Format</a> <br /> &nbsp;</label>

                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="branch_activity" name="branch_activity" {{ @$annexed_informations->branch_activity?'':'required' }}>
                                            <input type="hidden" class="form-control " id="branch_activity" name="old_branch_activity" value="{{ @$annexed_informations->branch_activity }}">
                                            
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->branch_activity != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->branch_activity }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">6. List of Managerial Personnel,
                                            Auditors &
                                            Technical Experts (list as per format in Table – B)<span
                                                class="text-danger">*</span> &nbsp;  &nbsp; <a href="{{ url('/assets/Table-B.docx') }}" target="_blank">Sample Format</a> </label>
                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="list_of_experts" name="list_of_experts" {{ @$annexed_informations->list_of_experts?'':'required' }}>
                                            <input type="hidden" class="form-control " id="list_of_experts" name="old_list_of_experts" value="{{ @$annexed_informations->list_of_experts }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->list_of_experts != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->list_of_experts }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                {{-- <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">7. Application Fee - Amount,
                                            Cheque / DD No., Date: <span class="text-danger">*</span></label>

                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="" name="">
                                        </div>
                                        <div class="col-md-2"></div>
                                    </div>
                                </div> --}}
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">7. Other Documents (annex
                                            list)</label>

                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="other_cert" name="other_cert" {{ @$annexed_informations->other_cert?'':'' }}>
                                            <input type="hidden" class="form-control " id="other_cert" name="old_other_cert" value="{{ @$annexed_informations->other_cert }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->other_cert != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->other_cert }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">8. Reference of any voluntary
                                            certification scheme<br />
                                        </label>
                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="ref_of_any_vol" name="ref_of_any_vol" {{ @$annexed_informations->ref_of_any_vol?'':'' }}>
                                            <input type="hidden" class="form-control " id="ref_of_any_vol" name="old_ref_of_any_vol" value="{{ @$annexed_informations->ref_of_any_vol }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->ref_of_any_vol != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->ref_of_any_vol }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group py-3">
                                        <label class="col-md-6" for="Name">Any other relevant
                                            information </label>

                                        <div class="col-md-4">
                                            <input type="file" class="form-control " id="any_other_rel" name="any_other_rel" {{ @$annexed_informations->any_other_rel?'':'' }}>
                                            <input type="hidden" class="form-control " id="any_other_rel" name="old_any_other_rel" value="{{ @$annexed_informations->any_other_rel }}">
                                        </div>
                                        <div class="col-md-2">
                                            @if (@$annexed_informations->any_other_rel != '')
                                                <a href="{{ url('public/assets/images/annexed') }}/{{ $annexed_informations->any_other_rel }}" target="_blank"><i class="fa fa-eye"></i> view</a>  &nbsp; 
                                                {{-- <a href="#" class="text-success"><i class="fa fa-cloud-download " aria-hidden="true"></i> download</a> --}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="text-center py-5">
                                        {{-- <button type="submit" class="btn btn-sm btn-warning"
                                            style="color: antiquewhite; background-color:tomato"><i
                                                class="bi bi-arrow-left"></i> Previous</button> --}}
                                        <button type="submit" class="btn btn-sm"><i
                                                class="bi bi-save2"></i> Save Changes
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
