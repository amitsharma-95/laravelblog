<!DOCTYPE html>
<html lang="en">

<head>

    <title>@yield('title', 'Admin Dashboard')</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Phoenixcoded" />
    <!-- Favicon icon -->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">

    <!-- vendor css -->
    <link rel="stylesheet" href="{{ asset('admin') }}/assets/css/style.css">

</head>

<div class="auth-wrapper">
    <div class="auth-content">
        <div class="card">
            <div class="row align-items-center text-center">
                <div class="col-md-12">
                    <div class="card-body">
                        <form action="{{ route('admin.login') }}" method="POST">
                            @csrf
                            <img src="{{ asset('admin') }}/assets/images/QCI-Logo.png" alt="" class="img-fluid mb-4">
                            <h4 class="mb-3 f-w-400">Admin Login</h4>
                            <div class="form-group mb-3">
                                <label class="floating-label" for="username">Username</label>
                                <input type="text" class="form-control" name="username" id="username" placeholder="">
                                @if ($errors->has('username'))
                                    <span class="alert alert-danger">* {{ $errors->first('username') }}</span>
                                @endif
                            </div>
                            <div class="form-group mb-4">
                                <label class="floating-label" for="Password">Password</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="">
                                @if ($errors->has('password'))
                                    <span class="alert alert-danger">* {{ $errors->first('password') }}</span>
                                @endif
                            </div>
                            <div class="custom-control custom-checkbox text-left mb-4 mt-2">
                                <input type="checkbox" class="custom-control-input" id="customCheck1">
                                <label class="custom-control-label" for="customCheck1">Save credentials.</label>
                            </div>
                            <button type="submit" class="btn btn-block btn-primary mb-4">Signin</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Required Js -->
<script src="{{ asset('admin') }}/assets/js/vendor-all.min.js"></script>
<script src="{{ asset('admin') }}/assets/js/plugins/bootstrap.min.js"></script>
<script src="{{ asset('admin') }}/assets/js/ripple.js"></script>
<script src="{{ asset('admin') }}/assets/js/pcoded.min.js"></script>
</body>

</html>
