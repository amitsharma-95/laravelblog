@extends('layouts.adminback')
@section('content')
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Allotment of User</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Allotment</a></li>
                                <li class="breadcrumb-item"><a href="#!">Allotment of User</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card user-profile-list">
                        <h5 class="card-header text-center">
                            Allotment of Dealing Officer
                            <a href="{{ route('allotment') }}" class="btn btn-warning btn-sm float-right">back</a>
                        </h5>
                        <div class="card-body my-2">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            <form action="{{ route('allotment.user') }}" method="POST" id="userForm">
                                @csrf
                                <input type="hidden" name="org_id" id="org_id" value="{{ $org_id }}">
                                <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                <input type="hidden" name="alloted_by" id="alloted_by"  value="{{ $alloted_by }}">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Select User</label>
                                            <select class="form-control" name="alloted_to" id="alloted_to" style="width:100%"
                                                required>
                                                <option value="" selected>Select User for Allotment</option>
                                                @foreach ($role_users as $user)
                                                    <option value="{{ $user->id }}" style="z-index: 9999;">
                                                        {{ $user->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-12">
                                        <button type="submit" name="submit" class="btn btn-primary" id="SaveBtn"> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
