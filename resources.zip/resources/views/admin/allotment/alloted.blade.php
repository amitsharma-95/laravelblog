@extends('layouts.adminback')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Alloted Application</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Alloted Applications</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    {{-- <div class="card user-profile-list"> --}}
                    <div class="card">
                        <h5 class="card-header">
                            Alloted Applications 
                            <a href="{{ route('allotment') }}" class="btn btn-dark float-right has-ripple"><i class="feather icon-arrow-left"></i> Back</a>
                        </h5>
                        <div class="card-body">
                            {{-- <div class="row">
                                <div class="col-md-8 offset-md-2 text-center">
                                    <a href="{{ route('alloted') }}" class="btn btn-success has-ripple"><i class="feather mr-2 icon-check-circle"></i> Allotted</a>
                                    <a href="{{ route('not.alloted') }}" class="btn btn-warning has-ripple"><i class="feather mr-2 icon-alert-triangle"></i> Not Allotted</a>
                                </div>
                            </div> --}}
                            <div class="dt-responsive table-responsive">
                                <table id="example"  class="table nowrap table-striped table-bordered"  style="width:100%">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%">S.No.</th>
                                            <th style="width: 5%">Username</th>
                                            <th>Org Name</th>
                                            <th>Scheme</th>
                                            <th>Level</th>
                                            <th style="width: 5%">DO</th>
                                            <th style="width: 5%">Preview</th>
                                            <th style="width: 7%">inserted At</th>
                                            <th style="width: 7%">Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot style="display: table-header-group">
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Username</th>
                                            <th>Org Name</th>
                                            <th>Scheme</th>
                                            <th>Level</th>
                                            <th>DO</th>
                                            <th>Preview</th>
                                            <th>inserted At</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        @php
                                            $i =1;
                                        @endphp
                                        @foreach ($applications as $item)
                                        @php
                                            $admin = Session('Admin');
                                            $user = \App\User::where('id',$item->user_id)->first();
                                            @$alloted = \App\AppUserAllotment::where('org_id', $item->user_id)->where('app_id', $item->id)->where('alloted_by', $admin)->where('isActive',0)->first();
                                            @$dealing_officer = \App\AdminUser::where('id', $alloted->alloted_to)->first();
                                            $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                        @endphp
                                            <tr>
                                                <td><div class="handsontable">{{ $i }}</div></td>
                                                <td><div class="handsontable">{{ $user->username }}</div></td>
                                                <td><div class="handsontable">{{ $user->org_name }}</div></td>
                                                <td><div class="handsontable">{{ $scheme->scheme_name }}</div></td>
                                                <td><div class="handsontable">{{ $item->level }}</div></td>
                                                <td><div class="handsontable">{{ @$dealing_officer->name }}</div></td>
                                                <td><div class="handsontable">
                                                    <a class="text-success" href="{{ route('adminapplication.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                <td><div class="handsontable">{{ $item->created_at }}</div></td>
                                                <td>                                                    
                                                {{-- <div class="overlay-edit"> --}}
                                                    @if ($alloted == null)
                                                    <a href="{{ route('allotments', [$item->id]) }}" 
                                                        class="btn btn-icon btn-warning edit allotmentUser handsontable" data-toggle="tooltip" data-placement="top" title="" data-original-title="Allot Dealing Office">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                    @else
                                                        <span class="badge badge-light-success handsontable">Dealing Office Alloted</span>
                                                    @endif
                                                    {{-- <a href="javascript:void(0)" data-toggle="tooltip"
                                                        data-id="{{ $item->id }}" data-original-title="allotment"
                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a> --}}
                                                    {{-- </div> --}}
                                                {{-- </div> --}}
                                            </td>
                                            </tr>
                                            @php
                                                $i++;
                                            @endphp
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg show" id="userAllotmentModel" aria-hidden="true">>
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userAllotmentHeading"> Allotment of Dealing Officer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="editContent">
                <form action="#" method="POST" id="userForm">
                    {{-- @csrf --}}
                    <input type="hidden" name="id" id="id">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="user" style="color: #080d19;font-weight: 600;">Select User</label>
                                <select class="form-control" name="user" id="user" style="width:100%" required>
                                    <option value="" selected>Select User for Allotment</option>
                                    @foreach ($role_users as $user)
                                        <option value="{{ $user->id }}" id="" style="z-index: 9999;">
                                            {{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary" id="SaveBtn"> Save </button>
                </form>
                </div>
            </div>
        </div> 
    </div>
@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });
            //popup
            // $('body').on('click', '.allotmentUser', function() {
            //     var id = $(this).data('id');
            //     $('#userAllotmentModel').modal('show');

            // });
        });
    </script>
@endsection
