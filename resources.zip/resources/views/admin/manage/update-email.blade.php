@extends('layouts.adminback')
@section('content')
    
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Email List</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Email</a></li>
                                <li class="breadcrumb-item"><a href="#!">Email list</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="card user-profile-list">
                        <h5 class="card-header">
                            Update Email Body
                            <a href="{{ route('manage.email') }}" class="btn btn-dark btn-sm float-right"><i class="feather icon-arrow-left"></i> Go Back</a>
                        </h5>
                        <div class="card-body">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            <form action="{{ route('edit.mail') }}" method="POST" id="userForm">
                                @csrf
                                <input type="hidden" name="id" value="{{ $mail->id }}">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group fill">
                                            <label class="floating-label" for="template_name">Template Name</label>
                                            <input type="text" class="form-control @error('template_name') is-invalid @enderror" name="template_name"
                                                id="template_name" value="{{ $mail->template_name }}" placeholder="Template Name">
                                            @error('template_name')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group fill">
                                            <label class="floating-label" for="subject">Subject</label>
                                            <input type="text" class="form-control @error('subject') is-invalid @enderror"
                                                name="subject" value="{{ $mail->subject }}" id="subject" placeholder="Subject">
                                            @error('subject')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group fill">
                                            <label class="floating-label" for="mail_from">Mail From</label>
                                            <input type="text" class="form-control @error('mail_from') is-invalid @enderror"
                                                name="mail_from" value="{{ $mail->mail_from }}" id="mail_from" placeholder="Mail From">
                                            @error('mail_from')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group fill">
                                            <label class="floating-label" for="sender_name">Sender Name</label>
                                            <input type="text" class="form-control @error('sender_name') is-invalid @enderror"
                                                name="sender_name" value="{{ $mail->sender_name }}" id="sender_name" placeholder="Sender Name">
                                            @error('sender_name')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group fill">
                                            <label class="floating-label" for="body">Body</label>
                                            {{-- <input type="text"
                                                class="form-control @error('body') is-invalid @enderror"
                                                placeholder="Mail Body" value="{{ $mail->body }}" name="body" required> --}}
                                                <textarea  class="form-control @error('body') is-invalid @enderror" name="body" id="body" cols="30" rows="3" placeholder="Mail Body" required>{{ $mail->body }}</textarea>
                                            @error('body')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Update  </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>

@endsection