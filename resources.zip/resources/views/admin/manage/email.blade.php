@extends('layouts.adminback')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Email List</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Email</a></li>
                                <li class="breadcrumb-item"><a href="#!">Email list</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card ">
                        <div class="card-body">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            <div class="dt-responsive table-responsive">
                                <table id="user-list-table" class="table nowrap table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Template Name</th>
                                            <th>Subject</th>
                                            <th>From</th>
                                            <th>Body</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($emails as $email)
                                            <tr>
                                                <td><div class="handsontable"> {{ $email->template_name }}</div></td>
                                                <td><div class="handsontable"> {{ $email->subject }}</div></td>
                                                <td><div class="handsontable"> {{ $email->mail_from }}</div></td>
                                                <td><div class="handsontable"> {{ $email->body }}</div></td>
                                                <td>
                                                    <span
                                                        class="badge badge-light-{{ $email->isActive == 0 ? 'success' : 'danger' }}">{{ $email->isActive == 0 ? 'Active' : 'DeActive' }}</span>
                                                    <div class="overlay-edit">
                                                        {{-- <button type="button" class="btn btn-icon btn-success"><i
                                                                class="feather icon-check-circle"></i></button> --}}
                                                        {{-- <a href="javascript:void(0)" data-toggle="tooltip"
                                                            data-id="{{ $email->id }}" data-original-title="Edit"
                                                            class="btn btn-icon btn-success edit editemail">
                                                            <i class="feather icon-check-circle"></i></a> --}}
                                                            <a href="{{ route('update.email',[$email->id]) }}" class="btn btn-icon btn-success edit editemail" data-toggle="tooltip" data-original-title="Edit"><i class="feather icon-check-circle"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>

    {{-- <div class="modal fade bd-example-modal-lg show" id="userModel" aria-hidden="true">>
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userHeading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="editContent">
                    <form action="{{ route('edit.mail') }}" method="POST" id="userForm">
                        @csrf
                        <input type="hidden" name="id" value="{{ $mail->id }}">
                    
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group fill">
                                    <label class="floating-label" for="template_name">Template Name</label>
                                    <input type="text" class="form-control @error('template_name') is-invalid @enderror" name="template_name"
                                        id="template_name" value="{{ $mail->template_name }}" placeholder="Template Name">
                                    @error('template_name')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group fill">
                                    <label class="floating-label" for="subject">Subject</label>
                                    <input type="text" class="form-control @error('subject') is-invalid @enderror"
                                        name="subject" value="{{ $mail->subject }}" id="subject" placeholder="Subject">
                                    @error('subject')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group fill">
                                    <label class="floating-label" for="mail_from">Mail From</label>
                                    <input type="number" class="form-control @error('mail_from') is-invalid @enderror"
                                        name="mail_from" value="{{ $mail->mail_from }}" id="mail_from" placeholder="Mail From">
                                    @error('mail_from')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group fill">
                                    <label class="floating-label" for="sender_name">Sender Name</label>
                                    <input type="text" class="form-control @error('sender_name') is-invalid @enderror"
                                        name="sender_name" value="{{ $mail->sender_name }}" id="sender_name" placeholder="Sender Name">
                                    @error('sender_name')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group fill">
                                    <label class="floating-label" for="body">Body</label>
                                    <input type="text"
                                        class="form-control @error('body') is-invalid @enderror"
                                        placeholder="Mail Body" value="{{ $mail->body }}" name="body" required>
                                    @error('body')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Update  </button>
                    </form>
                </div>
            </div>
        </div>
    </div> --}}
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();

            // $('body').on('click', '.editemail', function() {
            //     var id = $(this).data('id');
            //     $.get("{{ url('admin/mail') }}" + '/' + id + '/edit', function(data) {
            //         $('#editContent').html(data.html);
            //         $('#userHeading').html("Edit Email Template");
            //         $('#userModel').modal('show');
            //     });
            // });

        });
    </script>
@endsection
