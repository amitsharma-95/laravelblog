@extends('layouts.adminback')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Applicant Details</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                {{-- <li class="breadcrumb-item"><a href="#!">user</a></li> --}}
                                <li class="breadcrumb-item"><a href="#!">Applicant Details</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="dt-responsive table-responsive">
                                    {{-- <table id="example"  class="table nowrap"  style="width:100%"> --}}
                                        <table id="example" class="table nowrap table-striped table-bordered"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th><div class="handsontable">S.no.</div></th>
                                                <th><div class="handsontable">Username</div></th>
                                                <th><div class="handsontable">Application Number</div></th>
                                                <th><div class="handsontable">Org Name</div></th>
                                                <th><div class="handsontable">Scheme</div></th>
                                                <th><div class="handsontable">Level</div></th>
                                                {{-- <th><div class="handsontable">Status</th></div> --}}
                                                <th><div class="handsontable">Preview</div></th>
                                                <th><div class="handsontable">Registered At</div></th>
                                                {{-- <th>Application Fee</th>
                                                <th>Next Action</th> --}}
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th><div class="handsontable">S.no.</div></th>
                                                <th><div class="handsontable">Username</div></th>
                                                <th><div class="handsontable">Application Number</div></th>
                                                <th><div class="handsontable">Org Name</div></th>
                                                <th><div class="handsontable">Scheme</div></th>
                                                <th><div class="handsontable">Level</div></th>
                                                {{-- <th><div class="handsontable">Status</th></div> --}}
                                                <th><div class="handsontable">Preview</div></th>
                                                <th><div class="handsontable">Registered At</div></th>
                                                {{-- <th>Application Fee</th>
                                                <th>Next Action</th> --}}
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @php
                                                $i =1;
                                            @endphp
                                            @foreach ($applications as $item)
                                            @php
                                                $user = \App\User::where('id',$item->user_id)->first() ;
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                            @endphp
                                                <tr>
                                                    <td>{{ $i }}</td>
                                                    <td><div class="handsontable">{{ $user->username }}</div></td>
                                                    <td><div class="handsontable">{{ $item->application_no }}</div></td>
                                                    <td><div class="handsontable">{{ $user->org_name }}</div></td>
                                                    <td><div class="handsontable">{{ $scheme->scheme_name }}</div></td>
                                                    <td><div class="handsontable">{{ $item->level }}</div></td>
                                                    {{-- <td>submitted</td> --}}
                                                    <td><a class="text-success" href="{{ route('adminapplication.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td><div class="handsontable">{{ $item->created_at }}</div></td>
                                                    {{-- <td>Un-Paid</td>
                                                    <td>Allotment</td> --}}
                                                </tr>
                                                @php
                                                    $i++;
                                                @endphp
                                            @endforeach
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });
        });
    </script>
@endsection
