@extends('layouts.adminback')
@section('content')
    <style>
        .btn-secondary {
            color: #fff;
            background-color: #101b33;
            border-color: #ffffff;
        }

    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>User List</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">user</a></li>
                                <li class="breadcrumb-item"><a href="#!">User list</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card user-profile-list">
                        <div class="card-body">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            <div class="row align-items-center m-l-0">
                                <div class="col-sm-6">
                                </div>
                                <div class="col-sm-6 text-right">
                                    {{-- <button class="btn btn-success btn-sm btn-round has-ripple" data-toggle="modal"
                                        data-target="#user" id="createnewrole"><i class="feather icon-plus"></i> Add User</button> --}}
                                        <a href="javascript:void(0)" class="btn btn-success btn-sm btn-round has-ripple" id="createnewrole"
                                            style="float: right"><i class="feather icon-plus"></i> Add
                                            New Role</a>
                                </div>
                            </div>
                            <div class="dt-responsive table-responsive">
                                <table id="user-list-table" class="table nowrap">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Role Name</th>
                                            <th>Insert Date</th>
                                            <th>Update Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $i=1;
                                        @endphp
                                        @foreach ($roles as $role)
                                            <tr>
                                                <td>{{ $i }}</td>
                                                <td>{{ $role->role_name }}</td>
                                                <td>{{ $role->created_at->format('d-m-y') }}</td>
                                                <td>{{ $role->updated_at->format('d-m-y') }}</td>
                                                <td>
                                                    <span
                                                        class="badge badge-light-{{ $role->isActive == 0 ? 'success' : 'danger' }}">{{ $role->isActive == 0 ? 'Active' : 'DeActive' }}</span>
                                                    <div class="overlay-edit">
                                                        {{-- <button type="button" class="btn btn-icon btn-success"><i
                                                                class="feather icon-check-circle"></i></button> --}}
                                                        <a href="javascript:void(0)" data-toggle="tooltip" data-id="{{ $role->id }}"
                                                            data-original-title="Edit" class="btn btn-icon btn-success edit editRole">
                                                                <i class="feather icon-check-circle"></i></a>
                                                                {{-- <a href="javascript:void(0)" data-toggle="tooltip" data-id="{{ $user->id }}"
                                                                    data-original-title="Edit" class="edit text-warning editUser">
                                                                    <i class="fa fa-edit"></i></a> --}}
                                                        <a class="btn btn-icon btn-danger" onclick="return confirm('Are you sure. you want to delete this ??')"
                                                                    href="{{ url('admin/role/' . $role->id.'/delete') }}"><i class="feather icon-trash-2"></i></a>
                                                       
                                                    </div>
                                                </td>
                                            </tr>
                                            @php
                                                $i++;
                                            @endphp
                                        @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>

    <div class="modal fade" id="roleModel" aria-hidden="true">>
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="roleHeading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                {{-- <div class="modal-header">
                    <h5 class="modal-title">Add new Role</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div> --}}
                <div class="modal-body">
                    {{-- <div class="custom-control custom-checkbox custom-control-inline">
                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                    <label class="custom-control-label" for="customCheck1">Public</label>
                </div>
                <div class="custom-control custom-checkbox custom-control-inline">
                    <input type="checkbox" class="custom-control-input" id="customCheck2">
                    <label class="custom-control-label" for="customCheck2">Billable</label>
                </div> --}}
                    <form  action="{{ route('create.role') }}" method="POST" id="roleForm">
                        @csrf
                        <input type="hidden" name="id" id="id">
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group fill">
                                <label class="floating-label" for="role_name">Role Name</label>
                                <input type="text" class="form-control @error('role_name') is-invalid @enderror" name="role_name" id="role_name" placeholder="Role">
                                @error('role_name')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    {{-- <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="floating-label" for="Status">Status</label>
                                <select class="form-control" id="Status">
                                    <option value=""></option>
                                    <option value="Active">Active</option>
                                    <option value="DeActive">DeActive</option>
                                </select>
                            </div>
                        </div>
                    </div> --}}
                    <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Save Role</button>
                    {{-- <button  class="btn btn-danger"> Clear </button> --}}
                    </form>
                </div>
                {{-- <div class="modal-footer">
                <button class="btn btn-primary"> Save </button>
                <button class="btn btn-danger"> Clear </button>
            </div> --}}
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function() {
        $('#table_id').DataTable();

        $("#createnewrole").click(function() {
            $('#roleform').trigger("reset");
            $('#roleHeading').html("Add New Role");
            $('#roleModel').modal('show');
        });

        $('body').on('click', '.editRole', function() {
            var id = $(this).data('id');
            // $('#roleHeading').html("Edit Role Detail");
            // $('#roleModel').modal('show');
            $.get("{{ url('admin/role') }}"+'/'+id+'/edit', function(data) {
                $('#roleHeading').html("Edit Role Detail");
                $('#saveBtn').val("edit-user");
                $('#roleModel').modal('show');
                $('#id').val(data.id);
                $('#role_name').val(data.role_name);
            });
        });

    });
</script>

@endsection
