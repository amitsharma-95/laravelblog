@extends('layouts.adminback')
@section('content')
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-md-12 col-xl-4">
                <div class="card widget-statstic-card">
                    <div class="card-body">
                        <div class="card-header-left mb-3">
                            <h5 class="mb-0">Application Registered</h5>
                            <p class="p-t-10 m-b-0 text-c-blue">all registered applications</p>
                        </div>
                        <i class="feather icon-users st-icon bg-c-blue"></i>
                        <div class="text-start">
                            <h3 class="d-inline-block">{{ $application }}</h3>
                            <i class="feather icon-arrow-up f-30 text-c-blue"></i>
                            <a href="{{ route('all.application') }}"><span class="float-end bg-c-blue">Manage</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-xl-4">
                <div class="card widget-statstic-card">
                    <div class="card-body">
                        <div class="card-header-left mb-3">
                            <h5 class="mb-0">Registered Users</h5>
                            <p class="p-t-10 m-b-0 text-c-yellow">all registered users</p>
                        </div>
                        <i class="feather icon-users st-icon bg-c-yellow"></i>
                        <div class="text-start">
                            <h3 class="d-inline-block">{{ $user }}</h3>
                            <i class="feather icon-arrow-up f-30 text-c-yellow"></i>
                            <a href="{{ route('admin.users') }}"><span class="float-end bg-c-yellow">Manage</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-xl-4">
                <div class="card widget-statstic-card">
                    <div class="card-body">
                        <div class="card-header-left mb-3">
                            <h5 class="mb-0">Application Submitted</h5>
                            <p class="p-t-10 m-b-0 text-c-green">all applications submitted by CB</p>
                        </div>
                        <i class="feather icon-users st-icon bg-c-green"></i>
                        <div class="text-start">
                            <h3 class="d-inline-block">{{ $application_submitted }}</h3>
                            <i class="feather icon-arrow-up f-30 text-c-green"></i>
                            <a href="#"><span class="float-end bg-c-green">Manage</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- [ Main Content ] end -->
</div>
</div>
@endsection