<form action="{{ route('create.user') }}" method="POST" id="userForm">
    @csrf
    <input type="hidden" name="id" value="{{ $usersdetail->id }}">

    <div class="row">
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="Name">Name</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                    id="name" value="{{ $usersdetail->name }}" placeholder="Name">
                @error('name')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="Email">Email</label>
                <input type="email" class="form-control @error('email') is-invalid @enderror"
                    name="email" value="{{ $usersdetail->email }}" id="email" placeholder="Email">
                @error('email')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="Mobile">Mobile</label>
                <input type="number" class="form-control @error('mobile') is-invalid @enderror"
                    name="mobile" value="{{ $usersdetail->mobile }}" id="mobile" placeholder="Mobile">
                @error('mobile')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="Username">Username</label>
                <input type="text" class="form-control @error('username') is-invalid @enderror"
                    name="username" value="{{ $usersdetail->username }}" id="username" placeholder="Username">
                @error('username')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="Password">Password</label>
                <input type="password" class="form-control @error('password') is-invalid @enderror"
                    name="password" value="{{ $usersdetail->password }}" id="password" placeholder="Password">
                @error('password')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group fill">
                <label class="floating-label" for="confirm_password">Confirm Password</label>
                <input id="password_confirmation" type="password"
                    class="form-control @error('password') is-invalid @enderror"
                    placeholder="Confirm Password" value="{{ $usersdetail->password }}" name="password_confirmation" required>
                @error('password')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group fill">
                {{-- <input type="hidden" name="role_id" value=""> --}}
                @php
                    $user_roles = explode(',',$usersdetail->role_id);
                @endphp
                <label class="floating-label" for="confirm_password">Select Role/Roles</label>
                <select class="form-control" name="roles[]" id="roles[]" multiple style="width:100%" required>
                    <option value="" selected>--Select Role</option>
                    @foreach ($roles as $role)
                        <option value="{{ $role->id }}"
                            @foreach ($user_roles as $user_role)
                                @if ($user_role==$role->id)
                                {{ "selected"}}
                                @endif
                            @endforeach 
                             style="z-index: 9999;">
                            {{ $role->role_name }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
    <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Update  </button>
</form>