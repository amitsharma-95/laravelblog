@extends('layouts.adminback')
@section('content')
    
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>User List</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">user</a></li>
                                <li class="breadcrumb-item"><a href="#!">User list</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card user-profile-list">
                        <div class="card-body">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            <div class="row align-items-center m-l-0">
                                <div class="col-sm-6">
                                </div>
                                <div class="col-sm-6 text-right">
                                    {{-- <button class="btn btn-success btn-sm btn-round has-ripple" data-toggle="modal"
                                        data-target="#user" id="createnewuser"><i class="feather icon-plus"></i> Add User</button> --}}
                                    <a href="javascript:void(0)" class="btn btn-success btn-sm btn-round has-ripple"
                                        id="createnewuser" style="float: right"><i class="feather icon-plus"></i> Add
                                        User</a>
                                </div>
                            </div>
                            <div class="dt-responsive table-responsive">
                                <table id="user-list-table" class="table nowrap">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Insert Date</th>
                                            <th>Update Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($users_list as $user)
                                            <tr>
                                                <td>{{ $user->username }}</td>
                                                <td>{{ $user->name }}</td>
                                                <td>{{ $user->email }}</td>
                                                <td>{{ $user->mobile }}</td>
                                                <td>{{ $user->created_at->format('d-m-y') }}</td>
                                                <td>{{ $user->updated_at->format('d-m-y') }}</td>
                                                <td>
                                                    <span
                                                        class="badge badge-light-{{ $user->isActive == 0 ? 'success' : 'danger' }}">{{ $user->isActive == 0 ? 'Active' : 'DeActive' }}</span>
                                                    <div class="overlay-edit">
                                                        {{-- <button type="button" class="btn btn-icon btn-success"><i
                                                                class="feather icon-check-circle"></i></button> --}}
                                                        <a href="javascript:void(0)" data-toggle="tooltip"
                                                            data-id="{{ $user->id }}" data-original-title="Edit"
                                                            class="btn btn-icon btn-success edit editUser">
                                                            <i class="feather icon-check-circle"></i></a>
                                                        {{-- <a href="javascript:void(0)" data-toggle="tooltip" data-id="{{ $user->id }}"
                                                                    data-original-title="Edit" class="edit text-warning editUser">
                                                                    <i class="fa fa-edit"></i></a> --}}
                                                        <a class="btn btn-icon btn-danger"
                                                            onclick="return confirm('Are you sure. you want to delete this ??')"
                                                            href="{{ url('admin/user/' . $user->id . '/delete') }}"><i
                                                                class="feather icon-trash-2"></i></a>

                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg show" id="userModel" aria-hidden="true">>
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userHeading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                {{-- <div class="modal-header">
                    <h5 class="modal-title">Add new User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div> --}}
                <div class="modal-body" id="editContent">
                    {{-- <div class="custom-control custom-checkbox custom-control-inline">
                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                    <label class="custom-control-label" for="customCheck1">Public</label>
                </div>
                <div class="custom-control custom-checkbox custom-control-inline">
                    <input type="checkbox" class="custom-control-input" id="customCheck2">
                    <label class="custom-control-label" for="customCheck2">Billable</label>
                </div> --}}
                <form action="{{ route('create.user') }}" method="POST" id="userForm">
                    @csrf
                    <input type="hidden" name="id" id="id">

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Name">Name</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                                    id="name" placeholder="Name">
                                @error('name')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Email">Email</label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror"
                                    name="email" id="email" placeholder="Email">
                                @error('email')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Mobile">Mobile</label>
                                <input type="number" class="form-control @error('mobile') is-invalid @enderror"
                                    name="mobile" id="mobile" placeholder="Mobile">
                                @error('mobile')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Username">Username</label>
                                <input type="text" class="form-control @error('username') is-invalid @enderror"
                                    name="username" id="username" placeholder="Username">
                                @error('username')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Password">Password</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror"
                                    name="password" id="password" placeholder="Password">
                                @error('password')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="confirm_password">Confirm Password</label>
                                <input id="password_confirmation" type="password"
                                    class="form-control @error('password') is-invalid @enderror"
                                    placeholder="Confirm Password" name="password_confirmation" required>
                                @error('password')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group fill">
                                {{-- <input type="hidden" name="role_id" value=""> --}}
                                <label for="confirm_password" style="font-size: 13px;font-weight: 600;color: #263e76;">Select Role/Roles</label>
                                <select class="form-control" name="roles[]" id="roles[]" style="width:100%" required>
                                    <option value="" selected>--Select Role--</option>
                                    @foreach ($roles as $role)
                                        <option value="{{ $role->id }}" id="" style="z-index: 9999;">
                                            {{ $role->role_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        {{-- <div class="col-sm-6">
                        <div class="form-group">
                            <label class="floating-label" for="Status">Status</label>
                            <select class="form-control" id="Status">
                                <option value=""></option>
                                <option value="Active">Active</option>
                                <option value="DeActive">DeActive</option>
                            </select>
                        </div>
                    </div> --}}
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary" id="saveBtn"> Save </button>
                    {{-- <button  class="btn btn-danger"> Clear </button> --}}
                </form>
                </div>
                {{-- <div class="modal-footer">
                <button class="btn btn-primary"> Save </button>
                <button class="btn btn-danger"> Clear </button>
            </div> --}}
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();

            $("#createnewuser").click(function() {
                $('#userform').trigger("reset");
                $('#userHeading').html("Add New User");
                $('#userModel').modal('show');
            });

            $('body').on('click', '.editUser', function() {
                var id = $(this).data('id');
                // $('#userHeading').html("Edit User Detail");
                // $('#userModel').modal('show');
                $.get("{{ url('admin/user') }}" + '/' + id + '/edit', function(data) {
                    $('#editContent').html(data.html);
                    $('#userHeading').html("Edit User Detail");
                    $('#userModel').modal('show');

                    
                    // $('#saveBtn').val("edit-user");
                    // $('#userModel').modal('show');
                    // console.log(data.role_id);
                    // $('#id').val(data.id);
                    // $('#name').val(data.name);
                    // $('#email').val(data.email);
                    // $('#mobile').val(data.mobile);
                    // $('#username').val(data.username);
                    // $('#password').val(data.password);
                    // $('#password_confirmation').val(data.password);
                    // $('#role_id').val(data.role_id);
                });
            });

        });
    </script>
@endsection
