<!DOCTYPE html>
<html lang="en">

<head>
    <title>@yield('title','CB Dashboard') </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Phoenixcoded" />
    <!-- Favicon icon -->
    <link rel="icon" href="{{ asset('admin') }}/assets/images/favicon.ico" type="image/x-icon">

    <!-- prism css -->
    <link rel="stylesheet" href="{{ asset('admin') }}/assets/css/plugins/prism-coy.css">

    <!-- vendor css -->
    <link rel="stylesheet" href="{{ asset('admin') }}/assets/css/style.css">
    
    


</head>

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->

    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar theme-horizontal menu-light brand-blue">
        <div class="navbar-wrapper">
            <div class="navbar-content sidenav-horizontal" id="layout-sidenav">
                <ul class="nav pcoded-inner-navbar sidenav-inner">
                    <li class="nav-item pcoded-menu-caption">
                    	<label>Navigation</label>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                    	<a href="{{ url('/dashboard') }}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    	<ul class="pcoded-submenu">
                    		<li><a href="#">Create New App</a></li>
                    	</ul>
                    </li>
                    {{-- <li class="nav-item pcoded-hasmenu">
                    	<a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Page layouts</span></a>
                    	<ul class="pcoded-submenu">
                    		<li class="pcoded-hasmenu"><a href="#!">Vertical</a>
                    			<ul class="pcoded-submenu">
                    				<li><a href="layout-static.html" target="_blank">Static</a></li>
                    				<li><a href="layout-fixed.html" target="_blank">Fixed</a></li>
                    				<li><a href="layout-menu-fixed.html" target="_blank">Navbar fixed</a></li>
                    				<li><a href="layout-mini-menu.html" target="_blank">Collapse menu</a></li>
                    				<li><a href="layout-rtl.html" target="_blank">Vertical RTL</a></li>
                    			</ul>
                    		</li>
                    		<li><a href="layout-horizontal.html" target="_blank">Horizontal</a></li>
                    		<li><a href="layout-horizontal-2.html" target="_blank">Horizontal v2</a></li>
                    		<li><a href="layout-horizontal-rtl.html" target="_blank">Horizontal RTL</a></li>
                    		<li><a href="layout-box.html" target="_blank">Box layout</a></li>
                    		<li><a href="layout-light.html" target="_blank">Navbar dark</a></li>
                    		<li><a href="layout-dark.html" target="_blank">Dark layout <span class="pcoded-badge badge badge-danger">Hot</span></a></li>
                    	</ul>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                    	<a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-map"></i></span><span class="pcoded-mtext">Maps</span></a>
                    	<ul class="pcoded-submenu">
                    		<li><a href="map-google.html">Google</a></li>
                    		<li><a href="map-api.html">Gmap search API</a></li>
                    	</ul>
                    </li> --}}
                    <li class="nav-item"><a href="{{ route('logout') }}" class="nav-link  text-danger">
                        <b><span class="pcoded-micon"><i class="feather icon-log-out"></i></span><span class="pcoded-mtext">Logout</span></b></a></li>

                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->

    <!-- [ Header ] start -->
    <header class="navbar pcoded-header navbar-expand-lg header-blue navbar-light">
        <div class="m-header">
            <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
            <a href="#!" class="b-brand">
                <!-- ========   change your logo hear   ============ -->
                <img src="{{ asset('admin') }}/assets/images/QCI-Logo.png" alt="" class="logo" style="width: 140px;">
                <img src="{{ asset('admin') }}/assets/images/QCI-Logo.png" alt="" class="logo-thumb" style="width: 140px;">
            </a>
            <a href="#!" class="mob-toggler">
                <i class="feather icon-more-vertical"></i>
            </a>
        </div>
        <div class="collapse navbar-collapse">
            {{-- <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>
                    <div class="search-bar">
                        <input type="text" class="form-control border-0 shadow-none" placeholder="Search hear">
                        <button type="button" class="close" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </li>
            </ul> --}}
            <ul class="navbar-nav ml-auto">
                <li>
                    <div class="dropdown">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"><i class="icon feather icon-bell"></i></a>
                        <div class="dropdown-menu dropdown-menu-right notification">
                            <div class="noti-head">
                                <h6 class="d-inline-block m-b-0">Notifications</h6>
                                <div class="float-right">
                                    <a href="#!" class="m-r-10">mark as read</a>
                                    <a href="#!">clear all</a>
                                </div>
                            </div>
                            <ul class="noti-body">
                                <li class="n-title">
                                    <p class="m-b-0">NEW</p>
                                </li>
                                <li class="notification">
                                    <div class="media">
                                        <img class="img-radius" src="assets/images/user/avatar-1.jpg" alt="Generic placeholder image">
                                        <div class="media-body">
                                            <p><strong>John Doe</strong><span class="n-time text-muted"><i class="icon feather icon-clock m-r-10"></i>5 min</span></p>
                                            <p>New ticket Added</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="n-title">
                                    <p class="m-b-0">EARLIER</p>
                                </li>
                                <li class="notification">
                                    <div class="media">
                                        <img class="img-radius" src="assets/images/user/avatar-2.jpg" alt="Generic placeholder image">
                                        <div class="media-body">
                                            <p><strong>Joseph William</strong><span class="n-time text-muted"><i class="icon feather icon-clock m-r-10"></i>10 min</span></p>
                                            <p>Prchace New Theme and make payment</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="notification">
                                    <div class="media">
                                        <img class="img-radius" src="assets/images/user/avatar-1.jpg" alt="Generic placeholder image">
                                        <div class="media-body">
                                            <p><strong>Sara Soudein</strong><span class="n-time text-muted"><i class="icon feather icon-clock m-r-10"></i>12 min</span></p>
                                            <p>currently login</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="notification">
                                    <div class="media">
                                        <img class="img-radius" src="assets/images/user/avatar-2.jpg" alt="Generic placeholder image">
                                        <div class="media-body">
                                            <p><strong>Joseph William</strong><span class="n-time text-muted"><i class="icon feather icon-clock m-r-10"></i>30 min</span></p>
                                            <p>Prchace New Theme and make payment</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="noti-footer">
                                <a href="#!">show all</a>
                            </div>
                        </div>
                    </div>
                </li>
                @php
                   $user_id = session('user_id');
                   $user = \App\User::where('id',$user_id)->first();
                @endphp
                <li>
                    {{ @$user->username }}
                </li>
                <li>
                    <div class="dropdown drp-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="feather icon-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right profile-notification">
                            <div class="pro-head">
                                <img src="{{ asset('admin') }}/assets/images/user/avatar-1.jpg" class="img-radius" alt="User-Profile-Image">
                                <span>{{ @$user->name }}</span>
                                <a href="{{ route('logout') }}" class="dud-logout" title="Logout">
                                    <i class="feather icon-log-out"></i>
                                </a>
                            </div>
                            <ul class="pro-body">
                                <li><a href="#" class="dropdown-item"><i class="feather icon-user"></i> Profile</a></li>
                                <li><a href="#" class="dropdown-item"><i class="feather icon-mail"></i> My Messages</a></li>
                                <li><a href="{{ route('logout') }}" class="dropdown-item"><i class="feather icon-lock"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </header>
    <!-- [ Header ] end -->

    {{-- main --}}
    @yield('content')
    {{-- endmain --}}

        <!-- Required Js -->
        <script src="{{ asset('admin') }}/assets/js/vendor-all.min.js"></script>
        <script src="{{ asset('admin') }}/assets/js/plugins/bootstrap.min.js"></script>
        <script src="{{ asset('admin') }}/assets/js/ripple.js"></script>
        <script src="{{ asset('admin') }}/assets/js/pcoded.min.js"></script>
    	{{-- <script src="{{ asset('admin') }}/assets/js/menu-setting.min.js"></script> --}}


    <!-- prism Js -->
    <script src="{{ asset('admin') }}/assets/js/plugins/prism.js"></script>
    <script src="{{ asset('admin') }}/assets/js/horizontal-menu.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    @if (Session::has('success'))
        <script>
            swal("Great Job!","{!! Session('success') !!}","success",{
                button:"OK",
            })
        </script>
    @endif
    @if (Session::has('message'))
        <script>
            swal("Bad Request!","{!! Session('message') !!}","warning",{
                button:"OK",
            })
        </script>
    @endif
    @yield('script')
    <script>
        (function() {
            if ($('#layout-sidenav').hasClass('sidenav-horizontal') || window.layoutHelpers.isSmallScreen()) {
                return;
            }
            try {
                window.layoutHelpers._getSetting("Rtl")
                window.layoutHelpers.setCollapsed(
                    localStorage.getItem('layoutCollapsed') === 'true',
                    false
                );
            } catch (e) {}
        })();
        $(function() {
            $('#layout-sidenav').each(function() {
                new SideNav(this, {
                    orientation: $(this).hasClass('sidenav-horizontal') ? 'horizontal' : 'vertical'
                });
            });
            $('body').on('click', '.layout-sidenav-toggle', function(e) {
                e.preventDefault();
                window.layoutHelpers.toggleCollapsed();
                if (!window.layoutHelpers.isSmallScreen()) {
                    try {
                        localStorage.setItem('layoutCollapsed', String(window.layoutHelpers.isCollapsed()));
                    } catch (e) {}
                }
            });
        });
        $(document).ready(function() {
            $("#pcoded").pcodedmenu({
                themelayout: 'horizontal',
                MenuTrigger: 'hover',
                SubMenuTrigger: 'hover',
            });
        });
    </script>

    <script src="{{ asset('admin') }}/assets/js/analytics.js"></script>

</body>

</html>
