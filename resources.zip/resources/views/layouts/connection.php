<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paddscheme";

$con = mysqli_connect($servername,$username,$password,$dbname);

if($con )
{
	echo " ";
	
}
else
{
	die("Connection Failed becouse".mysqli_connect_error());
}
?>