@extends('layouts.adminuser')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }
        table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Existing NC's</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Existing NC's</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            @php
                $status = \App\ApplicationStatus::where('id',$app_id)->where('user_id',$user->id)->first();
            @endphp
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            @if (Session::has('success'))
                                <p class="alert alert-success error">{{ Session('success') }}</p>
                            @endif
                            <div class="row align-items-center m-l-0">
                                <div class="col-sm-6">
                                </div>
                                <div class="col-sm-6 text-right mb-4">
                                    <a href="{{ route('alloted.toassessor') }}" class="btn btn-dark btn-round has-ripple"><i class="fa fa-arrow-left"></i> Go Back</a>
                                            {{-- <a href="{{ route('existing.nc') }}">Existing NC</a> --}}
                                </div>
                            </div>
                            <div class="dt-responsive table-responsive">
                                <table class="table table-bordered table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th><div class="handsontable">Type</th>
                                            {{-- <th>NC For</th> --}}
                                            <th><div class="handsontable">Topic</th>
                                            {{-- <th>Type</th> --}}
                                            {{-- <th>Refrence No.</th> --}}
                                            <th><div class="handsontable">Findings of Assessment</th>
                                            {{-- @if ($status->stage != '2F') --}}
                                            <th><div class="handsontable">Last Reply</th>
                                            <th><div class="handsontable">Reply by</th>
                                            <th><div class="handsontable">Inserted dated</th>
                                            {{-- @endif --}}
                                            {{-- @if ($status->stage == '2G') --}}
                                            <th><div class="handsontable">Action</th>
                                            {{-- @endif --}}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $i=1;
                                        @endphp
                                        @foreach ($assessor_ncs as $assessor_nc)
                                            @php
                                                // $reply = \App\AppNcReply::where('org_id',$org->id)->where('nc_id',$assessor_nc->id)->first();
                                                // @$assessor_reply = \App\AppReply::where('reply_to',$reply->id)->first();
                                                $reply = \App\AppNcReply::where('nc_id', $assessor_nc->id)->orderBy('id', 'DESC')->first();
                                            @endphp
                                            <tr>
                                                <td>{{ $i }}</td>
                                                <td><div class="handsontable"> {{ $assessor_nc->type }}</div></td>
                                                {{-- <td>{{ $assessor_nc->nc_for }}</td> --}}
                                                <td><div class="handsontable">{{ $assessor_nc->topic }}</div></td>
                                                <td><div class="handsontable">{{ $assessor_nc->findings_of_assessment }}</div></td>
                                                {{-- @if ($status->stage != '2F') --}}
                                                <td><div class="handsontable">{{ @$reply->reply }}</div></td>
                                                <td><div class="handsontable">{{ @$reply->reply_by }}</div></td>
                                                <td><div class="handsontable">{{ @$reply->created_at }}</div></td>
                                                <td>
                                                    <a href="{{ route('replies',[$assessor_nc->id,$assessor_nc->app_id]) }}" class="btn btn-icon btn-outline-warning editnc"  data-toggle="tooltip" data-id="{{ @$reply->id }}"
                                                                data-original-title="Reply"><i class="fa fa-reply"></i></a>
                                                                @if ($status->stage == '2G')
                                                                @if ($assessor_nc->status != 1)
                                                                <a href="{{ route('closenc',[$assessor_nc->id]) }}" class="btn btn-icon btn-outline-success" data-toggle="tooltip"
                                                                    data-original-title="Close NC"><i class="feather icon-check-circle"></i></a>
                                                                @endif
                                                           
                                                            @endif
                                                </td>
                                                {{-- @endif --}}
                                                
                                            </tr>
                                            @php
                                                $i++;
                                            @endphp
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @if ($status->stage == '2G')
                            <div class="row py-5">
                                <div class="col-md-12 text-center">
                                    @if (Session::has('message'))
                                    <p class="text-danger">* {{ Session('message') }}</p>
                                @endif
                                    {{-- <h4 class="text-center py-5"><span class="text-danger">Note:- All ncs reply are mandatory!!</span></h4> --}}
                                    @php
                                        $all_ncs = \App\AppAssessmentNC::where('app_id',$app_id)->where('org_id',$user->id)->where('assessment_id',$assessment->id)->where('assessor_id',$assessment->assessor_id)->count();
                                        $close_nc = \App\AppAssessmentNC::where('app_id',$app_id)->where('org_id',$user->id)->where('assessment_id',$assessment->id)->where('assessor_id',$assessment->assessor_id)->where('status',1)->count();
                                    @endphp
                                    @if ($close_nc != $all_ncs)
                                    <a href="{{ route('sendreplytocb',[$app_id]) }}" class="btn btn-warning"><i class="feather mr-2 icon-alert-triangle"></i> Send all replies to CB </a>
                                    @endif
                                    @if ($close_nc == $all_ncs)
                                    <a href="{{ route('close.all_nc',[$app_id]) }}" class="btn btn-primary"><i class="feather mr-2 icon-thumbs-up"></i> Close NC Process  </a>
                                    @endif
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="ncmodal" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="Heading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('replyto.org') }}" method="POST" id="ncform">
                        @csrf
                        <div class="row">
                             <input type="hidden" name="id" id="id">
                             <input type="hidden" name="org_id" id="org_id" value="{{ $user->id }}">
                             <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="floating-label" for="findings_of_assessment">Reply to NC</label>
                                    <textarea name="reply" id="reply" class="form-control" placeholder="Reply ...."></textarea>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <input type="submit" class="btn btn-primary" value="Submit reply">
                                {{-- <button class="btn btn-danger">Clear</button> --}}
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function() {

        $("#generateNC").click(function() {
            $('#ncform').trigger("reset");
            $('#Heading').html("Generate New NC");
            $('#ncmodal').modal('show');
        });

        $('body').on('click', '.editnc', function() {
            var id = $(this).data('id');
            
            // alert(id);
            $.get("{{ url('assessor/existing-nc') }}" + '/' + id, function(data) {
                $('#Heading').html("Send Reply to ORG Again");
                $('#ncmodal').modal('show');
                // console.log(data);
                // alert(data);
                $('#id').val(data.id);
            })
        });

    });
</script>
@endsection
