@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Pending Alloted Application</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Pending Alloted Applications</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <h5 class="card-header text-center">
                            Pending Alloted Applications
                            <a href="{{ route('alloted.toassessor') }}" class="btn btn-dark float-right has-ripple"><i class="feather icon-arrow-left"></i> Back</a>
                        </h5>
                        <div class="card-body">
                            @if (Session::has('success'))
                                    <div class="alert alert-success">
                                        {{ Session::get('success') }}
                                    </div>
                                @endif
                                @if ($errors->any())
                                    <div class="alert alert-danger">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                            <div class="dt-responsive table-responsive">
                                    <table id="example"  class="table nowrap table-striped table-bordered" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 1%">S.No.</th>
                                                <th style="width: 6%">Username</th>
                                                <th style="width: 8%">Org Name</th>
                                                <th style="width: 34%">Scheme</th>
                                                <th style="width: 10%">Level</th>
                                                <th style="width: 7%">Preview</th>
                                                <th style="width: 5%">start from</th>
                                                <th style="width: 5%">close to</th>
                                                <th style="width: 8%">Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Username</th>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                <th>Preview</th>
                                                <th>start from</th>
                                                <th>close to</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @php
                                                $i = 1;
                                            @endphp
                                            @foreach ($allotments as $allotment)
                                                @php
                                                    if (!$allotment == null) {
                                                        $applications = \App\ApplicationStatus::where('id', $allotment->app_id)->where('user_id', $allotment->org_id)->where('stage','2E')->get();
                                                    } else {
                                                        $applications = [];
                                                    }
                                                @endphp
                                                @foreach ($applications as $item)
                                                    @php
                                                        $loginAssessor = Session('userRole');
                                                        $applicant = \App\User::where('id', $item->user_id)->first();
                                                        $scheme = \App\AppScheme::where('id', $item->scheme)->first();
                                                        $assessment = \App\AppAssessment::where('org_id', $item->user_id)->where('app_id', $item->id)
                                                            ->Where('assessor_id', $loginAssessor->id)->where('isActive', 0)
                                                            ->first();
                                                    @endphp
                                                    <tr>
                                                        <td>{{ $i }}</td>
                                                        <td>
                                                            <div class="handsontable">{{ $applicant->username }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $applicant->org_name }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $scheme->scheme_name }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $item->level }}</div>
                                                        </td>
                                                        <td>
                                                            <a href="{{ route('ass.application.preview', [$item->id]) }}"
                                                                target="_blank" class="handsontable text-success"><i
                                                                    class="fa fa-eye"></i> Preview</a>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $assessment->from_date }}</div>
                                                        </td>
                                                        <td>
                                                            <div class="handsontable">{{ $assessment->to_date }}</div>
                                                        </td>
                                                        <td>
                                                            @if ($item->stage == '2')
                                                                <span class="handsontable badge badge-light-success">Wait for
                                                                    Allot Assessor</span>
                                                            @elseif ($item->stage == '2A')
                                                                <span
                                                                    class="handsontable badge badge-light-primary">Accept/Reject</span>
                                                                {{-- @elseif ($item->stage == '2B' )
                                                            <span class="handsontable badge badge-light-{{ $assessment->assessor_action=='reject'?'danger':'success' }}">{{ $assessment->assessor_action?$assessment->assessor_action.' by Assessor':'' }}</span> --}}
                                                            @elseif ($item->stage == '2B')
                                                                <span class="handsontable badge badge-light-primary">Sent to ORG
                                                                    for Acceptance</span>
                                                            @elseif ($item->stage == '2D')
                                                                <span
                                                                    class="handsontable badge badge-light-primary">Confirmation
                                                                    Pending for assessment</span>
                                                            @elseif ($item->stage == '2E')
                                                                <span class="handsontable badge badge-light-warning">Start
                                                                    Assessment</span>
                                                            @elseif ($item->stage == '2F')
                                                                <span class="handsontable badge badge-light-primary">NC Sent to
                                                                    ORG</span>
                                                            @elseif ($item->stage == '2G')
                                                                <span class="handsontable badge badge-light-primary">View ORG
                                                                    Reply</span>
                                                            @elseif ($item->stage == '3')
                                                                <span class="handsontable badge badge-light-success">Assessment
                                                                    Completed report sent to DO</span>
                                                            @elseif ($item->stage == '4')
                                                                <span class="handsontable badge badge-light-success">Assessment
                                                                    Closed</span>
                                                            @endif
                                                            <div class="overlay-edit">
                                                                @if ($item->stage == 4)
                                                                    @php
                                                                        $clerification = \App\Clerification::where('org_id', $item->id)
                                                                            ->where('assessor_id', $loginAssessor->id)
                                                                            ->get();
                                                                    @endphp
                                                                    {{-- {{ dd($clerification) }} --}}
                                                                    @if ($clerification->count() > 0)
                                                                        <a href="{{ route('assessor.clerification', [$item->id]) }}"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            data-original-title="Clerification"
                                                                            class="btn btn-icon btn-warning edit allotmentUser">
                                                                            <i class="fas fa-file-signature"></i> </a>
                                                                    @endif
                                                                @endif
                                                                @if ($item->stage == '2A')
                                                                    <a href="{{ route('action', [$item->id]) }}"
                                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                                        <i class="feather icon-check-circle"></i> </a>
                                                                @elseif ($item->stage == '2E' || $item->stage == '2F' || $item->stage == '2G' || $item->stage == '3' || $item->stage == '4')
                                                                    <a href="{{ route('start.assessment', [$item->id]) }}"
                                                                        class="btn btn-icon btn-success edit allotmentUser"
                                                                        data-toggle="tooltip" data-original-title="NC Process">
                                                                        <i class="feather icon-check-circle"></i> </a><br>
                                                                    <a href="{{ route('assessment.report', [$item->id]) }}"
                                                                        class="btn btn-icon btn-warning edit allotmentUser"
                                                                        data-toggle="tooltip"
                                                                        data-original-title="Assessment Process">
                                                                        <i class="feather icon-upload-cloud"></i> </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    @php
                                                        $i++;
                                                    @endphp
                                                @endforeach
                                            @endforeach
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });

            //popup
            // $('body').on('click', '.allotmentUser', function() {
            //     var id = $(this).data('id');
            //     $('#userAllotmentModel').modal('show');

            // });

        });
    </script>
@endsection
