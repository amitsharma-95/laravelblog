@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
    width: 100%;
    padding: 8px;
    }
    table {
            border-spacing: 0px;
            table-layout: fixed;
            margin-left: auto;
            margin-right: auto;
        }
        .handsontable {
            overflow-wrap: break-word;
            white-space: pre-line;
        }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Assessor NC Process</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="#!">Assessor NC Process</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-md-12 col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-body">
                                <div class="row align-items-center m-l-0">
                                    <div class="col-sm-6">
                                    </div>
                                    <div class="col-sm-6 text-right mb-4">
                                        @if ($app->stage != '3' && $app->stage != '4')
                                        <a href="javascript:void(0)" class="btn btn-primary btn-round has-ripple" data-toggle="tooltip"
                                        data-target="#ncmodal" id="generateNC" data-original-title="Generate New NC"><i class="feather icon-plus"></i> Generate NC</a>
                                        @endif
                                        
                                        {{-- <a href="#" class="btn btn-primary btn-round has-ripple" data-toggle="tooltip"
                                           data-original-title="Generate New Assessment Report"><i class="feather icon-plus"></i> Assessment Report</a> --}}
                                        <a href="{{ route('existing.nc',[$app->id]) }}" class="btn btn-outline-primary btn-round has-ripple" data-toggle="tooltip" data-original-title="View Existing NC"><i class="feather icon-eye"></i> Existing NC</a>
                                        <a href="{{ route('alloted.toassessor') }}" class="btn btn-dark btn-round has-ripple"><i class="fa fa-arrow-left"></i> Back</a>
                                    </div>
                                </div>
                                @if (Session::has('success'))
                                    <div class="alert alert-success">
                                        {{ Session::get('success') }}
                                    </div>
                                @endif
                                @if ($errors->any())
                                    <div class="alert alert-danger">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                @if ($app->stage != '3' && $app->stage != '4')
                                <div class="dt-responsive table-responsive">
                                    <table id="example" class="table table-bordered table-striped nowrap" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Org Name</th>
                                                <th>NC For</th>
                                                <th>Topic</th>
                                                <th>Type</th>
                                                <th>Refrence No.</th>
                                                <th>Findings of Assessment</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>Org Name</th>
                                                <th>NC For</th>
                                                <th>Topic</th>
                                                <th>Type</th>
                                                <th>Refrence No.</th>
                                                <th>Findings of Assessment</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($all_ncs as $nc)
                                            @php
                                                $org = \App\User::where('id',$nc->org_id)->first();
                                            @endphp
                                                <tr>
                                                    <td><div class="handsontable">{{ $org->name }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->nc_for }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->topic }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->type }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->ref_no }}</div></td>
                                                    <td><div class="handsontable">{{ $nc->findings_of_assessment }}</div></td>
                                                    <td class="table-action">
                                                        {{-- <a href="#!" class="btn btn-icon btn-outline-primary has-ripple" data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><i class="feather icon-eye"></i><span class="ripple ripple-animate" style="height: 45px; width: 45px; animation-duration: 0.7s; animation-timing-function: linear; background: rgb(255, 255, 255); opacity: 0.4; top: 1.42188px; left: 18.7969px;"></span></a> --}}
                                                        {{-- <a href="#!" class="btn btn-icon btn-outline-success editnc" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="feather icon-edit"></i></a> --}}
                                                        <a href="javascript:void(0)" class="btn btn-icon btn-outline-success editnc"  data-toggle="tooltip" data-id="{{ $nc->id }}"
                                                            data-original-title="Edit"><i class="feather icon-edit"></i></a>
                                                        <a class="btn btn-icon btn-outline-danger" onclick="return confirm('Are you sure. you want to delete this ??')"
                                                        href="{{ route('delete.nc',[$nc->id]) }}" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="feather icon-trash-2"></i></a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-center my-3">
                                        <div class="content text-center">
                                            <h6 class="text-danger"><span class="text-danger">*</span> After Generating all NC's click on freeze all Button</h6>
                                        </div>
                                        <a href="{{ route('freeze.allnc',[$app->id]) }}" class="btn btn-dark btn sm"><i class="feather icon-chevrons-down"></i> Freeze All</a>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
    <div class="modal fade" id="ncmodal" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="Heading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('generate.nc') }}" method="POST" id="ncform">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="id" id="id" value="">
                            <input type="hidden" name="org_id" value="{{ $user->id }}" />
                            <input type="hidden" name="app_id" value="{{ $app->id }}" />
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="floating-label" for="nc_for">NC For</label>
                                    <input type="text" class="form-control" name="nc_for" id="nc_for" value="{{ $nc_for }}" readonly>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="floating-label" for="topic">Topic/Item</label>
                                    <input type="text" class="form-control" name="topic" id="topic" placeholder="Topic/Item">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="floating-label" for="type">Type NC/Obs.</label>
                                    <select class="form-control" name="type" id="type">
                                        <option selected>select Type NC/Obs.</option>
                                        <option value="Non Conformity">Non Conformity</option>
                                        <option value="Observation">Observation</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="floating-label" for="ref_no">Document Reference No.</label>
                                    <input type="text" class="form-control" name="ref_no" id="ref_no" placeholder="Document Reference No.">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="floating-label" for="findings_of_assessment">Findings of Assessment</label>
                                    <textarea name="findings_of_assessment" id="findings_of_assessment" class="form-control" placeholder="Findings of Assessment"></textarea>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <input type="submit" class="btn btn-primary" id="saveBtn" value="Submit">
                                <button class="btn btn-danger">Clear</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function() {

        $("#generateNC").click(function() {
            $('#ncform').trigger("reset");
            $('#Heading').html("Generate New NC");
            $('#ncmodal').modal('show');
        });

        $('body').on('click', '.editnc', function() {
            var id = $(this).data('id');
            $.get("{{ url('assessor/getnc') }}" + '/' + id + '/edit', function(data) {
                $('#Heading').html("Edit Generated NC");
                $('#saveBtn').val("Save Changes");
                $('#ncmodal').modal('show');
                $('#id').val(data.id);
                $('#topic').val(data.topic);
                $('#type').val(data.type);
                $('#ref_no').val(data.ref_no);
                $('#findings_of_assessment').val(data.findings_of_assessment);
            })
        });

    });
</script>
<script>
    $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });
            
        });
</script>
@endsection