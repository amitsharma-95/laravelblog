@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
        width: 100%;
        padding: 8px;
        /* box-sizing: border-box; */
    }

</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Assessment Completed</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Assessment Completed</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card user-profile-list">
                        <div class="card-body">
                            @if (Session::has('success'))
                                    <div class="alert alert-success">
                                        {{ Session::get('success') }}
                                    </div>
                                @endif
                                @if ($errors->any())
                                    <div class="alert alert-danger">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                            <div class="dt-responsive table-responsive">
                                    <table id="example"  class="table nowrap"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                <th>Username</th>
                                                <th>Preview</th>
                                                <th>start from</th>
                                                <th>close to</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>Org Name</th>
                                                <th>Scheme</th>
                                                <th>Level</th>
                                                <th>Username</th>
                                                <th>Preview</th>
                                                <th>start from</th>
                                                <th>close to</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($allotments as $item)
                                                @php
                                                    if (!$item == null) {
                                                            $applicants = \App\User::where('id', $item->org_id)->get();
                                                        } else {
                                                            $applicants = [];
                                                        } 
                                                @endphp
                                            @foreach ($applicants as $item)
                                            @php
                                                $loginAssessor = Session('userRole');
                                                $application = \App\ApplicationStatus::where('user_id',$item->id)->first() ;
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                                $assessment = \App\AppAssessment::where('org_id',$item->id)->Where('assessor_id',$loginAssessor->id)->first() ;
                                            @endphp
                                                <tr>
                                                    <td>{{ $item->org_name }}</td>
                                                    <td>{{ $scheme->scheme_name }}</td>
                                                    <td>{{ $item->level }}</td>
                                                    <td>{{ $item->username }}</td>
                                                    <td>
                                                        <a href="{{ route('ass.application.preview',[$item->id]) }}" target="_blank" class="text-success"><i class="fa fa-eye"></i> Preview</a>
                                                    </td>
                                                    <td>{{ $assessment->from_date }}</td>
                                                    <td>{{ $assessment->to_date }}</td>
                                                    <td>
                                                        @if ($application->stage == '2' )
                                                        <span class="badge badge-light-success">Wait for Allot Assessor</span>
                                                        @elseif ($application->stage == '2A' )
                                                        <span class="badge badge-light-primary">Accept/Reject</span>
                                                        @elseif ($application->stage == '2B' )
                                                        <span class="badge badge-light-{{ $assessment->assessor_action=='reject'?'danger':'success' }}">{{ $assessment->assessor_action?$assessment->assessor_action.' by Assessor':'' }}</span>
                                                        @elseif ($application->stage == '2C' )
                                                        <span class="badge badge-light-primary">Sent to ORG for Acceptance</span>
                                                        @elseif ($application->stage == '2D' )
                                                        <span class="badge badge-light-primary">Confirmation Pending for assessment</span>
                                                        @elseif ($application->stage == '2E' )
                                                        <span class="badge badge-light-primary">Start Assessment</span>
                                                        @elseif ($application->stage == '2F' )
                                                        <span class="badge badge-light-primary">NC Sent to ORG</span>
                                                        @elseif ($application->stage == '2G' )
                                                        <span class="badge badge-light-primary">View ORG Reply</span>
                                                        @endif
                                                    <div class="overlay-edit">
                                                       @if ($application->stage == '2A' )
                                                       <a href="{{ route('action',[$item->id]) }}" 
                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($application->stage == '2E' || $application->stage == '2F' || $application->stage == '2G')
                                                        <a href="{{ route('start.assessment',[$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser" data-toggle="tooltip" data-original-title="Start NC Process">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                        <a href="{{ route('assessment.report',[$item->id]) }}" 
                                                                class="btn btn-icon btn-warning edit allotmentUser" data-toggle="tooltip" data-original-title="Assessment Process">
                                                                <i class="feather icon-upload-cloud"></i> </a>
                                                       @endif
                                                    </div>
                                                </td>
                                                </tr>
                                            @endforeach
                                            @endforeach
                                            {{-- @foreach ($applicantions as $item)
                                            @php
                                                $loginAssessor = Session('userRole');
                                                $application = \App\ApplicationStatus::where('user_id',$item->id)->first() ;
                                                $scheme = \App\AppScheme::where('id',$item->scheme)->first() ;
                                                $assessment = \App\AppAssessment::where('org_id',$item->id)->orWhere('assessor_id',$loginAssessor->id)->first() ;
                                            @endphp
                                                <tr>
                                                    <td>{{ $item->org_name }}</td>
                                                    <td>{{ $scheme->scheme_name }}</td>
                                                    <td>{{ $item->level }}</td>
                                                    <td>{{ $item->username }}</td>
                                                    <td>{{ $assessment->from_date }}</td>
                                                    <td>{{ $assessment->to_date }}</td>
                                                    <td><a class="text-success" href="{{ route('application.preview',[$item->id]) }}" target="_blank"><i class="feather icon-eye"></i> preview</a></td>
                                                    <td>
                                                        @if ($application->stage == '2' )
                                                        <span class="badge badge-light-success">Assessor Alloted</span>
                                                        @elseif ($application->stage == '2A' )
                                                        <span class="badge badge-light-success">Accept/Reject</span>
                                                        @elseif ($application->stage == '2B' )
                                                        <span class="badge badge-light-{{ $assessment->assessor_action=='reject'?'danger':'success' }}">{{ $assessment->assessor_action }}</span>
                                                        @elseif ($application->stage == '2g' )
                                                        <span class="badge badge-light-success">Scrutiny Close</span>
                                                        @endif
                                                    <div class="overlay-edit">
                                                        
                                                       @if ($application->stage == '2A' )
                                                       <a href="{{ route('action',[$item->id]) }}" 
                                                        class="btn btn-icon btn-success edit allotmentUser">
                                                        <i class="feather icon-check-circle"></i> </a>
                                                        @elseif ($application->stage == '1C')
                                                        <a href="{{ route('scrutiny', [$item->id]) }}" 
                                                            class="btn btn-icon btn-success edit allotmentUser">
                                                            <i class="feather icon-check-circle"></i> </a>
                                                       @endif
                                                    </div>
                                                </td>
                                                </tr>
                                            @endforeach --}}
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script> --}}
    <script>
        // $('#example').DataTable({
        //     dom: 'Bfrtip',
        //     buttons: ['copy', 'csv', 'excel', 'print']
        // });
        
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    // Apply the search
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });

            //popup
            // $('body').on('click', '.allotmentUser', function() {
            //     var id = $(this).data('id');
            //     $('#userAllotmentModel').modal('show');

            // });

        });
    </script>
@endsection
