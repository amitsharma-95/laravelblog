@extends('layouts.adminuser')
@section('content')
    <style>
        tfoot input {
            width: 100%;
            padding: 8px;
            /* box-sizing: border-box; */
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Application Replies</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Applications Replies</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <div class="row">
                @php
                    $status = \App\ApplicationStatus::where('id',$app_id)->first();
                    $all_ncs = \App\AppAssessmentNC::where('app_id',$app_id)->where('org_id',$status->user_id)->where('id',$nc_id)->where('assessor_id',$assessor_id)->where('assessment_id',$assessment_id)->count();
                    $close_ncs = \App\AppAssessmentNC::where('app_id',$app_id)->where('org_id',$status->user_id)->where('id',$nc_id)->where('assessor_id',$assessor_id)->where('assessment_id',$assessment_id)->where('status',1)->count();
                @endphp
                @if ($status->stage == '2G')
                    @if ($all_ncs != $close_ncs)
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center py-3" >
                            <b>Send Reply</b>
                            <a href="{{ route('existing.nc',[$app_id]) }}" class="btn btn-dark btn-sm"><i
                                    class="fa fa-arrow-left"></i> Go Back</a>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('submit.reply') }}" method="POST" id="ncform">
                                @csrf
                                <div class="row">
                                    <input type="hidden" name="org_id" id="org_id" value="{{ $status->user_id }}">
                                    <input type="hidden" name="app_id" id="app_id" value="{{ $app_id }}">
                                    <input type="hidden" name="nc_id" id="nc_id" value="{{ $nc_id }}">
                                    <input type="hidden" name="assessor_id" id="assessor_id" value="{{ $assessor_id }}">
                                    <input type="hidden" name="assessment_id" id="assessment_id" value="{{ $assessment_id }}">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="floating-label" for="reply">Reply to NC <span
                                                    class="text-danger">*</span></label>
                                            <textarea name="reply" id="reply" rows="5" class="form-control" placeholder="Reply to NC ... .." required></textarea>
                                        </div>
                                    </div>
                                    
                                        <div class="col-sm-12 text-center my-4">
                                            <input type="submit" class="btn btn-primary" id="saveBtn" value="Submit Reply">
                                            {{-- <button class="btn btn-danger" class="close" data-dismiss="modal"
                                            aria-label="Close">Close</button> --}}
                                        </div>
                                        
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @endif
                                    
                                    @endif
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center py-3" style="border-top: 4px solid #ffa900;">
                            <b>CB/Assessor Replies</b>
                            <a href="{{ route('existing.nc',[$app_id]) }}" class="btn btn-dark btn-sm"><i
                                class="fa fa-arrow-left"></i> Go Back</a>
                        </div>
                        <div class="card-body">
                            {{-- @php
                                @$nc = \App\AppAssessmentNC::where('id',$nc_id)->first();
                            @endphp
                            <h5>NC For - <span class="text-primary">{{ @$nc->nc_for }}</span></h5>
                            <h5>NC Type - <span class="text-primary">{{ @$nc->type }}</span></h5>
                            <h5>NC Topic - <span class="text-primary">{{ @$nc->topic }}</span></h5> --}}
                            @foreach ($replies as $reply)
                            @if ($reply->reply_by == 'Applicant')
                                <div class="d-flex flex-row justify-content-start">
                                    <img src="{{ asset('assets/img/team/org_avatar.png') }}" alt="avatar 1"
                                        style="width: 45px; height: 100%;">
                                    <div class="p-3 me-3 border"
                                        style="border-radius: 15px; margin-left: 10px; background-color: #f5f6f7;">
                                        <p class="small mb-0">{{ $reply->reply_by == 'Applicant'?$reply->reply:'.......' }}</p>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mb-5">
                                    <p class="small mb-1">{{ $reply->reply_by }}</p>
                                    <p class="small mb-1 text-muted"><i class="fa fa-clock-o" aria-hidden="true"></i>
                                        {{ $reply->created_at }}</p>
                                </div>
                                @endif
                                @if ($reply->reply_by == 'Assessor')
                                    
                                <div class="d-flex flex-row justify-content-end pt-1">
                                    <div class="p-3 ms-3 mr-2"
                                        style="border-radius: 15px; margin-right: 10px; background-color: rgba(57, 192, 237,.2);">
                                        <p class="small mb-0">
                                            {{ $reply->reply_by == 'Assessor'?$reply->reply:'.......' }}
                                        </p>
                                    </div>
                                    <img src="{{ asset('assets/img/team/assessor_avatar.png') }}" alt="avatar 1"
                                        style="width: 45px; height: 100%;">
                                </div>
                                <div class="d-flex justify-content-between mb-5">
                                    <p class="small mb-1 text-muted"><i class="fa fa-clock-o" aria-hidden="true"></i>
                                        {{ $reply->updated_at }}</p>
                                    <p class="small mb-1">Assessor</p>
                                </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
