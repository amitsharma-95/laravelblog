@extends('layouts.adminuser')
@section('content')
<style>
    tfoot input {
    width: 100%;
    padding: 8px;
    }
</style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Assessment Report</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="#!">Assessment Report</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-md-12 col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-body">
                                <div class="row">
                                    @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible fade show">
                                        {{ Session::get('success') }}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                @endif
                                @if ($errors->any())
                                    <div class="alert alert-danger alert-dismissible fade show">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                @endif
                                </div>
                                <div class="row align-items-center m-l-0">
                                    
                                    <div class="col-sm-6">
                                    </div>
                                    <div class="col-sm-6 text-right mb-4">
                                        <a href="javascript:void(0)" class="btn btn-primary btn-round has-ripple" data-toggle="tooltip"
                                            data-target="#ncmodal" id="generateNC" data-original-title="Generate New Assessment Report"><i class="feather icon-plus"></i> Assessment Report</a>
                                        <a href="{{ route('alloted.toassessor') }}" class="btn btn-dark btn-round has-ripple">
                                            <i class="fa fa-arrow-left"></i> Go Back</a>
                                    </div>
                                </div>
                                
                                <div class="dt-responsive table-responsive">
                                    <table id="example" class="table table-bordered table-striped nowrap text-center" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Org Name</th>
                                                <th>Username</th>
                                                <th>Document Name</th>
                                                <th>Document file</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot style="display: table-header-group">
                                            <tr>
                                                <th>Org Name</th>
                                                <th>Username</th>
                                                <th>Document Name</th>
                                                <th>Document file</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($assessment_reports as $assessment_report)
                                            @php
                                                $org = \App\User::where('id',$assessment_report->org_id)->first();
                                            @endphp
                                                <tr>
                                                    <td>{{ $org->org_name }}</td>
                                                    <td>{{ $org->username }}</td>
                                                    <td>{{ $assessment_report->doc_name }}</td>
                                                    <td>
                                                        <a href="{{ url('public/assets/assessments') }}/{{ $assessment_report->doc_file }}" target="_blank">view</a>
                                                        {{-- <img src="{{ asset('public/assets/assessments') }}/{{ $assessment_report->doc_file }}" style="width: 100px; height: 100px;"> --}}
                                                    </td>
                                                    <td>
                                                        <a href="javascript:void(0)" class="btn btn-icon btn-outline-success editnc"  data-toggle="tooltip" data-id="{{ $assessment_report->id }}"
                                                            data-original-title="Edit"><i class="feather icon-edit"></i></a>
                                                            <a class="btn btn-icon btn-outline-danger" onclick="return confirm('Are you sure. you want to delete this ??')"
                                                        href="{{ route('delete.report',[$assessment_report->id]) }}" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="feather icon-trash-2"></i></a>
                                                    </td>
                                               </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
    <div class="modal fade" id="ncmodal" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="Heading"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('submit.report') }}" method="POST" id="ncform" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="id" id="id" value="">
                            <input type="hidden" name="org_id" value="{{ $org_id }}" />
                            <input type="hidden" name="app_id" value="{{ $app_id }}" />
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="floating-label" for="topic">Document Name</label>
                                    <input type="text" class="form-control" name="doc_name" id="doc_name" placeholder="Document Name">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="floating-label" for="ref_no">upload Document</label>
                                    <input type="file" class="form-control" name="doc_file" id="doc_file" placeholder="upload">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                {{-- <input type="submit" class="btn btn-primary" id="saveBtn" value="Submit"> --}}
                                <button type="submit" class="btn btn-primary"><i class="feather mr-2 icon-thumbs-up"></i> Submit</button>
                                <button class="btn btn-danger">Clear</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function() {

        $("#generateNC").click(function() {
            $('#ncform').trigger("reset");
            $('#Heading').html("Generate New Assessment Report");
            $('#ncmodal').modal('show');
        });

        $('body').on('click', '.editnc', function() {
            var id = $(this).data('id');
            $.get("{{ url('assessor/edit-report') }}" + '/' + id , function(data) {
                $('#Heading').html("Edit Assessment Report");
                $('#saveBtn').val("Save Changes");
                $('#ncmodal').modal('show');
                $('#id').val(data.id);
                $('#doc_name').val(data.doc_name);
                $('#doc_file').val(data.doc_file);
            })
        });

    });
</script>
<script>
    $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text"  placeholder="Search ' + title + '" />');
            });

            // DataTable
            var table = $('#example').DataTable({
                initComplete: function() {
                    this.api()
                        .columns()
                        .every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear', function() {
                                if (that.search() !== this.value) {
                                    that.search(this.value).draw();
                                }
                            });
                        });
                },
            });
            
        });
</script>
@endsection