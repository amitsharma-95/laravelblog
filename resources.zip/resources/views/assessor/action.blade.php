@extends('layouts.adminuser')
@section('content')
    <style>
        .reject {
            display: none;
        }
    </style>
    <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5>Assessor Action</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Assessor Action</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card user-profile-list">
                        <h5 class="card-header text-center">
                            Assessor Action
                            <a href="{{ route('alloted.toassessor') }}" class="btn btn-dark btn-sm float-right">back</a>
                        </h5>
                        <div class="card-body mb-2">
                            @if (Session::has('success'))
                                <div class="alert alert-success">
                                    {{ Session::get('success') }}
                                </div>
                            @endif
                            @error('assessor_remark')
                                <span class="text-danger mb-5" style="margin-bottom: 10px;">{{ $message }}</span>
                            @enderror
                            <form action="{{ route('assessor.action') }}" method="POST" id="userForm">
                                @csrf
                                <input type="hidden" name="org_id" id="org_id" value="{{ $org->id }}">
                                <input type="hidden" name="app_id" id="app_id" value="{{ $app->id }}">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Assessment
                                                Action</label>
                                            <select class="form-control" name="assessor_action" id="assessor_action"
                                                required>
                                                <option value="">Accept/Reject</option>
                                                <option value="Accept">Accept</option>
                                                <option value="Reject">Reject</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row reject">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="user" style="color: #080d19;font-weight: 600;">Remark for
                                                Rejection</label>
                                            <textarea class="form-control @error('assessor_remark') is-invalid @enderror" name="assessor_remark" id="assessor_remark" cols="30" rows="3"
                                                placeholder="Give Reason of Rejection........"></textarea>
                                                @error('assessor_remark')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-12">
                                        <button type="submit" name="submit" class="btn btn-primary" id="SaveBtn"> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script language="javascript">
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();

        today = yyyy + '-' + mm + '-' + dd;
        $('#from_date').attr('min', today);
        $('#to_date').attr('min', today);

        $('#assessor_action').change(function() {
            var $option = $(this).find('option:selected');
            var value = $option.val();
            if (value == 'Reject') {
                $('.reject').show();
            } else {
                $('.reject').hide();
            }
        });

    //    function remarkvalidation(){
    //     assessor_remark = document.getElementById('assessor_remark').value();
    //         if (assessor_remark == '') {
    //             swal("Bad Request!","You have to give the reason for Rejection!!","warning",{
    //                 button:"OK",
    //             })
    //             return false;
    //             document.getElementById('assessor_remark').value() = '';
    //         }
    //     }
    </script>
@endsection
