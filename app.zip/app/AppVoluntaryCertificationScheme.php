<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppVoluntaryCertificationScheme extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'branch_id',
        'location',
        'managerial_staff',
        'evaluators',
        'support_staff',
        'technical_experts',
        'total'
    ];

    public function branch()
    {
        return $this->belongsTo('App\AppBranchAddress');
    }
}
