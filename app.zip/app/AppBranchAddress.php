<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppBranchAddress extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'branch_address',
        'branch_state',
        'branch_city',
        'branch_pin',
        'branch_web'
    ];

    public function scheme()
    {
        return $this->hasOne('App\AppVoluntaryCertificationScheme');
    }
}
