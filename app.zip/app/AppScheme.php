<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppScheme extends Model
{
    public function user()
    {
        return $this->hasOne(User::class, 'scheme');
    }
}
