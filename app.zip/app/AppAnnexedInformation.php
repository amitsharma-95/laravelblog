<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppAnnexedInformation extends Model
{
    protected $fillable = [
       'org_id',
       'app_id',
       'org_reg_cert',
       'ref_of_vol',
       'applicable_acc_stand',
       'related_to_vol',
       'branch_activity',
       'list_of_experts',
       'other_cert',
       'ref_of_any_vol',
       'any_other_rel',
    ];
}
