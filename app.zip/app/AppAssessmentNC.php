<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppAssessmentNC extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'app_id',
        'org_id',
        'assessor_id',
        'assessment_id',
        'nc_for',
        'topic',
        'type',
        'ref_no',
        'findings_of_assessment'
    ];
    protected $dates = ['deleted_at'];

    public function Reply()
    {
        return $this->HasMany(AppNcReply::class, 'nc_id');
    }

}
