<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppSchemeLevel extends Model
{
    //
}
