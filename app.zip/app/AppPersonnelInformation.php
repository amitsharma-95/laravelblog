<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppPersonnelInformation extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'quality_manager_name',
        'quality_manager_designation',
    ];
}
