<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppFinancialPerformance extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'financial_year',
        'total_income',
        'income_from_certification',
        'net_profit'
    ];
}
