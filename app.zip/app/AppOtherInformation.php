<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppOtherInformation extends Model
{
    protected $fillable = [
            'org_id',
            'app_id',
            'other_activities',
            'related_org',
            'major_clients',
            'no_of_certificates',
            'total_certificate_issued',
    ];
}
