<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppUserAllotment extends Model
{
    protected $fillable =[];

    public function adminUser()
    {
        return $this->belongsTo(AdminUser::class);
    }
}
