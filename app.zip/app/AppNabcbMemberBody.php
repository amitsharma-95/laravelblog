<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppNabcbMemberBody extends Model
{
    protected $fillable = [
            'org_id',
            'app_id',
            'nabcb_name',
            'nabcb_cert_no',
            'nabcb_valid_from',
            'nabcb_valid_to'
    ];
}
