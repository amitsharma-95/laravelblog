<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppAnnexedInfo extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'org_id','app_id','type','filename'
    ];
}
