<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppAssessmentReport extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'app_id',
        'org_id',
        'assessor_id',
        'doc_name',
        'doc_file'
    ];
}
