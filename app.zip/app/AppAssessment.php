<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppAssessment extends Model
{
    protected $fillable = [];
}
