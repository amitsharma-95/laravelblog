<?php

namespace App\Http\Controllers\UserRole;

use App\AdminUser;
use App\AppAssessment;
use App\ApplicationStatus;
use App\AppUserAllotment;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminUserRoleController extends Controller
{
    public function login()
    {
        return view('userrole.login');
    }

    public function UserRoleLogin(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            ]);
        $userCheck = AdminUser::where('username', $request->username)->where('isActive',0)->first();
        if(!$userCheck){
            return redirect('adminuser/login')->with('error','Username not Found!! Please Check and try again.');
        }else{
            $Checkpassword = AdminUser::where('username', $request->username)->where('password', $request->password)->where('isActive',0)->first();
            if($Checkpassword){
                // $request->session()->put('superAdmin',$userCheck->id);
                if ($Checkpassword->role_id == 2) {
                    session(['userRole'=>$Checkpassword]);
                return redirect('assessor/dashboard');
                } else {
                    session(['userRole'=>$Checkpassword]);
                return redirect('adminuser/dashboard');
                }
                
                
            }else{
                return redirect('adminuser/login')->with('error','Password Not Match!!');
            }
        }
    }

    public function AdminUserDashboard()
    {
        $loginuser = Session('userRole');
        // dd($adminuser);3
        $applicants = AppUserAllotment::where('alloted_to', $loginuser->id)->where('isActive',0)->count();
        // dd($allotment);
        // if ($allotment == null) {
        //     $applicants = 0;
        DB::connection()->enableQueryLog();
        $completed = AppUserAllotment::leftJoin('application_statuses', function($join) {
            $join->on('application_statuses.user_id', '=', 'app_user_allotments.org_id');
          })
          ->where('app_user_allotments.alloted_to','=', $loginuser->id)
          ->whereNotIn('application_statuses.stage', array('1A','0','1B','1C'))
          ->count();
          $queries = DB::getQueryLog();
              $last_query = end($queries); 
            // $completed = 0;
        // }else {
        //     // $applicants = User::where('id', $allotment->org_id)->get()->count();
        //     $completed = ApplicationStatus::where('user_id', $allotment->org_id)->where('stage', 2)->get()->count();
        // }
        // dd($applicants);
        
        // dd($application_status);
        // if ($application_status == 0) {
        //     $completed = 0;
        // }
        // if ($adminuser->role_id == 1) {
        //     // $stage = '1B'; 
        //     $applicants = User::with('applicationStatus')->whereHas('applicationStatus', function ($query) {
        //         return $query->where('stage', '!=', 0) ;
        //     })->get()->count() ;
        // }else{
        //     $applicants = '';
        // }   
        // dd($applicants);    
        // return view('userrole.dashboard', ['applicants'=>$applicants, 'completed'=>$completed]);
        return view('userrole.dashboard', ['applicants'=>$applicants, 'completed'=>$completed]);
    }

    public function SendToOrg($org_id)
    {
        $loginAssessor = Session('userRole');
        $update_status = ApplicationStatus::where('user_id',$org_id)->first();
        $update_status->updated_by = 'Dealing Officer_'.$loginAssessor->id;
        $update_status->stage = '2C';
        // dd($update_status);
        if($update_status->save()){
            return redirect('adminuser/allotment')->with('success', 'Application Sent to ORG for Acceptance!!');
        }
    }

    public function SendConfirmation($org_id)
    {
        $loginUser = Session('userRole');
        $get_assessor = AppAssessment::where('org_id',$org_id)->where('assessor_action','Accept')->where('cb_action','Accept')->where('isActive',0)->first();
        $alloted = AppUserAllotment::where('org_id',$org_id)->where('alloted_to',$get_assessor->assessor_id)->where('isActive',0)->first();
        // dd($alloted);
        if ($alloted != null) {
            $update_status = ApplicationStatus::where('user_id',$org_id)->where('stage','2D')->first();
            $update_status->stage = '2E';
            $update_status->updated_by = 'Dealing officer_'.$loginUser->id;
            // dd($update_status);
            if($update_status->save()){
                return redirect('adminuser/allotment')->with('success', 'Application has been send to assessor for assessment!!');
            }
        }
    }

    //logout
    function adminuserLogout(){
        session()->forget(['userRole']);
        return redirect('adminuser/login');
    }
}
