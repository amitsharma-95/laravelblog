<?php

namespace App\Http\Controllers\UserRole;

use App\AppAssessment;
use App\AppClosure;
use App\ApplicationStatus;
use App\AppUserAllotment;
use App\Clerification;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class ClosuerController extends Controller
{
    public function Clerification($app_id)
    {        
        $app = ApplicationStatus::where('id',$app_id)->where('isDeleted',0)->first();
        $user = User::where('id',$app->user_id)->first();
        $clerifications = Clerification::where('org_id',$user->id)->where('app_id',$app->id)->get();
        return view('userrole.clerification', ['user'=>$user,'app'=>$app,'clerifications'=>$clerifications]);
    }

    public function ClerificationSubmit(Request $request)
    {
        $loginuser = Session('userRole');
        // $assessment = AppAssessment::where('org_id',$request->org_id)->where('app_id',$request->app_id)->where('isActive',0)->first();
        $user_allotment = AppUserAllotment::where('org_id',$request->org_id)->where('app_id',$request->app_id)->where('alloted_by',$loginuser->id)->where('isActive',0)->first();
        $dest = public_path('/assets/images/clerification/');
        
        //1. file format org_id_app_id_random_time_filename
        if($request->hasFile('file')){
            $file_image = $request->file('file');
            $file = $request->org_id.'_'.$request->app_id.'_'.rand(10000, 99999).'_'.time().'_clerification.'. $file_image->getClientOriginalExtension();
            $file_image->move($dest, $file);
        }else{
            $file = "NA";
        }
        $clerification = new Clerification();
        $clerification->app_id = $request->app_id;
        $clerification->org_id = $request->org_id;
        $clerification->do_id = $loginuser->id;
        $clerification->assessor_id = $user_allotment->alloted_to;
        $clerification->file = $file;
        $clerification->clerification_for = $request->clerification_for;
        $clerification->clerification_by = "Dealing Officer";
        $clerification->clerification = $request->clerification;
        // dd($clerification->toArray());
        if($clerification->save()){
            return back()->with('success','Your Clerification report created successfully');
        }
        
    }

    public function Closuer($app_id)
    { 
        // dd($org_id);
        return view('userrole.closure',['app_id'=>$app_id]);
    }

    public function AssessmentClosuer(Request $request)
    {
        $loginuser = Session('userRole');
        $closure = new AppClosure();
        $closure->org_id = $request->org_id;
        $closure->app_id = $request->app_id;
        $closure->do_id = $loginuser->id;
        $closure->cert_no = $request->cert_no;
        $closure->status = $request->status;
        $closure->from_date = $request->from_date;
        $closure->to_date = $request->to_date;
        $closure->final_remark = $request->final_remark;
        if($closure->save()){
            $app_status = ApplicationStatus::where('id',$request->app_id)->where('user_id',$request->org_id)->first();
            $app_status->stage = '4';
            $app_status->updated_by =  'DO_'.$loginuser->id;
            if($app_status->save()){
            return back()->with('success', 'Application has been close Now!!');
            }
        }
    }

    public function Certificate()
    {
        return view('applicationform.certificate');
    }
}
