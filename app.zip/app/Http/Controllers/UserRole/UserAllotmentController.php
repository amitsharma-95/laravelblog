<?php

namespace App\Http\Controllers\UserRole;

use App\AdminUser;
use App\AppAssessment;
use App\AppAssessmentNC;
use App\AppAssessmentReport;
use App\ApplicationStatus;
use App\AppMail;
use App\AppNcReply;
use App\AppReply;
use App\AppUserAllotment;
use App\Http\Controllers\Controller;
use App\Mail\ApplicationMail;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class UserAllotmentController extends Controller
{
    
    public function index()
    {
        // $app = array();
        $adminuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $adminuser->id)->where('isActive',0)->get();
        // return view('userrole.applicants', ['app' => $app]);
        return view('userrole.applicants', ['allotments' => $allotments]);
    }

    public function Pending()
    {
        $adminuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $adminuser->id)->where('isActive',0)->get();
        return view('userrole.pending', ['allotments' => $allotments]);
    }

    public function Processing()
    {
        $adminuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $adminuser->id)->where('isActive',0)->get();
        return view('userrole.processing', ['allotments' => $allotments]);
    }

    public function Closed()
    {
        $adminuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $adminuser->id)->where('isActive',0)->get();
        return view('userrole.closed', ['allotments' => $allotments]);
    }

    public function AllotedAssessor()
    {
        $loginuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginuser->id)->where('isActive',0)->get();
        
        return view('userrole.assessor.allotedassessor', ['allotments' => $allotments]);
    }

    public function AssessmentInProcess()
    {
        $loginuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginuser->id)->where('isActive',0)->get();
        
        return view('userrole.assessor.assessmentinprocess', ['allotments' => $allotments]);
    }

    public function NotAllotedAssessor()
    {
        $loginuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginuser->id)->where('isActive',0)->get();
        
        return view('userrole.assessor.notalloted', ['allotments' => $allotments]);
    }

    public function Allotment()
    {
        $loginuser = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginuser->id)->where('isActive',0)->get();
        
        // dd($applicants);
        return view('userrole.assessor.index', ['allotments' => $allotments]);
    }

    public function AllotAssessor($app_id)
    {
        $dealing_officer = Session('userRole');
        $app = ApplicationStatus::where('id', $app_id)->where('isDeleted',0)->first();
        
        $org = User::where('id',$app->user_id)->first();
        $role_users = AdminUser::where('role_id', 2)->get();
        return view('userrole.assessor.allotment', [
            'app_id' => $app_id,'org'=>$org,'role_users' => $role_users
        ]);
    }

    public function AssessorAllotment(Request $request)
    {
        // dd($request->all());
        $ip = $request->ip();
        $org_id = $request->org_id;
        $app_id = $request->app_id;
        $dealing_officer = Session('userRole');
        $app = ApplicationStatus::where('id', $app_id)->where('user_id', $org_id)->whereIn('stage', array('2','2C','2BO','2D'))->first();
        // dd($app);
        // if ($app == null) {
        //     $app = ApplicationStatus::where('id', $app_id)->where('user_id', $org_id)->where('stage', '2C')->first();
        //     if ($app == null) {
        //         $app = ApplicationStatus::where('id', $app_id)->where('user_id', $org_id)->where('stage', '2BO')->first();
        //     }
        // }
        // dd($app);
        // $app_id = $app->id;
        AppUserAllotment::where('org_id',$org_id)->where('app_id',$app_id)->where('alloted_to',$request->alloted_to)
        ->where('alloted_by',$dealing_officer->id)->where('isActive',0)->update(['isActive'=>1]);
        $app->stage = "2A";
        if ($app->save()) {
            $alloted_user = new AppUserAllotment();
            $alloted_user->org_id = $org_id;
            $alloted_user->app_id = $app_id;
            $alloted_user->alloted_by = $dealing_officer->id;
            $alloted_user->alloted_to = $request->alloted_to;
            $alloted_user->ip = $ip;
            $alloted_user->type = "Assessor";
            // dd($alloted_user);
            if ($alloted_user->save()) {
                $assessment = new AppAssessment();
                $assessment->org_id = $org_id;
                $assessment->app_id = $app_id;
                $assessment->assessor_id = $request->alloted_to;
                $assessment->from_date = $request->from_date;
                $assessment->to_date = $request->to_date;
                $assessment->assessment_type = $request->assessment_type;
                // $assessment->assessor_action = 
                if ($assessment->save()) {
                    $user = User::where('id', $org_id)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name', 'Assessor Alloted')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        $user = AdminUser::where('id',$assessment->assessor_id)->first();
                        $mail =  AppMail::where('template_name', 'Alloted Application for Assessor')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                        if (Mail::failures() != 0) {
                            return redirect('adminuser/allotment')->with('success', 'Assessor Alloted Successfully!!');
                        }
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
                }
            }
        }
    }

    public function viewNcReplies($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        $user = User::where('id',$app->user_id)->first();
        $dealing_officer = Session('userRole');
        // $alloted = AppUserAllotment::where('org_id',$org_id)->where('app_id',$app->id)->get();
        // dd($alloted);
        $allotment = AppUserAllotment::where('org_id',$app->user_id)->where('app_id',$app->id)->where('alloted_by',$dealing_officer->id)->first();
        // dd($allotment->toArray());
        $all_ncs = AppAssessmentNC::where('org_id',$app->user_id)->where('app_id',$app->id)->where('assessor_id',$allotment->alloted_to)->get();
        // $replies = AppNcReply::where('org_id',$org_id)->where('app_id',$app->id)->where('assessor_id',$assessment->assessor_id)
        // ->where('assessment_id',$assessment->assessment_id)->where('nc_id',$assessment->id)->get();
        $assessment_reports = AppAssessmentReport::where('org_id',$app->user_id)->where('app_id',$app->id)->where('assessor_id',$allotment->alloted_to)->get();
        // dd($allotment->toArray());
        return view('userrole.viewncreplies', ['app'=>$app,'org_id'=>$app->user_id,'dealing_officer'=>$dealing_officer,'all_ncs'=>$all_ncs,'allotment'=>$allotment,
    'assessment_reports'=>$assessment_reports]);
    }

    public function ViewReplies($nc_id)
    {
        $replies = AppNcReply::where('nc_id',$nc_id)->get();
        return view('userrole.viewreplies',['replies'=>$replies,'nc_id'=>$nc_id]);
    }
}
