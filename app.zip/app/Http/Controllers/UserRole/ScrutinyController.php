<?php

namespace App\Http\Controllers\UserRole;

use App\AdminUser;
use App\AppAnnexedInformation;
use App\AppBranchAddress;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\AppIafMemberBody;
use App\ApplicationStatus;
use App\AppMail;
use App\AppNabcbMemberBody;
use App\AppOtherApprovalGovt;
use App\AppOtherInformation;
use App\AppPersonnelInformation;
use App\AppScheme;
use App\AppScrutiny;
use App\AppVoluntaryCertificationScheme;
use App\Http\Controllers\Controller;
use App\Mail\ApplicationMail;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ScrutinyController extends Controller
{
    public function index($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        $scheme = AppScheme::where('id',$app->scheme)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.index', ['app'=>$app,'scheme'=>$scheme,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    } 

    public function personnelScrutiny($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.personnal', ['app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    }

    public function otherScrutiny($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.other', ['app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    }

    public function financialScrutiny($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.financial', ['app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    }

    public function annexedScrutiny($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.annexed', ['app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    }

    public function finalScrutiny($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        // dd($app_status);
        $user = User::where('id', $app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted',0)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $scrutiny_GI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
        $scrutiny_PI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
        $scrutiny_OI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
        $scrutiny_FI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
        $scrutiny_AI = AppScrutiny::where('org_id', $user->id)->where('app_id', $app->id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
        return view('userrole.scrutiny.final', ['app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances, 'scrutiny_GI' => $scrutiny_GI,
            'scrutiny_PI' => $scrutiny_PI, 'scrutiny_OI' => $scrutiny_OI, 'scrutiny_FI' => $scrutiny_FI, 'scrutiny_AI' => $scrutiny_AI, 'annexed_info' => $annexed_info
        ]);
    }

    public function store(Request $req)
    {
        // dd($req->all());
        $req->validate([
            'option'=>'required',
        ]);
        $app = ApplicationStatus::where('id', $req->app_id)->where('user_id', $req->org_id)->first();
        $update_stage = AppScrutiny::where('id', $req->id)->where('org_id', $req->org_id)
            ->where('app_id', $app->id)->where('scrutiny_for', $req->scrutiny_for)->where('isActive', 0)->first();
        if ($update_stage == null) {
            $scrutiny = new AppScrutiny();
            $scrutiny->org_id = $req->org_id;
            $scrutiny->app_id = $app->id;
            $scrutiny->alloted_user_id = $req->alloted_user_id;
            $scrutiny->option = $req->option;
            $scrutiny->remark = $req->remark;
            $scrutiny->scrutiny_for = $req->scrutiny_for;
            if ($scrutiny->save()) {
                return back()->with('success', 'Remarks has been save for this Information!!');
            }
        } else {
            $update_stage->isActive = "1";
            // dd($update);
            if ($update_stage->save()) {
                $scrutiny = new AppScrutiny();
                $scrutiny->org_id = $req->org_id;
                $scrutiny->app_id = $app->id;
                $scrutiny->alloted_user_id = $req->alloted_user_id;
                $scrutiny->option = $req->option;
                $scrutiny->remark = $req->remark;
                $scrutiny->scrutiny_for = $req->scrutiny_for;
                if ($scrutiny->save()) {
                    return back()->with('success', 'Remarks has been save for this Information!!');
                }
            }
        }
    }

    public function SendToCB(Request $req)
    {
        $updated_by = Session('userRole');
        $update_status = ApplicationStatus::where('id', $req->app_id)->where('user_id', $req->org_id)->where('isDeleted',0)->first();
        $update_status->stage = '1B';
        $update_status->updated_by = $updated_by->id;
        // dd($update_status);
        if ($update_status->save()) {
            $user = User::where('id', $req->org_id)->first();
            // dd($user->email);
            $mail =  AppMail::where('template_name', 'Scrutiny Report to CB')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                    return redirect('adminuser/alloted')->with('success', 'Scrutiny Report Send to CB For Review!!');
                // }
            }
            return back()->with('message', 'Failed! there is some issue with email provider');
            // return redirect('adminuser/alloted');
        }
    }

    public function ScrutinyClose($app_id)
    {
        $updated_by = Session('userRole');
        $update_stage = ApplicationStatus::where('id', $app_id)->first();
        $update_stage->stage = 2;
        $update_stage->updated_by = $updated_by->id;
        if ($update_stage->save()) {
            $user = User::where('id', $update_stage->user_id)->first();
            // dd($user->email);
            $mail =  AppMail::where('template_name', 'Scrutiny Closed')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                return redirect('adminuser/alloted')->with('success', 'Scrutiny Completed Successfully. Allot Assessor for Assessment Process!!');
            }
            return back()->with('message', 'Failed! there is some issue with email provider');
            
        }
    }
}
