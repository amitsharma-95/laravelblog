<?php

namespace App\Http\Controllers;

use App\AppIafMemberBody;
use App\ApplicationStatus;
use App\AppNabcbMemberBody;
use App\AppOtherApprovalGovt;
use App\AppOtherInformation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OtherInformationController extends Controller
{
    public function index($app_id)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        // $app_id = $app_status->id;
        $other_information = AppOtherInformation::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->first();
        if ($other_information == null) {
            $other_information = '';
        }
        $nabcb_members = AppNabcbMemberBody::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($nabcb_members == null) {
            $nabcb_members = [];
        }
        $iaf_members = AppIafMemberBody::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($iaf_members == null) {
            $iaf_members = [];
        }
        $govt_other_approvals = AppOtherApprovalGovt::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($govt_other_approvals == null) {
            $govt_other_approvals = [];
        }
        return view('applicationform.other-information', ['app_id'=>$app_id,'other_information' => $other_information, 'nabcb_members' => $nabcb_members, 'iaf_members' => $iaf_members, 'govt_other_approvals' => $govt_other_approvals]);
    }
 
    public function store(Request $request)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        $app_id = $request->app_id;

        // dd($request->all());
        //NABCB
        $nabcb_id = $request->nabcb_id;
        $nabcb_name = $request->nabcb_name;
        $nabcb_cert_no = $request->nabcb_cert_no;
        $nabcb_valid_from = $request->nabcb_valid_from;
        $nabcb_valid_to = $request->nabcb_valid_to;

        for ($i = 0; $i < count($nabcb_name); $i++) {
            if ($nabcb_name[$i] != null && $nabcb_cert_no[$i] != null && $nabcb_valid_from[$i] != null && $nabcb_valid_to[$i] != null) {
                // DB::connection()->enableQueryLog();
                $checkNabcb = AppNabcbMemberBody::where('id', $nabcb_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
                // $queries = DB::getQueryLog();
                // $last_query = end($queries);
                // dd($last_query);  
                $datasave = [
                    'org_id' => $org_id,
                    'app_id' => $app_id,
                    'nabcb_name' => $nabcb_name[$i],
                    'nabcb_cert_no' => $nabcb_cert_no[$i],
                    'nabcb_valid_from' => $nabcb_valid_from[$i],
                    'nabcb_valid_to' => $nabcb_valid_to[$i],
                ];
                if ($checkNabcb == null) {
                    // dd("inserted");
                    DB::table('app_nabcb_member_bodies')->insert($datasave);
                } else {
                    // dd("updated");
                    DB::table('app_nabcb_member_bodies')->where('id', $nabcb_id[$i])->update($datasave);
                }
            }
        }
        //2. IAF
        $iaf_id = $request->iaf_id;
        $iaf_name = $request->iaf_name;
        $iaf_cert_no = $request->iaf_cert_no;
        $iaf_valid_from = $request->iaf_valid_from;
        $iaf_valid_to = $request->iaf_valid_to;
        for ($i = 0; $i < count($iaf_name); $i++) {
            if ($iaf_name[$i] != null && $iaf_cert_no[$i] != null && $iaf_valid_from[$i] != null && $iaf_valid_to[$i] != null) {
                // DB::connection()->enableQueryLog();
                $check_iaf = AppIafMemberBody::where('id', $iaf_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
                $queries = DB::getQueryLog();
                $last_query = end($queries);
                // dd($last_query);  
                $datasave = [
                    'org_id' => $org_id,
                    'app_id' => $app_id,
                    'iaf_name' => $iaf_name[$i],
                    'iaf_cert_no' => $iaf_cert_no[$i],
                    'iaf_valid_from' => $iaf_valid_from[$i],
                    'iaf_valid_to' => $iaf_valid_to[$i],
                ];
                if ($check_iaf == null) {
                    // dd("inserted");
                    DB::table('app_iaf_member_bodies')->insert($datasave);
                } else {
                    // dd("updated");
                    DB::table('app_iaf_member_bodies')->where('id', $iaf_id[$i])->update($datasave);
                }
            }
        }

        //2. Other Govt Approvals
        $govt_other_approvals_id = $request->govt_other_approvals_id;
        $govt_other_approvals_name = $request->govt_other_approvals_name;
        $govt_other_approvals_cert_no = $request->govt_other_approvals_cert_no;
        $govt_other_approvals_valid_from = $request->govt_other_approvals_valid_from;
        $govt_other_approvals_valid_to = $request->govt_other_approvals_valid_to;
        
            for ($i = 0; $i < count($govt_other_approvals_name); $i++) {
                if ($govt_other_approvals_name[$i] != null && $govt_other_approvals_cert_no[$i] != null && $govt_other_approvals_valid_from[$i] != null && $govt_other_approvals_valid_to[$i] != null) {
                // DB::connection()->enableQueryLog();
                $checkOther_approvals = AppOtherApprovalGovt::where('id', $govt_other_approvals_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
                $queries = DB::getQueryLog();
                $last_query = end($queries);
                // dd($last_query);  
                $datasave = [
                    'org_id' => $org_id,
                    'app_id' => $app_id,
                    'other_name' => $govt_other_approvals_name[$i],
                    'other_cert_no' => $govt_other_approvals_cert_no[$i],
                    'other_valid_from' => $govt_other_approvals_valid_from[$i],
                    'other_valid_to' => $govt_other_approvals_valid_to[$i],
                ];
                if ($checkOther_approvals == null) {
                    // dd("inserted");
                    DB::table('app_other_approval_govts')->insert($datasave);
                } else {
                    // dd("updated");
                    DB::table('app_other_approval_govts')->where('id', $govt_other_approvals_id[$i])->update($datasave);
                }
            }
        }

        $other_information = AppOtherInformation::updateOrCreate(
                [
                    'org_id' => $org_id,
                    'app_id' => $app_id,
                ],
                [
                    'other_activities' => $request->other_activities,
                    'related_org' => $request->related_org,
                    'major_clients' => $request->major_clients,
                    'no_of_certificates' => $request->no_of_certificates,
                    'total_certificate_issued' => $request->total_certificate_issued
                ]
            );
            if ($other_information) {
                return back()->with('success', 'Changes has been saved successfully!!');
            }
    }

    //delete NABCB
    public function deleteNabcb($id)
    {
        $financial_address = AppNabcbMemberBody::find($id);
        $financial_address->isDeleted = "1";
        $financial_address->save();
        return back()->with('success', 'Record Deleted Successfully!!');
    }

    //delete IAF
    public function deleteIAF($id)
    {
        $financial_address = AppIafMemberBody::find($id);
        $financial_address->isDeleted = "1";
        $financial_address->save();
        return back()->with('success', 'Record Deleted Successfully!!');
    }

    //delete Other
    public function deleteOther($id)
    {
        $financial_address = AppOtherApprovalGovt::find($id);
        $financial_address->isDeleted = "1";
        $financial_address->save();
        return back()->with('success', 'Record Deleted Successfully!!');
    }
}
