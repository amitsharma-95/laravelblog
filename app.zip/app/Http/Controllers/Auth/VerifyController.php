<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\VerifyOTP;
use App\User;
use App\VerifyEmail;
use App\VerifyMobile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class VerifyController extends Controller
{
    public function verify_OTP(Request $request)
    {
        $user = User::where('email', $request->email)->first();
        if (!$user) {
            $mailbefore = VerifyEmail::where('email', $request->email)->first();
            if ($mailbefore) {
                $mailbefore->delete();
            }
            $otp = rand(100000, 999999);
            $verifydata = new VerifyEmail();
            $verifydata->email = $request->email;
            $verifydata->otp = $otp;
            $verifydata->is_verified = '0';
            if ($verifydata->save()) {
                Mail::to($request->email)->send(new VerifyOTP($otp));
                return 1;
            } else {
                return 2;
            }
        }else{
            return 3;
        }
    }

    public function is_verified(Request $request)
    {
        $verifyEmail = VerifyEmail::where('otp', $request->otp)->where('is_verified', 0)->first();
        if ($verifyEmail) {
            $verifyEmail->is_verified = '1';
            $verifyEmail->save();
            return 1;
        } else {
            return 0;
        }
    }

    public function verifyMobile_OTP(Request $request)
    {
        $user = User::where('mobile', $request->mobile)->first();
        if (!$user) {
        $mobilebefore = VerifyMobile::where('mobile', $request->mobile)->first();
        if ($mobilebefore) {
            $mobilebefore->delete();
        }
        $otp = rand(100000, 999999);
        $verifydata = new VerifyMobile();
        $verifydata->mobile = $request->mobile;
        $verifydata->otp = $otp;
        $verifydata->is_verified = '0';
        $verifydata->save();
        $authKey = "101399ABRiGsKU55684e346";
        $msg = "Your OTP from SVNQCI is " . $otp . " . Please use this OTP to login.";
        //Multiple mobiles numbers separated by comma
        $mobileNumber = $request->mobile;
        // $mobileNumber = "7982151615";

        //Sender ID,While using route4 sender id should be 6 characters long.
        $senderId = "SVNTCH";

        //Your message to send, Add URL encoding here.
        $message = urlencode($msg);

        //Define route
        $route = 4;
        $country = 91;
        //Prepare you post parameters
        $postData = array(
            'authkey' => $authKey,
            'mobiles' => $mobileNumber,
            'message' => $message,
            'sender' => $senderId,
            'country' => $country,
            'route' => $route,
            'DLT_TE_ID' => "1307161233114221506"
        );

        //API URL
        $url = "http://api.msg91.com/api/sendhttp.php";

        // init the resource
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
            //,CURLOPT_FOLLOWLOCATION => true
        ));


        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


        //get response
        $output = curl_exec($ch);

        //Print error if any
        if (curl_errno($ch)) {
            echo 'error:' . curl_error($ch);
        }

        curl_close($ch);
        // dd($output);
        if ($output) {
            return 1;
        } else {
            return 0;
        }
    }else{
        return 2;
    }
    }

    public function Mobile_verified(Request $request)
    {
        $verifyMobile = VerifyMobile::where('otp', $request->otp)->where('is_verified', 0)->first();
        if ($verifyMobile) {
            $verifyMobile->is_verified = '1';
            $verifyMobile->save();
            return 1;
        } else {
            return 0;
        }
    }

    // public function check_mail(Request $req )
    // {
    //     $alreadyReg = User::where('email', $req->email)->first();
    //     if(!$alreadyReg){
    //         return json_encode(array("statusCode"=>201));
    //     }else{
    //         return json_encode(array("statusCode"=>200));
    //     }
    // }
}
