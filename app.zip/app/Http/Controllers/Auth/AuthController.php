<?php

namespace App\Http\Controllers\Auth;

use App\ApplicationStatus;
use App\AppScheme;
use App\AppSchemeLevel;
use App\Http\Controllers\Controller;
use App\Mail\LoginDetail;
use App\User;
use App\VerifyEmail;
use App\VerifyMobile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class AuthController extends Controller
{
    //register
    public function index(){
        $schemes = AppScheme::where('isDeleted', 0)->get();
        return view('auth.register', ['schemes'=>$schemes]);
    }

    //Scheme Level
    public function SchemeLevel()
    {
        $scheme_id = request('scheme_id');
        $scheme_levels = AppSchemeLevel::where('scheme_id', $scheme_id)->get();
        $option = "<option value=''>----Select Level Of Scheme----</option>";
        foreach ($scheme_levels as $level) {
            // $option .= "<option value='".$state->name."'>".$state->name."'</option>";
            $option .= "<option value='".$level->scheme_level."'>".$level->scheme_level."</option>";
        }
        return $option;
    }

     //Store
    public function store(Request $req){
        // dd('success');
        $CheckEmail = VerifyEmail::where('email', $req->email)->where('is_verified', 1)->first();
        if($CheckEmail){
             $CheckMobile = VerifyMobile::where('mobile', $req->mobile)->where('is_verified', 1)->first();
             if (!$CheckMobile) {
                return json_encode(array("statusCode"=>202));
             }
        }else{
            return json_encode(array("statusCode"=>203));
        }
        $alreadyReg = User::where('email', $req->email)->first();
        if($alreadyReg){
            return json_encode(array("statusCode"=>204));
        }
        $MalreadyReg = User::where('mobile', $req->mobile)->first();
        if($MalreadyReg){
            return json_encode(array("statusCode"=>205));
        }
        
        $val = $CheckEmail->id;
        $length = 4;
        $username = "QRG".str_pad($val,$length,"0",STR_PAD_LEFT);
        $password = rand(100000, 999999);
        $users = new User();
        $users->name = $req->name;
        $users->org_name = $req->org_name;
        $users->email = $req->email;
        $users->mobile = $req->mobile;
        $users->country = $req->country;
        $users->username = $username;
        $users->password = Hash::make($password);
        // dd($users);
        if($users->save())
        {
            // $application = new ApplicationStatus();
            // $application->user_id = $users->id;
            // $application->type = "IA";
            // $application->stage = 0;
            // if ($application->save()) {
                // $users = User::where('id', $users->id)->first();
                // $users->is_first_time = 2;
                // // dd($users);
                // if ($users->save()) {
                    // return redirect('application-form');;
                    Mail::to($req->email)->send(new LoginDetail($req->name, $username, $password));
                    return json_encode(array("statusCode"=>200));
                // }
            // }
           
        }else {
            echo json_encode(array("statusCode"=>201));
        }

    }

    //login
    function submit_login(Request $request){
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            // 'g-recaptcha-response' => 'required|captcha',
        ]);
        $checkUsername = User::where('username', $request->username)->first();
        // if ($user) {
        //     $email = $user->email;
        //     return view('auth.change-password', compact('email'));
        // }
        if ($checkUsername) {
            $password = Hash::check($request->password, $checkUsername->password);
            if ($password) {
                $isfirstTime = User::where('username', $request->username)->where('is_first_time', 0)->first();
                $SecondTime = User::where('username', $request->username)->where('is_first_time', 1)->first();
                if($isfirstTime){
                    // session(['user_id'=>$isfirstTime->id]);
                    // return redirect('/dashboard');
                $username = $checkUsername->username;
                return view('auth.change-password', compact('username'));
                }elseif($SecondTime){
                    session(['user_id'=>$SecondTime->id]);
                    return redirect('/dashboard');
                }else{
                    $user = User::where('username', $request->username)->where('is_first_time', 2)->first();
                    // $app_id = ApplicationStatus::where('user_id', $user->id)->first();
                    if($user){
                        // dd($user);
                        session(['user_id'=>$user->id]);
                    return redirect('/dashboard');
                        // session(['user_id'=>$user->id,'app_id'=>$app_id->id]);
                        // $cehckSatge = ApplicationStatus::where('user_id', $user->id)->first();
                        // if ($cehckSatge->stage == 0 || $cehckSatge->stage == '1B' ) {
                        //     session(['user_id'=>$user->id]);
                        // return redirect('application-form');
                        // } else {
                        //     session(['user_id'=>$user->id]);
                        //     return redirect('application');
                        // }
                    }else{
                        return redirect('/login')->with('error','Password Not Match!!');
                    }
                    
                    // return view('applicationform.form', ['user'=>$user]);
                }
            }
            return back()->with('failed', 'Failed! Invalid password');
        }
        return back()->with('failed', 'Username Not Found!!!');
        // $userCheck = User::where(['email'=>$request->email,'password'=>$request->password])->count();
        // if($userCheck > 0){
        //     $userData = User::where(['email'=>$request->email,'password'=>$request->password])->first();
        //     session(['userData'=>$userData]);
        //     return redirect('/')->with('success', 'Success');
        // }else{
        //     return redirect('/login')->with('error','Invalid email/Password');
        // }
    }

    //login
    public function login()
    {
        return view('auth.login');
    }

    //logout
    function logout(){
        session()->forget(['user_id']);
        return redirect('/login');
    }

    public function test(){
        $authKey = "101399ABRiGsKU55684e346";
        $otpNo = "12345";
        $msg = "Your OTP from SVNQCI is ".$otpNo." . Please use this OTP to login.";
                //Multiple mobiles numbers separated by comma
                $mobileNumber = "7982151615";

                //Sender ID,While using route4 sender id should be 6 characters long.
                $senderId = "SVNTCH";

                //Your message to send, Add URL encoding here.
                $message = urlencode($msg);

                //Define route
                $route = 4;
                $country = 91;
                //Prepare you post parameters
                $postData = array(
                    'authkey' => $authKey,
                    'mobiles' => $mobileNumber,
                    'message' => $message,
                    'sender' => $senderId,
                    'country' => $country,
                    'route' => $route,
                    'DLT_TE_ID' => "1307161233114221506"
                );

                //API URL
                $url="http://api.msg91.com/api/sendhttp.php";

                // init the resource
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $postData
                    //,CURLOPT_FOLLOWLOCATION => true
                ));


                //Ignore SSL certificate verification
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


                //get response
                $output = curl_exec($ch);

                //Print error if any
                if(curl_errno($ch))
                {
                    echo 'error:' . curl_error($ch);
                }

                curl_close($ch);

                echo $output;
                    }
}
