<?php

namespace App\Http\Controllers;

use App\Admin;
use App\AdminUser;
use App\AppAnnexedInfo;
use App\AppAnnexedInformation;
use App\AppAssessment;
use App\AppAssessmentNC;
use App\AppAssessmentReport;
use App\AppBranchAddress;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\AppIafMemberBody;
use App\ApplicationStatus;
use App\AppMail;
use App\AppNabcbMemberBody;
use App\AppNcReply;
use App\AppOtherApprovalGovt;
use App\AppOtherInformation;
use App\AppPersonnelInformation;
use App\AppScheme;
use App\AppUserAllotment;
use App\AppVoluntaryCertificationScheme;
use App\Mail\ApplicationMail;
use App\Notifications\SubmitNotification;
use App\Notifications\TestNotification;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Notification;

// use PDF;


class HomeController extends Controller
{
    function index()
    {
        $user_id = session('user_id');
        $user =  User::where('id',$user_id)->first();
        $apps = ApplicationStatus::where('user_id',$user->id)->where('isDeleted',0)->get();
        $schemes = AppScheme::where('isDeleted', 0)->get();
        return view('applicationform.dashboard', ['user_id'=>$user_id,'user'=>$user,'apps'=>$apps,'schemes'=>$schemes]);
    }

    function Create(Request $request)
    {
        // dd($request->all());
        $application_status = new ApplicationStatus();
        $application_status->user_id = $request->user_id;
        $application_status->type = "IA";
        $application_status->stage = '0';
        $application_status->scheme = $request->scheme;
        $application_status->level = $request->level;
        // dd($application_status->toArray());
        if ($application_status->save()) {
                // return redirect('application-form')->with('success','Application for this scheme has been created successfully!!');
                return back()->with('success','Application for this scheme has been created successfully!!');
        }
    }

    public function SubmittedApp($app_id)
    {
        $user_id = session('user_id');
        $app = ApplicationStatus::where('id', $app_id)->where('user_id', $user_id)->first();
        $assessment = AppAssessment::where('org_id', $user_id)->where('app_id', $app->id)->where('isActive', 0)->first();
        $user = User::where('id', $user_id)->first();
        return view('applicationform.submitapplication', ['user' => $user,'app'=>$app,'login_user' => $user_id]);
    }

    function Preview($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        $scheme = AppScheme::where('id',$app->scheme)->first();
        $user = User::where('id',$app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted', 0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        // $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $org_reg_cert = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Organization Registration Certificate and Memorandum or Articles of Association')->where('isActive', 0)->first();
        $ref_of_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Master List of Documents reference of voluntary certification scheme')->where('isActive', 0)->first();
        $applicable_acc_stand = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Quality Manual by applicable accreditation standard')->where('isActive', 0)->first();
        $related_to_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Documentation relating to voluntary certification scheme')->where('isActive', 0)->first();
        $branch_activity = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Branch Office with activities to be covered under approval')->where('isActive', 0)->first();
        $list_of_experts = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'List of Managerial Personnel, Auditors')->where('isActive', 0)->first();
        $other_cert = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Other Documents')->where('isActive', 0)->first();
        $ref_of_any_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Reference of any voluntary certification scheme')->where('isActive', 0)->first();
        $any_other_rel = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Any other relevant information')->where('isActive', 0)->first();
        $pdf = PDF::loadView('applicationform.application-priview', ['scheme'=>$scheme,'app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances,
            'org_reg_cert' => $org_reg_cert, 'ref_of_vol' => $ref_of_vol, 'applicable_acc_stand' => $applicable_acc_stand, 'related_to_vol' => $related_to_vol,
            'branch_activity' => $branch_activity, 'list_of_experts' => $list_of_experts, 'other_cert' => $other_cert, 'ref_of_any_vol' => $ref_of_any_vol, 'any_other_rel' => $any_other_rel
        ]);
        return $pdf->stream();
    }

    public function SendBack($app_id)
    {
        $update_stage = ApplicationStatus::where('id', $app_id)->first();
        $update_stage->stage = '1C';
        if ($update_stage->save()) {
            $loginuser = User::where('id', $update_stage->user_id)->first();
            $allotment = AppUserAllotment::where('org_id',$loginuser->id)->where('app_id',$app_id)->first();
            $user = AdminUser::where('id',$allotment->alloted_to)->first();
            // dd($user->email);
            $mail =  AppMail::where('template_name', 'Scrutiny Reply By CB')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                return redirect()->route('submitted.application',[$app_id])->with('success','Application send back to DO for Scrutiny Again!!');
                // }
            }
            return back()->with('message', 'Failed! there is some issue with email provider');
            // return redirect('adminuser/alloted');
       
        }
    }

    public function SubmitForm()
    {

        $org_id = session('user_id');
        $app = ApplicationStatus::where('user_id', $org_id)->first();
        $gen_info = AppGeneralInfo::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $personnel_info = AppPersonnelInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $other_info = AppOtherInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $financial_info = AppFinancialPerformance::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $annexed_info = AppAnnexedInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $total_count = $gen_info + $personnel_info + $other_info + $financial_info + $annexed_info;

        if ($gen_info == 0) {
            return redirect('/application-form')->with('success', 'You have to fill these detail first for final submit!!');
        } elseif ($personnel_info == 0) {
            return redirect('/personnel-information')->with('success', 'You have to fill these detail first for final submit!!');
        } elseif ($other_info == 0) {
            return redirect('/other-information')->with('success', 'You have to fill these detail first for final submit!!');
        } elseif ($financial_info == 0) {
            return redirect('/financial-performance')->with('success', 'You have to fill these detail first for final submit!!');
        } elseif ($annexed_info == 0) {
            return redirect('/annexed-information')->with('success', 'You have to fill these detail first for final submit!!');
        } else {
            dd('success');
            // $user_id = session('user_id');
            if ($total_count == 5) {
                $update_stage = ApplicationStatus::where('user_id', $org_id)->first();
                $update_stage->stage = '1A';
                if ($update_stage->save()) {
                    return redirect('application');
                }
            }
        }
    }

    public function Action(Request $request)
    {
        if ($request->cb_action == 'Reject') {
            $request->validate([
                'cb_remark' => 'required'
            ]);
        }
        
        $update_assessment = AppAssessment::where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('isActive', 0)->first();
        $allotment = AppUserAllotment::where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('alloted_to',$update_assessment->assessor_id)->where('isActive', 0)->first();
        $update_assessment->cb_action = $request->cb_action;
        $update_assessment->cb_remark = $request->cb_remark;
        // dd($update_assessment);
        if ($request->cb_action == 'Accept') {
            // dd($allotment);
            if ($update_assessment->save()) {
                $update_status = ApplicationStatus::where('id', $request->app_id)->where('user_id', $request->org_id)->first();
                $update_status->stage = '2E';
                $update_status->updated_by = 'ORG_'. $request->org_id;
                if ($update_status->save()) {
                    $user = AdminUser::where('id', $allotment->alloted_by)->first();
                    // dd($user);
                    $mail =  AppMail::where('template_name', 'CB Acceptance Sent to DO')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        $user = AdminUser::where('id',$request->assessor_id)->first();
                        $mail =  AppMail::where('template_name', 'CB Acceptance Sent to Assessor')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                        if (Mail::failures() != 0) {
                            return back()->with('success', 'Acceptance Action Remark has been send to DO!!');
                        }
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
                    
                }
            }
        } else {
            // dd("else");
            $update_assessment->isActive = '1';
            if ($update_assessment->save()) {
                $update_status = ApplicationStatus::where('id', $request->app_id)->where('user_id', $request->org_id)->first();
                $update_status->stage = '2D';
                $update_status->updated_by = 'ORG_' . $request->org_id;
                if ($update_status->save()) {
                    $user = AdminUser::where('id', $allotment->alloted_by)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name','CB Acceptance Sent to DO')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        $user = AdminUser::where('id',$request->assessor_id)->first();
                        $mail =  AppMail::where('template_name','CB Acceptance Sent to Assessor')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                        if (Mail::failures() != 0) {
                            return back()->with('success', 'Acceptance Action Remark has been send to DO!!');
                        }
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
                }
            }
        }
    }

    public function NCReply($app_id)
    {
        $org_id = session('user_id');
        $application = ApplicationStatus::where('id', $app_id)->where('user_id',$org_id)->first();
        $all_ncs =  AppAssessmentNC::where('org_id', $org_id)->where('app_id', $application->id)->get();
        // $replies = AppNcReply::where('org_id',$org_id)->where('app_id',$application->id)->where('nc_id',7)->get();
        // dd($replies->toArray());
        $replies = AppNcReply::join('app_replies', 'app_nc_replies.id', '=', 'app_replies.reply_to')
            ->where('org_id', $org_id)->where('app_id', $application->id)->get([
                'app_nc_replies.reply_by', 'app_nc_replies.reply', 'app_nc_replies.created_at', 'app_replies.assessor_reply', 'app_replies.updated_at'
            ]);
        //         dd($replies->toArray());
        return view('applicationform.nc-reports', ['all_ncs' => $all_ncs, 'application' => $application, 'replies' => $replies]);
    }

    public function ReplyNC($nc_id)
    {
        $org_id = session('user_id');
        // $application = ApplicationStatus::where('user_id', $org_id)->first();

        $replies = AppNcReply::where('org_id', $org_id)->where('nc_id', $nc_id)->get();
        // dd($replies->toArray());
        return view('applicationform.replies', ['replies' => $replies, 'nc_id' => $nc_id]);
        // return response()->json($nc_id);
    }

    public function SubmitReply(Request $request)
    {
        $dest = public_path('/assets/evidences/');
        $org_id = session('user_id');
        $app = ApplicationStatus::where('id', $request->app_id)->where('user_id', $org_id)->first();
        $assessment = AppAssessment::where('app_id', $app->id)->where('org_id', $org_id)->first();

        if ($request->hasFile('ref_doc')) {
            $ref_doc = $request->file('ref_doc');
            $org_ref_doc = time() . '_ref_org_' . $org_id . '.' . $ref_doc->getClientOriginalExtension();
            $ref_doc->move($dest, $org_ref_doc);
        } else {
            $org_ref_doc = $request->ref_doc;
        }
        $reply_nc = new AppNcReply();
        $reply_nc->app_id = $app->id;
        $reply_nc->org_id = $org_id;
        $reply_nc->nc_id = $request->nc_id;
        $reply_nc->assessor_id = $assessment->assessor_id;
        $reply_nc->assessment_id = $assessment->id;
        $reply_nc->reply_by = "Applicant";
        $reply_nc->ref_doc = $org_ref_doc;
        $reply_nc->reply = $request->reply;
        // dd($reply_nc);
        if ($reply_nc->save()) {
            return redirect()->route('reply.nc',[$app->id])->with('success', 'Click on send replies to Assessor!!!');
        }
    }

    public function ReplytoAssessor($app_id)
    {
        $org_id = session('user_id');
        $updateReply = AppNcReply::where('app_id',$app_id)->where('org_id', $org_id)->where('isActive', 0)->update(['isActive' => 1]);
        $assessment = AppAssessment::where('app_id',$app_id)->where('org_id',$org_id)->where('isActive',0)->first();
        if ($updateReply) {
            $update_stage = ApplicationStatus::where('id',$app_id)->where('user_id', $org_id)->first();
            $update_stage->stage = '2G';
            if ($update_stage->save()) {
                $user = AdminUser::where('id', $assessment->assessor_id)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name', 'NC Reply to Assessor')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        return redirect()->route('reply.nc',[$app_id])->with('success', 'All replies has been sent to Assessor !!');
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
            }
        }
    }

    public function ViewAssessment($app_id)
    {
        $org_id = session('user_id');
        $assessment_reports = AppAssessmentReport::where('app_id', $app_id)->where('org_id', $org_id)->get();
        return view('applicationform.assessment-reports', ['assessment_reports' => $assessment_reports,'app_id'=>$app_id]);
    }

    public function test()
    {
        // $mail =  AppMail::where('template_name','Submitted Application')->first();
        // dd($mail->toArray());
        $user = User::where('email', 'iconicamitweb@gmail.com')->first();
        // // dd($user->toArray());
        // Notification::send($user, new SubmitNotification($mail));
        // Mail::to($user->email)->send(new ApplicationMail($user,$mail));

        // if(Mail::failures() != 0) {
        //     return back()->with('success', 'Success! Mail Sent');
        // }
        // return back()->with('failed', 'Failed! there is some issue with email provider');
        $mail =  AppMail::where('template_name', 'Submitted Application')->first();
        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
        if (Mail::failures() != 0) {
            $user = Admin::first();
            $mail =  AppMail::where('template_name', 'Submitted Application')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                return redirect('application')->with('success', 'Your Form Details has been submitted successfully!!');
            }
        }
        return back()->with('message', 'Failed! there is some issue with email provider');
    }

    public function barcode()
    {
        return view('applicationform.barcode');
    }

    public function Notify()
    {
        $user = User::first();
        $data = [
            'name'=>'Amit Sharma',
            'email'=>'test@gmail.com'
        ];
        Notification::send($user, new TestNotification($data));
        dd('done');
    }
}
