<?php

namespace App\Http\Controllers;

use App\AppAnnexedInfo;
use App\AppAnnexedInformation;
use App\ApplicationStatus;
use Illuminate\Http\Request;

class AnnexedInformationController extends Controller
{
    public function index($app_id)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        // $app_id = $app_status->id;
        $org_reg_cert = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Organization Registration Certificate and Memorandum or Articles of Association')->where('isActive',0)->first();
        $mstr_vcs = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Master List of Documents reference of voluntary certification scheme')->where('isActive',0)->first();
        $qlty_manual = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Quality Manual by applicable accreditation standard')->where('isActive',0)->first();
        $vol_cert_scheme = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Documentation relating to voluntary certification scheme')->where('isActive',0)->first();
        $cov_undr_aprv = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Branch Office with activities to be covered under approval')->where('isActive',0)->first();
        $man_pers_audt = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','List of Managerial Personnel, Auditors')->where('isActive',0)->first();
        $otr_doc = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Other Documents')->where('isActive',0)->first();
        $ref_vol_cert_sch = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Reference of any voluntary certification scheme')->where('isActive',0)->first();
        $otr_rel_info = AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app_id)->where('type','Any other relevant information')->where('isActive',0)->first();
        // $org_reg_certs = AppAnnexedInformation::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted',0)->first();
        // if ($org_reg_certs == null) {
        //     $org_reg_certs = '';
        // }
        // dd($otr_doc);
        return view('applicationform.annexed-information', ['app_id'=>$app_id,'org_reg_cert'=>$org_reg_cert,'mstr_vcs'=>$mstr_vcs,'qlty_manual'=>$qlty_manual,
    'vol_cert_scheme'=>$vol_cert_scheme,'cov_undr_aprv'=>$cov_undr_aprv,'man_pers_audt'=>$man_pers_audt,'otr_doc'=>$otr_doc,'ref_vol_cert_sch'=>$ref_vol_cert_sch,'otr_rel_info'=>$otr_rel_info]);
    }

    public function Store(Request $request)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        $app_id = $request->app_id;
        $dest = public_path('/assets/images/annexed/');
        
        //1. file format org_id_app_id_random_time_filename
        if($request->hasFile('filename')){
            $filename_image = $request->file('filename');
            $filename = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_filename.'. $filename_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $filename_image->move($dest, $filename);
        }else{
            $filename = $request->old_filename;
        }

        //2. file format org_id_app_id_random_time_ref_of_vol
        if($request->hasFile('ref_of_vol')){
            $ref_of_vol_image = $request->file('ref_of_vol');
            $ref_of_vol = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_ref_of_vol.'. $ref_of_vol_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $ref_of_vol_image->move($dest, $ref_of_vol);
        }else{
            $ref_of_vol = $request->old_ref_of_vol;
        }

        //3. file format org_id_app_id_random_time_applicable_acc_stand
        if($request->hasFile('applicable_acc_stand')){
            $applicable_acc_stand_image = $request->file('applicable_acc_stand');
            $applicable_acc_stand = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_applicable_acc_stand.'. $applicable_acc_stand_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $applicable_acc_stand_image->move($dest, $applicable_acc_stand);
        }else{
            $applicable_acc_stand = $request->old_applicable_acc_stand;
        }

        //4. file format org_id_app_id_random_time_related_to_vol
        if($request->hasFile('related_to_vol')){
            $related_to_vol_image = $request->file('related_to_vol');
            $related_to_vol = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_related_to_vol.'. $related_to_vol_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $related_to_vol_image->move($dest, $related_to_vol);
        }else{
            $related_to_vol = $request->old_related_to_vol;
        }

        //5.  file format org_id_app_id_random_time_branch_activity
        if($request->hasFile('branch_activity')){
            $branch_activity_image = $request->file('branch_activity');
            $branch_activity = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_branch_activity.'. $branch_activity_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $branch_activity_image->move($dest, $branch_activity);
        }else{
            $branch_activity = $request->old_branch_activity;
        }

        //6.  file format org_id_app_id_random_time_list_of_experts
        if($request->hasFile('list_of_experts')){
            $list_of_experts_image = $request->file('list_of_experts');
            $list_of_experts = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_list_of_experts.'. $list_of_experts_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $list_of_experts_image->move($dest, $list_of_experts);
        }else{
            $list_of_experts = $request->old_list_of_experts;
        }

        //7.   file format org_id_app_id_random_time_other_cert
        if($request->hasFile('other_cert')){
            $other_cert_image = $request->file('other_cert');
            $other_cert = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_other_cert.'. $other_cert_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $other_cert_image->move($dest, $other_cert);
        }else{
            $other_cert = $request->old_other_cert;
        }

        //8.  file format org_id_app_id_random_time_ref_of_any_vol
        if($request->hasFile('ref_of_any_vol')){
            $ref_of_any_vol_image = $request->file('ref_of_any_vol');
            $ref_of_any_vol = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_ref_of_any_vol.'. $ref_of_any_vol_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $ref_of_any_vol_image->move($dest, $ref_of_any_vol);
        }else{
            $ref_of_any_vol = $request->old_ref_of_any_vol;
        }

        //9.  file format org_id_app_id_random_time_any_other_rel
        if($request->hasFile('any_other_rel')){
            $any_other_rel_image = $request->file('any_other_rel');
            $any_other_rel = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_any_other_rel.'. $any_other_rel_image->getClientOriginalExtension();
            // $dest = public_path('/assets/images/annexed/');
            $any_other_rel_image->move($dest, $any_other_rel);
        }else{
            $any_other_rel = $request->old_any_other_rel;
        }

        // $annexed_information = new AppAnnexedInformation();
        // $annexed_information->org_id = $org_id;
        // $annexed_information->app_id = $app_id;
        // $annexed_information->filename = $filename;
        // $annexed_information->ref_of_vol = $ref_of_vol;
        // $annexed_information->applicable_acc_stand = $applicable_acc_stand;
        // $annexed_information->related_to_vol = $related_to_vol;
        // $annexed_information->branch_activity = $branch_activity;
        // $annexed_information->list_of_experts = $list_of_experts;
        // $annexed_information->other_cert = $other_cert;
        // $annexed_information->ref_of_any_vol = $ref_of_any_vol;
        // $annexed_information->any_other_rel = $any_other_rel;
        // dd($annexed_information);

        $annexed_information = AppAnnexedInformation::updateOrCreate(
            ['org_id' => $org_id,
            'app_id' => $app_id,],
            [
                'filename' => $filename,
                'ref_of_vol'=>$ref_of_vol,
                'applicable_acc_stand' => $applicable_acc_stand,
                'related_to_vol' => $related_to_vol,
                'branch_activity' => $branch_activity,
                'list_of_experts' => $list_of_experts,
                'other_cert' => $other_cert,
                'ref_of_any_vol' => $ref_of_any_vol,
                'any_other_rel' => $any_other_rel,
            ]);
            if ($annexed_information->save()) {
                return back()->with('success', 'Changes has been saved successfully!!');
            }

    }

    public function UploadFile(Request $request)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        $app_id = $request->app_id;
        $dest = public_path('/assets/images/annexed/');
        
        //1. file format org_id_app_id_random_time_filename
        if($request->hasFile('filename')){
            $filename_image = $request->file('filename');
            $filename = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_'.$request->fname.'.'. $filename_image->getClientOriginalExtension();
            $filename_image->move($dest, $filename);
        }else{
            $filename = $request->old_filename;
        }
       $annexed =  AppAnnexedInfo::where('id',$request->id)->where('type',$request->type)->where('isActive',0)->first();
       if ($annexed) {
        $annexed->isActive = 1;
        if ($annexed->save()) {
            $annexed_info = new AppAnnexedInfo();
            $annexed_info->org_id = $org_id;
            $annexed_info->app_id = $app_id;
            $annexed_info->type = $request->type;
            $annexed_info->filename = $filename;
            if ($annexed_info->save()) {
                return back()->with('success', 'Changes has been saved successfully!!');
            }
        }
       }else{
            $annexed_info = new AppAnnexedInfo();
            $annexed_info->org_id = $org_id;
            $annexed_info->app_id = $app_id;
            $annexed_info->type = $request->type;
            $annexed_info->filename = $filename;
            if ($annexed_info->save()) {
                return back()->with('success', 'Changes has been saved successfully!!');
            }
       }
        // $annexed_information = AppAnnexedInfo::updateOrCreate(
        //     ['id'=>$request->id,
        //     'org_id' => $org_id,
        //     'app_id' => $app_id,],
        //     [
        //         'type'=>$request->type,
        //         'filename' => $filename,
        //     ]);
        //     if ($annexed_information->save()) {
        //         return back()->with('success', 'Changes has been saved successfully!!');
        //     }
    }

    // public function UploadFile(Request $request)
    // {
    //     $org_id = session('user_id');
    //     $app_status = ApplicationStatus::where('user_id', $org_id)->first();
    //     $app_id = $app_status->id;
    //     $dest = public_path('/assets/images/annexed/');
        
    //     //1. file format org_id_app_id_random_time_filename
    //     if($request->hasFile('filename')){
    //         $filename_image = $request->file('filename');
    //         $filename = $org_id.'_'.$app_id.'_'.rand(10000, 99999).'_'.time().'_filename.'. $filename_image->getClientOriginalExtension();
    //         $filename_image->move($dest, $filename);
    //     }else{
    //         $filename = $request->old_filename;
    //     }
    //     $annexed_information = AppAnnexedInformation::updateOrCreate(
    //         ['org_id' => $org_id,
    //         'app_id' => $app_id,],
    //         [
    //             'filename' => $filename,
    //         ]);
    //         if ($annexed_information->save()) {
    //             return back()->with('success', 'Changes has been saved successfully!!');
    //         }
    // }

    public function DeleteFile($id)
    {
        $annexed_information = AppAnnexedInfo::find($id);
        if ($annexed_information->delete()) {
            return back()->with('success','File has been deleted Successfully. Upload new file!!');
        }
    }
}
