<?php

namespace App\Http\Controllers;

use App\AppBranchAddress;
use App\AppGeneralInfo;
use App\ApplicationStatus;
use App\AppScrutiny;
use App\AppVoluntaryCertificationScheme;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GeneralInformationController extends Controller
{
    public function index($id)
    {
        $user_id = session('user_id');
        $app_status = ApplicationStatus::where('id', $id)->where('user_id', $user_id)->where('isDeleted', 0)->first();
        $app_id = $app_status->id;
        $userData = User::where('id', $user_id)->first();
        $generalinformations = AppGeneralInfo::where('org_id', $user_id)->where('app_id', $app_id)->where('isDeleted', 0)->first();
        if ($generalinformations == null) {
            $generalinformations = [];
        }
        // dd($generalinformations);
        $branch_addressess = AppBranchAddress::where('org_id', $user_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($branch_addressess == null) {
            $branch_addressess = [];
        }
        if ($app_status->stage == '1B') {
            $check_Adequcy = AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'GI')->where('isActive', 0)->first();
            if (@$check_Adequcy->option == 'InAdequate') {
                return view('applicationform.form', ['userData' => $userData, 'user' => $userData, 'app_id' => $app_id, 'generalinformations' => $generalinformations, 'branch_addressess' => $branch_addressess]);
                // return redirect('application-form');
            }
        }
        if ($app_status->stage == '1B') {
            $check_Adequcy = AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'PI')->where('isActive', 0)->first();
            if (@$check_Adequcy->option == 'InAdequate') {
                return redirect()->route('personnel.Information', [$app_id]);
            }
        }
        if ($app_status->stage == '1B') {
            $check_Adequcy = AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'OI')->where('isActive', 0)->first();
            if (@$check_Adequcy->option == 'InAdequate') {
                return redirect()->route('other.info', [$app_id]);
            }
        }
        if ($app_status->stage == '1B') {
            $check_Adequcy = AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'FI')->where('isActive', 0)->first();
            if (@$check_Adequcy->option == 'InAdequate') {
                return redirect()->route('financialinfo', [$app_id]);
            }
        }
        if ($app_status->stage == '1B') {
            $check_Adequcy = AppScrutiny::where('org_id', $user_id)->where('app_id', $app_id)->where('scrutiny_for', 'AI')->where('isActive', 0)->first();
            if (@$check_Adequcy->option == 'InAdequate') {
                return redirect()->route('annexed.information', [$app_id]);
            }
        }

        // dd($branch_addressess);
        return view('applicationform.form', ['app_id' => $app_id, 'userData' => $userData, 'user' => $userData, 'generalinformations' => $generalinformations, 'branch_addressess' => $branch_addressess]);
        // return view('applicationform.form', ['userData'=>$userData]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'assessment_body_name' => 'required',
            'ab_mobile' => 'required',
            'ab_email' => 'required',
            'main_ofc_address' => 'required',
            'state' => 'required',
            'city' => 'required',
            'pin' => 'required',
            'owneship_detail' => 'required',
            'status' => 'required',
            'reg_no' => 'required',
            'reg_date' => 'required',
            'reg_authority' => 'required',
            'reg_place' => 'required',
            'chief_name' => 'required',
            'chief_designation' => 'required',
            'p_designation' => 'required',
            'option' => 'required',
        ]);
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->where('id', $org_id)->first();
        $app_id = $request->app_id;
        // dd($app_id);
        $generalinformations = AppGeneralInfo::updateOrCreate(
            [
                'org_id' => $org_id,
                'app_id' => $app_id,
            ],
            [
                'assessment_body_name' => $request->assessment_body_name,
                'ab_mobile' => $request->ab_mobile,
                'ab_email' => $request->ab_email,
                'main_ofc_address' => $request->main_ofc_address,
                'state' => $request->state,
                'city' => $request->city,
                'pin' => $request->pin,
                'fax' => $request->fax,
                'web' => $request->web,
                'owneship_detail' => $request->owneship_detail,
                'status' => $request->status,
                'reg_no' => $request->reg_no,
                'reg_date' => $request->reg_date,
                'reg_authority' => $request->reg_authority,
                'reg_place' => $request->reg_place,
                'chief_name' => $request->chief_name,
                'chief_designation' => $request->chief_designation,
                'p_designation' => $request->p_designation,
                'p_phone' => $request->p_phone,
                'option' => $request->option,
            ]
        );

        if ($generalinformations) {
            // $totaolRows = $request->totalRows;
            // dd($request->branch_id);

            if ($generalinformations->option == 'yes') {
                $request->validate([
                    'branch_name' => 'required',
                    'branch_address' => 'required',
                    'branch_state' => 'required',
                    'branch_city' => 'required',
                    'branch_pin' => 'required',
                    'branch_p_name' => 'required',
                    'branch_p_designation' => 'required',
                    'branch_p_mobile' => 'required',
                    'branch_p_email' => 'required',
                ]);

                $ip = $request->ip();
                $branch_id = $request->branch_id;
                $branch_name = $request->branch_name;
                $branch_address = $request->branch_address;
                $branch_state = $request->branch_state;
                $branch_city = $request->branch_city;
                $branch_pin = $request->branch_pin;
                $branch_p_name = $request->branch_p_name;
                $branch_p_designation = $request->branch_p_designation;
                $branch_p_mobile = $request->branch_p_mobile;
                $branch_p_email = $request->branch_p_email;
                // if ( $request->branch_name != null) {
                if (count($branch_name)) {

                    for ($i = 0; $i < count($branch_address); $i++) {
                        if (
                            $branch_name[$i] != null && $branch_address[$i] != null && $branch_state[$i] != null && $branch_city[$i] != null
                            && $branch_pin[$i] != null && $branch_p_name[$i] != null && $branch_p_designation[$i] != null && $branch_p_mobile[$i] != null
                            && $branch_p_email[$i] != null
                        ) {

                            // DB::connection()->enableQueryLog();
                            $checkBranch = AppBranchAddress::where('id', $branch_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
                            // $queries = DB::getQueryLog();
                            //     $last_query = end($queries); 
                            //     dd($last_query);  
                            // dd($checkBranch);
                            $datasave = [
                                'org_id' => $org_id,
                                'app_id' => $app_id,
                                'branch_name' => $branch_name[$i],
                                'branch_address' => $branch_address[$i],
                                'branch_state' => $branch_state[$i],
                                'branch_city' => $branch_city[$i],
                                'branch_pin' => $branch_pin[$i],
                                'branch_p_name' => $branch_p_name[$i],
                                'branch_p_designation' => $branch_p_designation[$i],
                                'branch_p_mobile' => $branch_p_mobile[$i],
                                'branch_p_email' => $branch_p_email[$i],
                            ];
                            if ($checkBranch == null) {
                                // dd("inserted");
                                DB::table('app_branch_addresses')->insert($datasave);
                            } else {
                                // dd($branch_id[$i]);
                                // DB::connection()->enableQueryLog();

                                DB::table('app_branch_addresses')->where('id', $branch_id[$i])->update($datasave);

                                // $queries = DB::getQueryLog();

                                // $last_query = end($queries); 
                                // dd($last_query);             
                                //    return back()->with('success', 'Changes has been saved successfully!!');
                            }
                        } else {
                            $update_info = AppGeneralInfo::where('app_id', $app_id)->where('org_id', $org_id)->where('isDeleted', 0)->update(['option' => 'no']);
                            if ($update_info) {
                                return back()->with('message', 'Branch fields are required!!');
                            }
                        }
                    }
                }
            }
            return back()->with('success', 'Changes has been saved successfully!!');
        }
    }

    public function deleteBranch($id)
    {
        $branch_address = AppBranchAddress::find($id);
        $branch_address->isDeleted = "1";
        if ($branch_address->save()) {
            $update_info = AppGeneralInfo::where('app_id', $branch_address->app_id)->where('org_id', $branch_address->org_id)->where('isDeleted', 0)->first();
            $update_info->option = 'no';
            if ($update_info->save()) {
                $voluntry = AppVoluntaryCertificationScheme::where('branch_id', $id)->first();
                if ($voluntry) {
                    $voluntry->isDeleted = "1";
                    $voluntry->save();
                }
            }

            return back()->with('success', 'Branch Address deleted successfully!');
        }
        // return back()->with('success', 'Branch Address deleted successfully!');
    }
}
