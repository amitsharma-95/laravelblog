<?php

namespace App\Http\Controllers\Admin;

use App\AdminUser;
use App\AppAnnexedInfo;
use App\AppAnnexedInformation;
use App\AppBranchAddress;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\AppIafMemberBody;
use App\ApplicationStatus;
use App\AppNabcbMemberBody;
use App\AppOtherApprovalGovt;
use App\AppOtherInformation;
use App\AppPersonnelInformation;
use App\AppScheme;
use App\AppVoluntaryCertificationScheme;
use App\Http\Controllers\Controller;
use App\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{
    public function index()
    {
        // $applications = User::join('app_schemes', 'users.scheme', '=', 'app_schemes.id')
        //        ->where('users.isDeleted',0)->latest()->get(['users.*', 'app_schemes.scheme_name']);
        // $applications = User::all();
        $applications = ApplicationStatus::all();
        // dd($applications);
        return view('admin.application.index', ['applications'=>$applications]);
    }

    function Preview($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->first();
        $scheme = AppScheme::where('id',$app->scheme)->first();
        $user = User::where('id',$app->user_id)->first();
        $general_info = AppGeneralInfo::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $branch_addresses = AppBranchAddress::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $personnel_info = AppPersonnelInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $certificate_schemes = AppVoluntaryCertificationScheme::where('org_id', $user->id)->where('app_id', $app->id)->where('isDeleted', 0)->get();
        $nabcb_bodies = AppNabcbMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $iaf_member_bodies = AppIafMemberBody::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $other_approvals = AppOtherApprovalGovt::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $financial_performances = AppFinancialPerformance::where('org_id', $user->id)->where('app_id', $app->id)->get();
        $other_information = AppOtherInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        // $annexed_info = AppAnnexedInformation::where('org_id', $user->id)->where('app_id', $app->id)->first();
        $org_reg_cert = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Organization Registration Certificate and Memorandum or Articles of Association')->where('isActive', 0)->first();
        $ref_of_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Master List of Documents reference of voluntary certification scheme')->where('isActive', 0)->first();
        $applicable_acc_stand = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Quality Manual by applicable accreditation standard')->where('isActive', 0)->first();
        $related_to_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Documentation relating to voluntary certification scheme')->where('isActive', 0)->first();
        $branch_activity = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Branch Office with activities to be covered under approval')->where('isActive', 0)->first();
        $list_of_experts = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'List of Managerial Personnel, Auditors')->where('isActive', 0)->first();
        $other_cert = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Other Documents')->where('isActive', 0)->first();
        $ref_of_any_vol = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Reference of any voluntary certification scheme')->where('isActive', 0)->first();
        $any_other_rel = AppAnnexedInfo::where('org_id', $user->id)->where('app_id', $app->id)->where('type', 'Any other relevant information')->where('isActive', 0)->first();
        $pdf = PDF::loadView('applicationform.application-priview', ['scheme'=>$scheme,'app'=>$app,
            'user' => $user, 'general_info' => $general_info, 'branch_addresses' => $branch_addresses,
            'personnel_info' => $personnel_info, 'certificate_schemes' => $certificate_schemes, 'nabcb_bodies' => $nabcb_bodies, 'other_information' => $other_information,
            'iaf_member_bodies' => $iaf_member_bodies, 'other_approvals' => $other_approvals, 'financial_performances' => $financial_performances,
            'org_reg_cert' => $org_reg_cert, 'ref_of_vol' => $ref_of_vol, 'applicable_acc_stand' => $applicable_acc_stand, 'related_to_vol' => $related_to_vol,
            'branch_activity' => $branch_activity, 'list_of_experts' => $list_of_experts, 'other_cert' => $other_cert, 'ref_of_any_vol' => $ref_of_any_vol, 'any_other_rel' => $any_other_rel
        ]);
        return $pdf->stream();
    }
}
