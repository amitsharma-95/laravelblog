<?php

namespace App\Http\Controllers\Admin;

use App\AdminUser;
use App\AppMail;
use App\AppRole;
use App\AppUserRole;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {
        $users_list = AdminUser::where('isDeleted',0)->get();
        $roles = AppRole::all();
        return view('admin.users.index', ['users_list'=>$users_list,'roles'=>$roles]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|min:3|max:50',
            'email' => 'required|email',
            'mobile' => 'required',
            'password' => 'required|confirmed|min:6',
        ]);
        $roles = implode(',',$request->roles);
        // dd($roles);
        
        $saveuser = AdminUser::updateOrCreate(
            ['id'=>$request->id],
            [
                'name'=>$request->name,
                'email'=>$request->email,
                'mobile' => $request->mobile,
                'username' => $request->username,
                'password' => $request->password,
                'role_id'=>$roles
            ]
         );
         if ($saveuser) {
         return back()->with('success', 'Submitted successfully!');
         }

        //  if ($saveuser) {
        //      $adminuser_id = $saveuser->id;
        //      $user_roles = $request->roles;

        //      if (count($user_roles) != NULL) {
                 
        //         for ($i=0; $i < count($user_roles) ; $i++) { 
        //             // dd($user_roles);
        //             $checkRoles = AppUserRole::where('adminuser_id',$adminuser_id)->where('role_id',$user_roles[$i])->first();
        //             $data  = [
        //                 'adminuser_id'=>$adminuser_id,
        //                 'role_id'=>$user_roles[$i],
        //             ];
                   
        //             if ($checkRoles == null) {
        //                 // dd($data);
        //                 DB::table('app_user_roles')->insert($data);
        //             }else{
        //                 // dd($data);
        //                 DB::table('app_user_roles')->where('adminuser_id',$adminuser_id)->where('role_id',$user_roles[$i])->update($data);
        //             }
        //         }}
        //     //  dd($user_roles);
        //     //  foreach ($user_roles as $role) {
        //     //      $roles[] = $role;
        //     //  }
        //     //  $users_roles = new AppUserRole();
        //     //      $users_roles->adminuser_id = $adminuser_id;
        //     //      $users_roles->role_id = $roles;
        //     //      dd($users_roles);
        //     //  if($user_roles->save()){
        //     //     return back()->with('success', 'Submitted successfully!');
        //     //     }else{
        //     //         return back()->with('error', 'Something went wrong!');
        //     //     }
        //     return back()->with('success', 'Submitted successfully!');
        //  }
    }

    public function edit($id){
        $usersdetail = AdminUser::find($id);
        // dd($usersdetail);
        $roles = AppRole::all();

        // return view('admin.users.update', ['usersdetail'=>$usersdetail,'roles'=>$roles]);
        $returnHTML = view('admin.users.update', ['usersdetail'=>$usersdetail,'roles'=>$roles])->render();
        return response()->json(array('success' => true, 'html'=>$returnHTML));
        // return response()->json($usersdetail);
    }

    public function destroy($id)
    {
        $ldate = date('Y-m-d H:i:s');
        $user = AdminUser::where('id',$id)->first();
        $user->isDeleted = 1;
        $user->deleted_at = $ldate;
        // dd($user);
        $user->save();
        return back()->with('success', 'Deleted Successfully!');
    }

    public function ManageEmail()
    {
        $emails = AppMail::all();
        return view('admin.manage.email', ['emails'=>$emails]);
    }

    public function editEmail($id){
        $mail = AppMail::find($id);
        return view('admin.manage.update-email', ['mail'=>$mail]);
        // return response()->json(array('success' => true, 'html'=>$returnHTML));
        // return response()->json($usersdetail);
    }

    public function Editmail(Request $request)
    {
        // dd($request->all());
        $update_mail = AppMail::where('id',$request->id)->where('isActive',0)->first();
        $update_mail->template_name = $request->template_name;
        $update_mail->subject = $request->subject;
        $update_mail->mail_from = $request->mail_from;
        $update_mail->sender_name = $request->sender_name;
        $update_mail->body = $request->body;
        if($update_mail->save()){
            return back()->with('success', 'Your mail configuration has been updated successfully!!');
        }
    }
}
