<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\AdminUser;
use App\ApplicationStatus;
use App\AppMail;
use App\AppScheme;
use App\AppUserAllotment;
use App\Http\Controllers\Controller;
use App\Mail\ApplicationMail;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class AllotmentController extends Controller
{
    public function index()
    {
        // $stage = '1A'; 
        // $users = User::with('applicationStatus')->whereHas('applicationStatus', function ($query) {
        //     return $query->where('stage', '!=', 0);
        // })->get();
        $applications = ApplicationStatus::where('stage', '!=', 0)->get();
        $role_users = AdminUser::where('isActive', 0)->get();
        return view('admin.allotment.index', ['applications' => $applications, 'role_users' => $role_users]);
    }

    public function Allotuser($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->where('isDeleted',0)->first();
        // $user = User::where('id',$app->user_id)->first();
        $org_id = $app->user_id;
        $alloted_by = Session('Admin');
        $role_users = AdminUser::where('role_id', 1)->where('isActive', 0)->get();
        // dd($role_users);
        return view('admin.allotment.allotuser', ['org_id' => $org_id,'app_id'=>$app_id, 'alloted_by' => $alloted_by, 'role_users' => $role_users]);
    }

    public function UserAllotment(Request $request)
    {
        $ip = $request->ip();
        $app = ApplicationStatus::where('id', $request->app_id)->where('user_id', $request->org_id)->where('stage', '1')->where('isDeleted',0)->first();
        // dd($app);
        // $check_already_alloted = AppUserAllotment::where('org_id',$request->org_id)->where('alloted_to',$request->alloted_to)
        //                          ->where('type','Dealing Officer')->first();

        $alloted_user = new AppUserAllotment();
        $alloted_user->org_id = $request->org_id;
        $alloted_user->app_id = $app->id;
        $alloted_user->alloted_by = $request->alloted_by;
        $alloted_user->alloted_to = $request->alloted_to;
        $alloted_user->ip = $ip;
        $alloted_user->type = "Dealing Officer";
        // dd($alloted_user);
        if ($alloted_user->save()) {
            $admin = Session('Admin');
            $app->stage = '1A';
            $app->updated_by = 'Admin_'.$admin;
            if ($app->save()) {
                $user = AdminUser::where('id', $alloted_user->alloted_to)->first();
            // dd($user->email);
            $mail =  AppMail::where('template_name', 'Dealing Officer')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                $user = User::where('id',$alloted_user->org_id)->first();
                $mail =  AppMail::where('template_name', 'Dealing Officer')->first();
                Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                if (Mail::failures() != 0) {
                    return redirect('admin/allotment')->with('success', 'Dealing Officer allotted Successfully!!');
                }
            }
            return back()->with('failed', 'Failed! there is some issue with email provider');
            }
            
        }
    }

    public function NotAlloted()
    {
        // $stage = '1A'; 
        // $users = User::with('applicationStatus')->whereHas('applicationStatus', function ($query) {
        //     return $query->where('stage', '1');
        // })->get();

        $applications = ApplicationStatus::where('stage', "1")->get();
        $role_users = AdminUser::where('isActive', 0)->get();
        return view('admin.allotment.not-alloted', ['applications' => $applications, 'role_users' => $role_users]);
    }

    public function Alloted()
    {
        // $stage = '1A'; 
        // $users = User::with('applicationStatus')->whereHas('applicationStatus', function ($query) {
        //     return $query->where('stage', '!=', 0)->where('stage', '!=', '1');
        // })->get();
        // dd($users->toArray());
        $applications = ApplicationStatus::where('stage', '!=', array('0','1'))->get();
        $role_users = AdminUser::where('isActive', 0)->get();
        return view('admin.allotment.alloted', ['applications' => $applications, 'role_users' => $role_users]);
    }
}
