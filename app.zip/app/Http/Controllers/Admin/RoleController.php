<?php

namespace App\Http\Controllers\Admin;

use App\AppRole;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index()
    {
        $roles = AppRole::where('isDeleted',0)->get();
        return view('admin.roles.index', ['roles'=>$roles]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'role_name'=>'required'
        ]);
        $create_role = AppRole::updateOrCreate(
            ['id'=>$request->id],
            [
                'role_name'=>$request->role_name,
            ]);

            if ($create_role) {
                return back()->with('success', 'Changes have been saved Successfully!!!');
            }
    }

    public function edit($id){
        $roleupdate = AppRole::find($id);
        // dd($roleupdate);
        return response()->json($roleupdate);
    }

    public function destroy($id)
    {
        $ldate = date('Y-m-d H:i:s');
        $role = AppRole::where('id',$id)->first();
        $role->isDeleted = 1;
        $role->deleted_at = $ldate;
        // dd($role);
        $role->save();
        return back()->with('success', 'Deleted Successfully!');
    }
}
