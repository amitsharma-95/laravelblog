<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\AdminUser;
use App\ApplicationStatus;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function AdminLogin()
    {
        return view('admin.login');
    }

    //Admin login
    public function Login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            ]);
        $userCheck = Admin::where('username', $request->username)->first();
        if(!$userCheck){
            return redirect('admin/login')->with('error','Username not Found!! Please Check and try again.');
        }else{
            $Checkpassword = Admin::where('username', $request->username)->where('password', $request->password)->first();
            if($Checkpassword){
                // $request->session()->put('superAdmin',$userCheck->id);
                session(['Admin'=>$userCheck->id]);
                return redirect('admin/dashboard');
            }else{
                return redirect('admin/login')->with('error','Password Not Match!!');
            }
        }
    }

    //logout
    function Adminlogout(){
        session()->forget(['Admin']);
        return redirect('admin/login');
    }

    public function AdminDashboard()
    {
        $application = ApplicationStatus::all()->count();
        $user = AdminUser::all()->count();
        $application_submitted = ApplicationStatus::where('stage', '!=', 0)->count();
        $notifications = DB::table('notifications')->select('data')->get();
        // dd($notifications);
        // return view('admin.dashboard', compact('application','user','application_submitted','notifications'));
        return view('admin.dashboard', ['application'=>$application,'user'=>$user,'application_submitted'=>$application_submitted,'notifications'=>$notifications]);
    }
}
