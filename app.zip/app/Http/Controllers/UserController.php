<?php

namespace App\Http\Controllers;

use App\Mail\ResetPassword;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class UserController extends Controller
{

    public function forgotPassword()
    {
        return view('auth.forgot-password');
    }

    public function forgotPasswordValidate($token)
    {
        $user = User::where('token', $token)->where('is_verified', 0)->first();
        if ($user) {
            $username = $user->username;
            return view('auth.change-password', compact('username'));
        }
        return redirect()->route('forgot-password')->with('failed', 'Password reset link is expired');
    }
    public function resetPassword(Request $request)
    {
        // dd($request->all());
        // exit();
        $this->validate($request, [
            'email' => 'required',
        ]);
        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return back()->with('failed', 'Failed! Email is not registered.');
        }
        // $otp = rand(10,100);
        // dd("success");
        $token = Str::random(60);

        $user['token'] = $token;
        $user['is_verified'] = 0;
        if($user->save()){
            Mail::to($request->email)->send(new ResetPassword($user->name, $token));

            return back()->with('success', 'Success! password reset link has been sent to your email');

        }
        return back()->with('failed', 'Failed! there is some issue with email provider');
    }

    public function updatePassword(Request $request) {
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required|min:6',
            'confirm_password' => 'required|same:password'
        ]);
        $user = User::where('username', $request->username)->first();
        if ($user) {
            $user['is_verified'] = 0;
            $user['token'] = '';
            $user['password'] = Hash::make($request->password);
            $user['is_first_time'] = 2;
            $user->save();
            return redirect()->route('login')->with('success', 'Success! password has been changed');
        }
        return redirect()->route('forgot-password')->with('failed', 'Failed! something went wrong');
    }

}
