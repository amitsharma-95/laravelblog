<?php

namespace App\Http\Controllers;

use App\AppLocation;
use Illuminate\Http\Request;

class AppLocationController extends Controller
{
    public function store(Request $req)
    {

        try {
            $location = new AppLocation();
        $location->org_id = $req->org_id;
        $location->app_id = $req->app_id;
        $location->location_name = $req->location_name;
        $location->save();
        return 1;
        } catch (\Throwable $th) {
            throw $th;
        }

    }
}
