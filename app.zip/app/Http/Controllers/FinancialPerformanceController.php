<?php

namespace App\Http\Controllers;

use App\AppFinancialPerformance;
use App\ApplicationStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FinancialPerformanceController extends Controller
{
    public function index($app_id)
    {
        $org_id = session('user_id');
        // dd($user_id);
        // $app_id = session('app_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        // $app_id = $app_status->id;
        $financial_details = AppFinancialPerformance::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($financial_details == null) {
            $financial_details = [];
        }
        return view('applicationform.financial-performance', ['app_id' => $app_id, 'financial_details' => $financial_details]);
    }

    public function store(Request $request)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        $app_id = $request->app_id;
        $financial_address_id = $request->financial_address_id;
        $financial_year = $request->financial_year;
        $total_income = $request->total_income;
        $income_from_certification = $request->income_from_certification;
        $net_profit = $request->net_profit;
        // dd($financial_year);
        for ($i = 0; $i < count($financial_year); $i++) {
            // if($i == 1){ DB::connection()->enableQueryLog();
            //     $checkBranch = AppFinancialPerformance::where('id', $financial_address_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
            //     $queries = DB::getQueryLog();
            //     $last_query = end($queries); 
            //         dd($last_query);   }
            // DB::connection()->enableQueryLog();
            $checkBranch = AppFinancialPerformance::where('id', $financial_address_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
            $queries = DB::getQueryLog();
            $last_query = end($queries);
            // dd($last_query);  
            $datasave = [
                'org_id' => $org_id,
                'app_id' => $app_id,
                'financial_year' => $financial_year[$i],
                'total_income' => $total_income[$i],
                'income_from_certification' => $income_from_certification[$i],
                'net_profit' => $net_profit[$i],
            ];
            if ($checkBranch == null) {
                // dd("inserted");
                DB::table('app_financial_performances')->insert($datasave);
            } else {
                // dd($branch_id[$i]);
                // DB::connection()->enableQueryLog();
                // dd("update");
                DB::table('app_financial_performances')->where('id', $financial_address_id[$i])->update($datasave);

                // $queries = DB::getQueryLog();

                // $last_query = end($queries); 
                // dd($last_query);             
                //    return back()->with('success', 'Changes has been saved successfully!!');
            }
        }
        return back()->with('success', 'Changes has been saved successfully!!');
    }

    public function deleteFinanceRecord($id)
    {
        $financial_address = AppFinancialPerformance::find($id);
        $financial_address->isDeleted = "1";
        $financial_address->save();
        return back()->with('success', 'Record Deleted Successfully!!');
    }
}
