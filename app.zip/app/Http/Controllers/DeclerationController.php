<?php

namespace App\Http\Controllers;

use App\Admin;
use App\AppAnnexedInformation;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\ApplicationStatus;
use App\AppMail;
use App\AppOtherInformation;
use App\AppPersonnelInformation;
use App\AppScheme;
use App\Mail\ApplicationMail;
use App\Notifications\SubmitNotification;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Notification;

class DeclerationController extends Controller
{
    public function index($app_id)
    {
        $org_id = session('user_id');
        $user = User::where('id', $org_id)->first();
        $app = ApplicationStatus::where('id',$app_id)->first();
        $scheme = AppScheme::where('id', $app->scheme)->first();
        return view('applicationform.decleration', ['app_id'=>$app_id,'user' => $user, 'scheme' => $scheme]);
    }

    public function submit(Request $request)
    {
        $org_id = session('user_id');
        $user = User::where('id','org_id')->first();
        $app = ApplicationStatus::where('id', $request->app_id)->where('user_id', $org_id)->first();
        $gen_info = AppGeneralInfo::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $personnel_info = AppPersonnelInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $other_info = AppOtherInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        $financial_infos = AppFinancialPerformance::where('org_id', $org_id)->where('app_id', $app->id)->get();
        if ($financial_infos->count() > 0) {
            $financial_info = 1;
        }
        $org_reg_cert = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','Organization Registration Certificate and Memorandum or Articles of Association')->where('isActive',0)->count();
        $mstr_vcs = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','Master List of Documents reference of voluntary certification scheme')->where('isActive',0)->count();
        $qlty_manual = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','Quality Manual by applicable accreditation standard')->where('isActive',0)->count();
        $vol_cert_scheme = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','Documentation relating to voluntary certification scheme')->where('isActive',0)->count();
        $cov_undr_aprv = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','Branch Office with activities to be covered under approval')->where('isActive',0)->count();
        $man_pers_audt = \App\AppAnnexedInfo::where('org_id', $org_id)->where('app_id', $app->id)->where('type','List of Managerial Personnel, Auditors')->where('isActive',0)->count();
        $annexed_infos = $org_reg_cert + $mstr_vcs + $qlty_manual + $vol_cert_scheme + $cov_undr_aprv + $man_pers_audt;
        if ($annexed_infos == 6 || $annexed_infos >= 6) {
            $annexed_info = 1;
        }else {
            $annexed_info = 0;
        }
        $total_count = $gen_info + $personnel_info + $other_info + $financial_info + $annexed_info;
        // $annexed_info = AppAnnexedInformation::where('org_id', $org_id)->where('app_id', $app->id)->count();
        // $total_count = $gen_info + $personnel_info + $other_info + $financial_info + $annexed_info;
        // if ($gen_info == 0) {
        //     return redirect('/application-form')->with('message', 'You have to fill out these details before final submission!!');
        // } elseif ($personnel_info == 0) {
        //     return redirect('/personnel-information')->with('message', 'You have to fill out these details before final submission!!');
        // } elseif ($other_info == 0) {
        //     return redirect('/other-information')->with('message', 'You have to fill out these details before final submission!!');
        // } elseif ($financial_info == 0) {
        //     return redirect('/financial-performance')->with('message', 'You have to fill out these details before final submission!!');
        // } elseif ($annexed_info == 0) {
        //     return redirect('/annexed-information')->with('message', 'You have to fill out these details before final submission!!');
        // } else {
            $mytime = date('Y-m-d H:i:s');
            if ($total_count == 5) {
                // dd('success');
                $status_update = ApplicationStatus::where('id', $app->id)->where('user_id', $org_id)->first();
                $status_update->stage = '1';
                $status_update->stage_updation_date = $mytime;
                $status_update->application_no = 'QCI/APP/000'.$app->id;
                $status_update->updated_by = 'ORG_'.$org_id;
                // dd($status_update);
                if ($status_update->save()) {
                    $org_id = session('user_id');
                    $user = User::where('id', $org_id)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name','Submitted Application')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user,$mail));
                        if(Mail::failures() != 0) {
                            $user = Admin::first();
                            $mail =  AppMail::where('template_name','Submitted Application')->first();
                            Mail::to($user->email)->send(new ApplicationMail($user,$mail));
                            if(Mail::failures() != 0) {
                            return redirect()->route('submitted.application',[$app->id])->with('success', 'Your Form Details has been submitted successfully!!');
                            }
                        }
                        return back()->with('failed', 'Failed! there is some issue with email provider');
                }
            }else{
                return back()->with('message', 'You have to fill out all details before final submission!!');
            }
        // }
    }
}
