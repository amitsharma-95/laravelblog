<?php

namespace App\Http\Controllers;

use App\AppGeneralInfo;
use App\ApplicationStatus;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GeneralInformationController extends Controller
{
    public function index($id)
    {
        $user_id = session('user_id');
        $app_status = ApplicationStatus::where('id', $id)->where('user_id', $user_id)->first();
        $app_id = $app_status->id;
        $userData = User::where('id', $user_id)->first();
        $generalinformations = AppGeneralInfo::where('org_id', $user_id)->where('app_id',$app_id)->first();
        if ($generalinformations==null) {
            $generalinformations = [];
        }
        // dd($generalinformations);
        return view('applicationform.form', ['userData'=>$userData,'generalinformations'=>$generalinformations]);
        // return view('applicationform.form', ['userData'=>$userData]);
    }

    public function store(Request $request)
    {

        // echo "<pre>";
        // print_r($request->all());
        // echo "</pre>";
        // $alreadyStore = AppGeneralInfo::where('org_id', $request->org_id)->where('app_id',$request->app_id)->first();

        // dd($request->all());
        
        $app_status = ApplicationStatus::where('user_id', $request->org_id)->first();
        $app_id = $app_status->id;
        // dd($app_id);
       $generalinformations = AppGeneralInfo::updateOrCreate(
                ['org_id' => $request->org_id,
                'app_id' => $app_id,],
                [
                    'assessment_body_name' => $request->assessment_body_name,
                    'address' => $request->address,
                    'state' => $request->state,
                    'city' => $request->city,
                    'pin' => $request->pin,
                    'fax' => $request->fax,
                    'web' => $request->web,
                    'owneship_detail' => $request->owneship_detail,
                    'status' => $request->status,
                    'reg_no' => $request->reg_no,
                    'reg_date' => $request->reg_date,
                    'reg_authority' => $request->reg_authority,
                    'reg_place' => $request->reg_place,
                    'chief_name' => $request->chief_name,
                    'chief_designation' => $request->chief_designation,
                    'p_name' => $request->p_name,
                    'p_designation' => $request->p_designation,
                    'p_phone' => $request->p_phone,
                    'p_mobile' => $request->p_mobile,
                    'p_email' => $request->p_email
                ]);
                
            if ($generalinformations) {
                $branch_address = $request->branch_address;
                $branch_state = $request->branch_state;
                $branch_city = $request->branch_city;
                $branch_pin = $request->branch_pin;
                $branch_web = $request->branch_web;
                for ($i=0; $i < count($branch_address) ; $i++) { 
                    $datasave = [
                        'org_id' => $request->org_id,
                        'app_id' => $app_id,
                        'branch_address' => $branch_address,
                        'branch_state' => $branch_state,
                        'branch_city' => $branch_city,
                        'branch_pin' => $branch_pin,
                        'branch_web' => $branch_web,
                    ];
                    // dd($datasave);
                    DB::table('app_branch_addresses')->insert($datasave);
                }
                return back()->with('success', 'Changes has been saved successfully!!');
            }    
           

    //     if(!$alreadyStore){
    //         $generalinformations = new AppGeneralInfo();
    //         $generalinformations->org_id = $request->org_id;
    //         $generalinformations->app_id = $request->app_id;
    //         $generalinformations->assessment_body_name = $request->assessment_body_name;
    //         $generalinformations->address = $request->address;
    //         $generalinformations->state = $request->state;
    //         $generalinformations->city = $request->city;
    //         $generalinformations->pin = $request->pin;
    //         $generalinformations->fax = $request->fax;
    //         $generalinformations->web = $request->web;
    //         $generalinformations->owneship_detail = $request->owneship_detail;
    //         $generalinformations->status = $request->status;
    //         $generalinformations->reg_no = $request->reg_no;
    //         $generalinformations->reg_date = $request->reg_date;
    //         $generalinformations->reg_authority = $request->reg_authority;
    //         $generalinformations->reg_place = $request->reg_place;
    //         $generalinformations->chief_name = $request->chief_name;
    //         $generalinformations->chief_designation = $request->chief_designation;
    //         $generalinformations->p_name = $request->p_name;
    //         $generalinformations->p_designation = $request->p_designation;
    //         $generalinformations->p_phone = $request->p_phone;
    //         $generalinformations->p_mobile = $request->p_mobile;
    //         $generalinformations->p_email = $request->p_email;
    //         if($generalinformations->save()){
    //             $generalinformations = AppGeneralInfo::where('org_id', $request->org_id)->where('app_id',$$request->app_id)->first();
    //         return redirect('application-form', compact('generalinformations'))->with('success', 'Record Save Successfully!!');
    //             }else{
    //                 return back()->with('error', 'Something went Worng!!');
    //             }
    // }

    // else{
    //     $generalinformations = AppGeneralInfo::where('org_id', $request->org_id)->where('app_id',$request->app_id)->first();
    //     $generalinformations->org_id = $request->org_id;
    //     $generalinformations->app_id = $request->app_id;
    //     $generalinformations->assessment_body_name = $request->assessment_body_name;
    //     $generalinformations->address = $request->address;
    //     $generalinformations->state = $request->state;
    //     $generalinformations->city = $request->city;
    //     $generalinformations->pin = $request->pin;
    //     $generalinformations->fax = $request->fax;
    //     $generalinformations->web = $request->web;
    //     $generalinformations->owneship_detail = $request->owneship_detail;
    //     $generalinformations->status = $request->status;
    //     $generalinformations->reg_no = $request->reg_no;
    //     $generalinformations->reg_date = $request->reg_date;
    //     $generalinformations->reg_authority = $request->reg_authority;
    //     $generalinformations->reg_place = $request->reg_place;
    //     $generalinformations->chief_name = $request->chief_name;
    //     $generalinformations->chief_designation = $request->chief_designation;
    //     $generalinformations->p_name = $request->p_name;
    //     $generalinformations->p_designation = $request->p_designation;
    //     $generalinformations->p_phone = $request->p_phone;
    //     $generalinformations->p_mobile = $request->p_mobile;
    //     $generalinformations->p_email = $request->p_email;
    //     if($generalinformations->save()){
    //    return back()->with('success', 'Record Updated Successfully!!');
    //     }else{
    //         return back()->with('error', 'Something went Worng!!');
    //     }

    }

    // AppGeneralInfo::updateOrCreate(
    //     ['id' => $request->id],
    //     [
    //         'org_id' => $request->org_id,
    //         'app_id' => $request->app_id,
    //         'assessment_body_name' => $request->assessment_body_name,
    //         'address' => $request->address,
    //         'state' => $request->state,
    //         'city' => $request->city,
    //         'pin' => $request->pin,
    //         'fax' => $request->fax,
    //         'web' => $request->web,
    //         'owneship_detail' => $request->owneship_detail,
    //         'status' => $request->status,
    //         'reg_no' => $request->reg_no,
    //         'reg_date' => $request->reg_date,
    //         'reg_authority' => $request->reg_authority,
    //         'reg_place' => $request->reg_place,
    //         'chief_name' => $request->chief_name,
    //         'chief_designation' => $request->chief_designation,
    //         'p_name' => $request->p_name,
    //         'p_designation' => $request->p_designation,
    //         'p_phone' => $request->p_phone,
    //         'p_mobile' => $request->p_mobile,
    //         'p_email' => $request->p_email
    // ]);
    // // dd($request->all());
    // return back()->with('success', 'success');
}
