<?php

namespace App\Http\Controllers\Assessor;

use App\AdminUser;
use App\AppAnnexedInformation;
use App\AppAssessment;
use App\AppAssessmentNC;
use App\AppBranchAddress;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\AppIafMemberBody;
use App\ApplicationStatus;
use App\AppMail;
use App\AppNabcbMemberBody;
use App\AppOtherApprovalGovt;
use App\AppOtherInformation;
use App\AppPersonnelInformation;
use App\AppUserAllotment;
use App\AppVoluntaryCertificationScheme;
use App\Clerification;
use App\Http\Controllers\Controller;
use App\Mail\ApplicationMail;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class AssessorController extends Controller
{
    public function Dashboard()
    {
        $assessor = Session('userRole');
        // dd($assessor);
        $alloted_applications = AppUserAllotment::where('alloted_to', $assessor->id)->where('isActive', 0)->count();

        // dd($allotment);
        // if ($allotment == null) {
        //     $alloted_applications = 0;
        //     // $completed = 0;
        // }else {
        //     $alloted_applications = User::where('id', $allotment->org_id)->get()->count();
        //     // $completed = ApplicationStatus::where('user_id', $allotment->user_id_of_allotment)->where('stage', 2)->get()->count();
        // }
        $allotments = AppUserAllotment::where('alloted_to', $assessor->id)->where('isActive', 0)->get();
        return view('assessor.dashboard', ['alloted_applications' => $alloted_applications,'allotments'=>$allotments]);
    }

    public function AllotedApp()
    {
        $loginAssessor = Session('userRole');
        // $assessment = AppAssessment::where('assessor_id', $loginAssessor->id)->where('isActive', 0)->first();
        $allotments = AppUserAllotment::where('alloted_to', $loginAssessor->id)->where('isActive', 0)->get();
        
        return view('assessor.applicantions', ['allotments' => $allotments]);
    }

    public function AssessmentPending()
    {
        $loginAssessor = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginAssessor->id)->where('isActive', 0)->get();
        return view('assessor.assessment-pending', ['allotments' => $allotments]);
    }

    public function AssessmentProcessing()
    {
        $loginAssessor = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginAssessor->id)->where('isActive', 0)->get();
        return view('assessor.assessment-processing', ['allotments' => $allotments]);
    }

    public function AssessmentClosed()
    {
        $loginAssessor = Session('userRole');
        $allotments = AppUserAllotment::where('alloted_to', $loginAssessor->id)->where('isActive', 0)->get();
        return view('assessor.assessment-closed', ['allotments' => $allotments]);
    }

    public function Action($app_id)
    {
        $app = ApplicationStatus::where('id',$app_id)->where('isDeleted',0)->first();
        $org = User::where('id',$app->user_id)->first();
        return view('assessor.action', ['org'=>$org,'app'=>$app]);
    }

    public function AssessorAcceptance(Request $request)
    {
        
        if($request->assessor_action == 'Reject'){
            $request->validate([
                'assessor_remark' => 'required'
            ]);
        }
        // dd($request->all());
        $loginAssessor = Session('userRole');
        $allotment = AppUserAllotment::Where('org_id', $request->org_id)->Where('app_id', $request->app_id)->where('alloted_to',$loginAssessor->id)->where('isActive',0)->first();
        $assessment = AppAssessment::Where('app_id', $request->app_id)->Where('org_id', $request->org_id)->where('assessor_id', $loginAssessor->id)->where('isActive',0)->first();
        $assessment->assessor_action = $request->assessor_action;
        $assessment->assessor_remark = $request->assessor_remark;
        if ($request->assessor_action == 'Accept') {
            // dd($assessment);
            if ($assessment->save()) {
                $updatestage = ApplicationStatus::Where('id', $request->app_id)->where('user_id', $request->org_id)->first();
                $updatestage->updated_by = 'Assessor_'.$loginAssessor->id;
                $updatestage->stage = '2B';
                if ($updatestage->save()) {
                    $user = User::where('id', $request->org_id)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name', 'Assessor Acceptance to CB')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        $user = AdminUser::where('id',$allotment->alloted_by)->first();
                        if (!$user) {
                            $user = AdminUser::where('id',$loginAssessor->id)->first();
                        }
                        $mail =  AppMail::where('template_name', 'Assessor Acceptance to DO')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                        if (Mail::failures() != 0) {
                            return redirect('assessor/applications')->with('success', 'Your Acceptance Remark sent to DO!!');
                        }
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
                }
            }
        } else {
            // dd($assessment->toArray());
            $assessment->isActive = 1;
            if ($assessment->save()) {
                $updatestage = ApplicationStatus::Where('id', $request->app_id)->where('user_id', $request->org_id)->where('isDeleted',0)->first();
                $updatestage->updated_by = 'Assessor_'.$loginAssessor->id;
                $updatestage->stage = '2C';
                if ($updatestage->save()) {
                    $user = User::where('id', $request->org_id)->first();
                    // dd($user->email);
                    $mail =  AppMail::where('template_name', 'Assessor Acceptance to CB')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        $user = AdminUser::where('id',$allotment->alloted_by)->first();
                        if (!$user) {
                            $user = AdminUser::where('id',$loginAssessor->id)->first();
                        }
                        $mail =  AppMail::where('template_name', 'Assessor Acceptance to DO')->first();
                        Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                        if (Mail::failures() != 0) {
                            return redirect('assessor/applications')->with('success', 'Your Acceptance Remark sent to DO!!');
                        }
                    }
                    return back()->with('message', 'Failed! there is some issue with email provider');
                    // return redirect('assessor/applications')->with('success', 'Your Acceptance Remark sent to DO!!');
                }
            }
        }
    }

    public function StartAssessment($app_id)
    {
        $assessor = Session('userRole');
        $app = ApplicationStatus::where('id',$app_id)->where('isDeleted',0)->first();
        $user = User::where('id',$app->user_id)->first();
        $assessment = AppAssessment::where('app_id',$app_id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        $nc_for = $assessment->assessment_type;
        $all_ncs = AppAssessmentNC::where('app_id',$app_id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('isActive',0)->get();
        return view('assessor.ncs', ['user' => $user,'app'=>$app,'nc_for' => $nc_for, 'all_ncs' => $all_ncs]);
    }
}
