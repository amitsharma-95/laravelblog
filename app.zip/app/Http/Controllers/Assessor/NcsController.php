<?php

namespace App\Http\Controllers\Assessor;

use App\AdminUser;
use App\AppAssessment;
use App\AppAssessmentNC;
use App\ApplicationStatus;
use App\AppMail;
use App\AppNcReply;
use App\AppReply;
use App\AppUserAllotment;
use App\Http\Controllers\Controller;
use App\Mail\ApplicationMail;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class NcsController extends Controller
{
    public function CreateNC(Request $request)
    {
        $request->validate([
            'option' => 'required'
        ]);
        $assessor = Session('userRole');
        $assessment = AppAssessment::where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        // dd($assessor->id);
        $check_nc = AppAssessmentNC::where('id', $request->id)->where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        $image = array();
        if ($files = $request->file('evidences')) {
            foreach ($files as $file) {
                $ext = strtolower($file->getClientOriginalExtension());
                $image_full_name = time() . '-' . $request->nc_for . '_org_' . $request->org_id . '.' . $ext;
                $upload_path = 'assets/evidences/';
                $image_url = $image_full_name;
                $file->move($upload_path, $image_full_name);
                $image[] = $image_url;
                $image = implode('|', $image);
            }
        } else {
            $image = $request->image;
        }
        if ($check_nc == null) {
            $create_ncs = new AppAssessmentNC();
            $create_ncs->app_id = $request->app_id;
            $create_ncs->org_id = $request->org_id;
            $create_ncs->assessor_id = $assessor->id;
            $create_ncs->assessment_id = $assessment->id;
            $create_ncs->assessor_nc_action = $request->option;
            $create_ncs->nc_for = $request->nc_for;
            $create_ncs->evidences = $image;
            $create_ncs->remark = $request->remark;
            // dd($create_ncs);
            if ($create_ncs->save()) {
                return back()->with('success', 'NC has been created successfully for this record!!');
            }
        } else {
            $check_nc->isActive = '1';
            if ($check_nc->save()) {
                $create_ncs = new AppAssessmentNC();
                $create_ncs->app_id = $request->app_id;
                $create_ncs->org_id = $request->org_id;
                $create_ncs->assessor_id = $assessor->id;
                $create_ncs->assessment_id = $assessment->id;
                $create_ncs->assessor_nc_action = $request->option;
                $create_ncs->nc_for = $request->nc_for;
                $create_ncs->evidences = $image;
                $create_ncs->remark = $request->remark;
                // dd($create_ncs);
                if ($create_ncs->save()) {
                    return back()->with('success', 'NC has been created successfully for this record!!');
                }
            }
        }
    }

    public function GenerateNC(Request $request)
    {
        $assessor = Session('userRole');
        $assessment = AppAssessment::where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        $check_nc = AppAssessmentNC::where('app_id', $request->app_id)->where('org_id', $request->org_id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();

        // $create_ncs = new AppAssessmentNC();
        // $create_ncs->app_id = $assessment->app_id;
        // $create_ncs->org_id = $request->org_id;
        // $create_ncs->assessor_id = $assessor->id;
        // $create_ncs->assessment_id = $assessment->id;
        // $create_ncs->nc_for = $request->nc_for;
        // $create_ncs->topic = $request->topic;
        // $create_ncs->type = $request->type;
        // $create_ncs->ref_no = $request->ref_no;
        // $create_ncs->findings_of_assessment = $request->findings_of_assessment;
        // if ($create_ncs->save()) {
        //     return back()->with('success', 'NC has been created successfully for this record!!');
        // }

        $create_ncs = AppAssessmentNC::updateOrCreate(
            ['id' => $request->id],
            [
                'app_id' => $request->app_id,
                'org_id' => $request->org_id,
                'assessor_id' => $assessor->id,
                'assessment_id' => $assessment->id,
                'nc_for' => $request->nc_for,
                'topic' => $request->topic,
                'type' => $request->type,
                'ref_no' => $request->ref_no,
                'findings_of_assessment' => $request->findings_of_assessment,
            ]
        );

        if ($create_ncs) {
            return back()->with('success', 'NC has been created successfully for this record!!');
        }
    }

    public function GetNC($id)
    {
        $edit_nc = AppAssessmentNC::find($id);
        return response()->json($edit_nc);
    }

    public function Destroy($id)
    {
        AppAssessmentNC::find($id)->delete();
        return back()->with('success', 'Record has been deleted Successfully!!');
    }

    public function FreezeAll($app_id)
    {
        $assessor = Session('userRole');
        $app = ApplicationStatus::where('id', $app_id)->where('id', $app_id)->first();
        $user =  User::where('id', $app->user_id)->first();
        $assessment = AppAssessmentNC::where('app_id', $app_id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('isActive', 0)->update(['isActive' => 1]);
        // $assessment->isActive = 1;
        // dd($assessment->toArray());
        if ($assessment) {
            $update_stage = ApplicationStatus::where('id', $app_id)->first();
            $update_stage->stage = '2F';
            $update_stage->updated_by = 'Assessor_' . $assessor->id;
            if ($update_stage->save()) {
                $user = User::where('id', $update_stage->user_id)->first();
                // dd($user->email);
                $mail =  AppMail::where('template_name', 'NC Report Sent to CB')->first();
                Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                if (Mail::failures() != 0) {
                    $allotment = AppUserAllotment::where('app_id', $app_id)->where('org_id', $app->user_id)->where('alloted_to', $assessor->id)->first();
                    $user = AdminUser::where('id', $allotment->alloted_by)->first();
                    if (!$user) {
                        $user = AdminUser::where('id', $assessor->id)->first();
                    }
                    $mail =  AppMail::where('template_name', 'NC Report Sent to DO')->first();
                    Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                    if (Mail::failures() != 0) {
                        return back()->with('success', 'All NC has been sent to ORG successfully!!');
                    }
                }
                return back()->with('message', 'Failed! there is some issue with email provider');
            }
        }
    }

    public function ExistingNC($app_id)
    {
        $assessor = Session('userRole');
        $app = ApplicationStatus::where('id', $app_id)->where('isDeleted', 0)->first();
        $user =  User::where('id', $app->user_id)->first();
        // dd($app_id);
        $assessment = AppAssessment::where('app_id', $app_id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        
        $assessor_ncs = AppAssessmentNC::where('app_id', $app_id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('assessment_id', $assessment->id)->where('isActive', 1)->get();
        // $nc_status = AppAssessmentNC::where('assessor_id',$assessor->id)->where('assessment_id',$assessment->id)->where('isActive',1)->where('status',1)->count();
        // dd($assessor_ncs);
        return view('assessor.existing-nc', ['assessor_ncs' => $assessor_ncs, 'user' => $user, 'app_id' => $app_id, 'assessment' => $assessment]);
    }

    public function ExistingNCReply($id)
    {
        $data = AppAssessmentNC::find($id);
        // dd($data);
        return response()->json($data);
    }

    public function ReplyToORG(Request $request)
    {
        // dd($request->all());
        $assessor = Session('userRole');
        $add_reply = new AppReply();
        $add_reply->assessor_id = $assessor->id;
        $add_reply->reply_to = $request->id;
        $add_reply->assessor_reply = $request->reply;
        if ($add_reply->save()) {
            return back()->with('success', 'Your reply has been sent to CB');
        }
    }

    public function CloseNC($id)
    {
        $update_nc = AppAssessmentNC::where('id', $id)->first();
        $update_nc->status = 1;
        if ($update_nc->save()) {
            return back()->with('success', 'This NC has been close Now!!');
        }
    }

    public function CloseAllNC($app_id)
    {
        $assessor = Session('userRole');
        $app = ApplicationStatus::where('id', $app_id)->first();
        $user = User::where('id', $app->user_id)->first();
        $allotment = AppUserAllotment::where('app_id', $app_id)->where('org_id', $user->id)->where('alloted_to', $assessor->id)->where('isActive', 0)->first();
        $assessment = AppAssessment::where('app_id', $app->id)->where('org_id', $user->id)->where('assessor_id', $assessor->id)->where('isActive', 0)->first();
        $app->stage = '3';
        $app->updated_by = 'Assessor_' . $assessor->id;
        if ($app->save()) {
            $user = User::where('id', $app->user_id)->first();
            // dd($user->email);Assessor Reply
            $mail =  AppMail::where('template_name', 'Assessment Close')->first();
            Mail::to($user->email)->send(new ApplicationMail($user, $mail));
            if (Mail::failures() != 0) {
                $user = AdminUser::where('id', $allotment->alloted_by)->first();
                if (!$user) {
                    $user = AdminUser::where('id', $assessor->id)->first();
                }
                $mail =  AppMail::where('template_name', 'Assessment Close Report Sent to DO')->first();
                Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                if (Mail::failures() != 0) {
                    return redirect('assessor/applications')->with('success', 'NC Close Report Send to DO');
                }
            }
            return back()->with('message', 'Failed! there is some issue with email provider');
        }
    }

    public function Replies($nc_id, $app_id)
    {
        // dd($nc_id);
        $assessor = Session('userRole');
        $application = ApplicationStatus::where('id', $app_id)->first();
        $assessment = AppAssessment::where('assessor_id', $assessor->id)
            ->where('org_id', $application->user_id)
            ->where('app_id', $application->id)
            ->where('isActive', 0)->first();
        $replies = AppNcReply::where('org_id', $application->user_id)->where('app_id', $application->id)->where('nc_id', $nc_id)->get();
        // dd($replies->toArray());
        return view('assessor.replies', ['replies' => $replies, 'app_id' => $app_id, 'nc_id' => $nc_id, 'assessor_id' => $assessor->id, 'assessment_id' => $assessment->id]);
    }

    public function SubmitReply(Request $request)
    {
        $app = ApplicationStatus::where('id', $request->app_id)->where('user_id', $request->org_id)->first();
        $save_reply = new AppNcReply();
        $save_reply->app_id = $app->id;
        $save_reply->org_id = $request->org_id;
        $save_reply->nc_id = $request->nc_id;
        $save_reply->assessor_id = $request->assessor_id;
        $save_reply->assessment_id = $request->assessment_id;
        $save_reply->reply = $request->reply;
        $save_reply->reply_by = "Assessor";
        // dd($save_reply);
        if ($save_reply->save()) {
            return redirect('assessor/existing-nc/' . $request->app_id)->with('success', 'Click on send replies to CB !!');
        }
    }

    public function SendReplyToCB($app_id)
    {
        $app = ApplicationStatus::where('id', $app_id)->where('isDeleted', 0)->first();
        $user = User::where('id', $app->user_id)->first();
        $updateReply = AppNcReply::where('app_id', $app_id)->where('org_id', $user->id)->where('isActive', 0)->update(['isActive' => 1]);
        if ($updateReply) {
            $update_stage = ApplicationStatus::where('id', $app_id)->where('user_id', $user->id)->first();
            $update_stage->stage = '2F';
            if ($update_stage->save()) {
                $user = User::where('id', $app->user_id)->first();
                // dd($user->email);
                $mail =  AppMail::where('template_name', 'Assessor Reply')->first();
                Mail::to($user->email)->send(new ApplicationMail($user, $mail));
                if (Mail::failures() != 0) {
                    return redirect()->route('reply.orgnc', [$app_id])->with('success', 'All replies has been sent to CB !!');
                }
                return back()->with('message', 'Failed! there is some issue with email provider');
            }
        }
    }
}
