<?php

namespace App\Http\Controllers\Assessor;

use App\AppAssessment;
use App\AppAssessmentReport;
use App\ApplicationStatus;
use App\AppUserAllotment;
use App\Clerification;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AssessmentReportController extends Controller
{
    public function index($app_id)
    {
        $app = ApplicationStatus::where('id', $app_id)->where('isDeleted',0)->first();
        $assessor = Session('userRole');
        $assessor_id = $assessor->id;
        $assessment_reports = AppAssessmentReport::where('org_id',$app->user_id)->where('app_id',$app->id)->where('assessor_id',$assessor_id)->get();
        return view('assessor.assessment-report',['org_id'=>$app->user_id,'app_id'=>$app_id,'assessment_reports'=>$assessment_reports]);
    }

    public function SubmitReport(Request $request)
    {
        $request->validate([
            'doc_name'=>'required',
            'doc_file'=>'required'
        ]);
        $app = ApplicationStatus::where('id', $request->app_id)->where('user_id', $request->org_id)->first();
        $assessor = Session('userRole');
        $assessor_id = $assessor->id;
        $dest = public_path('/assets/assessments/');
        if($request->hasFile('doc_file')){
            $doc_file_image = $request->file('doc_file');
            $doc_file = time().'_assessor_'.$assessor_id.'_app_'.$request->app_id.'.'. $doc_file_image->getClientOriginalExtension();
            $doc_file_image->move($dest, $doc_file);
        }else{
            $doc_file = $request->old_doc_file;
        }
        $assessment_report = AppAssessmentReport::updateOrCreate(
            ['id'=>$request->id],
            [
                'app_id' => $app->id,
                'org_id' => $request->org_id,
                'assessor_id' => $assessor->id,
                'doc_name' => $request->doc_name,
                'doc_file' => $doc_file
            ]
         );
        // dd($assessment_report);
        if($assessment_report->save()){
            return back()->with('success', 'Assessment Report has been created successfully!!');
        }
    }

    public function EditReport($id)
    {
        $edit_report = AppAssessmentReport::find($id);
        return response()->json($edit_report);
    }

    public function Destroy($id)
    {
        AppAssessmentReport::find($id)->delete();
        return back()->with('success', 'Record has been deleted Successfully!!');
    }

    public function AssessmentCompleted()
    {
        $assessor = Session('userRole');
        $assessment = AppAssessment::where('assessor_id',$assessor->id)->where('assessor_action','Accept')->where('cb_action','Accept')->where('isActive',0)->first();
        // dd($assessment);
        $app = ApplicationStatus::where('id',$assessment->app_id)->first();
        $allotments = AppUserAllotment::where('alloted_to', $assessor->id)->where('isActive', 0)->get();
        
        return view('assessor.completed-assessment', ['allotments'=>$allotments]);
    }

    public function Clerification($id)
    {        
        $app = ApplicationStatus::where('user_id',$id)->first();
        $clerifications = Clerification::where('org_id',$id)->where('app_id',$app->id)->get();
        return view('assessor.clerification', ['id'=>$id,'app'=>$app,'clerifications'=>$clerifications]);
    }

    public function ClerificationSubmit(Request $request)
    {
        $loginuser = Session('userRole');
        // $assessment = AppAssessment::where('org_id',$request->org_id)->where('app_id',$request->app_id)->where('isActive',0)->first();
        $user_allotment = AppUserAllotment::where('org_id',$request->org_id)->where('app_id',$request->app_id)->where('alloted_to',$loginuser->id)->where('isActive',0)->first();
        $dest = public_path('/assets/images/clerification/');
        
        //1. file format org_id_app_id_random_time_filename
        if($request->hasFile('file')){
            $file_image = $request->file('file');
            $file = $request->org_id.'_'.$request->app_id.'_'.rand(10000, 99999).'_'.time().'_clerification.'. $file_image->getClientOriginalExtension();
            $file_image->move($dest, $file);
        }else{
            $file = "NA";
        }
        $clerification = new Clerification();
        $clerification->app_id = $request->app_id;
        $clerification->org_id = $request->org_id;
        $clerification->do_id = $user_allotment->alloted_by;
        $clerification->assessor_id = $loginuser->id;
        $clerification->file = $file;
        $clerification->clerification_for = $request->clerification_for;
        $clerification->clerification_by = "Assessor";
        $clerification->clerification = $request->clerification;
        // dd($clerification->toArray());
        if($clerification->save()){
            return back()->with('success','Your Clerification report created successfully');
        }
        
    }
}
