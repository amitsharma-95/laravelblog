<?php

namespace App\Http\Controllers;

use App\AppBranchAddress;
use App\AppFinancialPerformance;
use App\AppGeneralInfo;
use App\ApplicationStatus;
use App\AppLocation;
use App\AppPersonnelInformation;
use App\AppVoluntaryCertificationScheme;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PersonnelInformationController extends Controller
{
    public function index($app_id)
    {
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->where('id',$app_id)->first();
        // $app_id = $app_status->id;
        // DB::connection()->enableQueryLog();
        // $queries = DB::getQueryLog();
        $personnel_infos = AppPersonnelInformation::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->first();
        // $queries = DB::getQueryLog();
            //             $last_query = end($queries); 
            //             dd($last_query);  
        // dd($personnel_infos->org_id);
        if ($personnel_infos==null) {
            $personnel_infos = [];
        }
        $branch_address = AppBranchAddress::where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($branch_address==null) {
            $branch_address = [];
        }
        $certification_scheme = AppVoluntaryCertificationScheme::where('branch_id','!=', null)->where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->get();
        if ($certification_scheme==null) {
            $certification_scheme = [];
        }
        $certification_scheme_main = AppVoluntaryCertificationScheme::where('branch_id',null)->where('org_id', $org_id)->where('app_id', $app_id)->where('isDeleted', 0)->first();
        // dd($certification_scheme);
        return view('applicationform.personnel-information', ['app_id'=>$app_id,'personnel_infos'=>$personnel_infos,
        'certification_scheme_main'=>$certification_scheme_main,'branch_address'=>$branch_address,
        'certification_scheme'=>$certification_scheme]);
    }

    public function store(Request $req)
    {
        $req->validate([
            'quality_manager_name' => 'required',
            'quality_manager_designation' => 'required'
        ]);
        $org_id = session('user_id');
        // $app_status = ApplicationStatus::where('user_id', $org_id)->first();
        $app_id = $req->app_id;
        
        // DB::connection()->enableQueryLog();
        $personnel_info = AppPersonnelInformation::updateOrCreate(
            [
                'org_id'=>$org_id,
                'app_id'=>$app_id
            ],
            [
                'quality_manager_name'=>$req->quality_manager_name,
                'quality_manager_designation'=>$req->quality_manager_designation
            ]);
            // $queries = DB::getQueryLog();
            //             $last_query = end($queries); 
            //             dd($last_query);  
         if ($personnel_info) {
             $scheme_id = $req->scheme_id;
             $branch_id = $req->branch_id;
             $location = $req->location;
             $managerial_staff = $req->managerial_staff;
             $evaluators = $req->evaluators;
             $support_staff = $req->support_staff;
             $technical_experts = $req->technical_experts;
             $total = $req->total;
            //  dd($location);
             for ($i=0; $i < count($evaluators) ; $i++) { 
                // DB::connection()->enableQueryLog();
                $checkScheme = AppVoluntaryCertificationScheme::where('id', $scheme_id[$i])->where('org_id', $org_id)->where('app_id', $app_id)->first();
                // $queries = DB::getQueryLog();
                // $last_query = end($queries); 
                $total[$i] = $managerial_staff[$i] + $evaluators[$i] + $support_staff[$i] +  $technical_experts[$i];
                $datasave = [
                    'org_id' => $org_id,
                    'app_id' => $app_id,
                    'branch_id' =>$branch_id[$i],
                    'location' => $location[$i],
                    'managerial_staff' => $managerial_staff[$i],
                    'evaluators' => $evaluators[$i],
                    'support_staff' => $support_staff[$i],
                    'technical_experts' => $technical_experts[$i],
                    'total' => $total[$i],
                ];
                if($checkScheme == null){
                    // dd("inserted");
                          DB::table('app_voluntary_certification_schemes')->insert($datasave);
                    }else{
                        // dd("updated");
                        DB::table('app_voluntary_certification_schemes')->where('id', $scheme_id[$i])->update($datasave);
                    }
             }
             
             return back()->with('success', 'Changes has been saved successfully!!');
         }
    }

    public function deleteFinanceRecord($id)
    {
        $financial_address = AppFinancialPerformance::find($id);
        $financial_address->isDeleted = "1";
        $financial_address->save();
        return back()->with('success', 'Record Deleted Successfully!!');
    }
}
