<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppUserRole extends Model
{
    public function adminUser()
    {
        return $this->hasMany(AdminUser::class);
    }

    public function Role()
    {
        return $this->hasMany(AppRole::class);
    }

}
