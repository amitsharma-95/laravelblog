<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppGeneralInfo extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'assessment_body_name',
        'ab_mobile',
        'ab_email',
        'main_ofc_address',
        'state',
        'city',
        'pin',
        'fax',
        'web',
        'owneship_detail',
        'status',
        'reg_no',
        'reg_date',
        'reg_authority',
        'reg_place',
        'chief_name',
        'chief_designation',
        'p_designation',
        'p_phone',
        'option'
    ];
}
