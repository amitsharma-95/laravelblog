<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppRole extends Model
{
    protected $fillable = [
        'role_name'
    ];

    public function adminUser()
    {
        return $this->hasOne(AdminUser::class);
    }
}
