<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminUser extends Model
{
    protected $fillable = [
        'name',
        'email',
        'mobile',
        'username',
        'password',
        'role_id',
    ];

    // public function Role()
    // {
    //     return $this->hasMany(AppRole::class);
    // }

    public function role()
    {
        return $this->belongsTo(AppRole::class);
    }
}

