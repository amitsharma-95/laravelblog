<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VerifyOTP extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $otp;

    public function __construct($otp)
    {
        $this->otp = $otp;
    }

    public function build()
    {
        $user['otp'] = $this->otp;
        return $this->from("iconicamitweb@gmail.com", "Verification Mail By QCI")
        ->subject('One Time Password')
        ->view('template.one-time-password', ['user' => $user]);
    }
}