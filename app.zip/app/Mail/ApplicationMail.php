<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ApplicationMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;
    public $mail;
    public $user;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($user,$mail)
    {
        $this->user = $user;
        $this->mail = $mail;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $user = $this->user;
        $mail = $this->mail;
        return $this->from('noreply@gmail.com', $this->mail['sender_name'])
        ->subject($this->mail['subject'])
        ->view('template.application',['user'=>$user,'mail'=>$mail]);
    }
}
