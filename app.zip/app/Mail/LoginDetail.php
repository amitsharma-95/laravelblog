<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LoginDetail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $name;
    public $username;
    public $password; 

    public function __construct($name, $username, $password)
    {
        $this->name = $name;
        $this->username = $username;
        $this->password = $password;
    }

    public function build()
    {
        $user['name'] =  $this->name;
        $user['username'] =  $this->username;
        $user['password'] =  $this->password;
        return $this->from("iconicamitweb@gmail.com", "QCI")
        ->subject('Login Credentials')
        ->view('template.login-credentials', ['user' => $user]);
    }
}