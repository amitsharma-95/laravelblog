<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppScrutiny extends Model
{
    protected $fillable = [
        'org_id',
        'app_id',
        'alloted_user_id',
        'option',
        'remark',
        'scrutiny_for'
    ];
}
