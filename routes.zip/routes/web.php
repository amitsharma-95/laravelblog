<?php

use App\Http\Controllers\Admin\AllotmentController;
use App\Http\Controllers\Admin\ApplicationController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\AnnexedInformationController;
use App\Http\Controllers\AppLocationController;
use App\Http\Controllers\Assessor\AssessmentReportController;
use App\Http\Controllers\Assessor\AssessorController;
use App\Http\Controllers\Assessor\NcsController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\VerifyController;
use App\Http\Controllers\DeclerationController;
use App\Http\Controllers\FinancialPerformanceController;
use App\Http\Controllers\GeneralInformationController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OtherInformationController;
use App\Http\Controllers\PersonnelInformationController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserRole\AdminUserRoleController;
use App\Http\Controllers\UserRole\ClosuerController;
use App\Http\Controllers\UserRole\ScrutinyController;
use App\Http\Controllers\UserRole\UserAllotmentController;
use Symfony\Component\Console\Input\Input;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('register');
});
Route::fallback(function () {
    return view('errors.404');
});

Route::get('/notify-test', [HomeController::class, 'Notify']);
// Route::get('/barcode', [HomeController::class,'barcode']);
// Route::get('/test-mail', [HomeController::class, 'test']);
Route::get('scheme-level', [AuthController::class, 'SchemeLevel']);
// Route::get('test', [AuthController::class, 'test']);
Route::get('register', [AuthController::class, 'index'])->name('register');
Route::post('register-store', [AuthController::class, 'store'])->name('registeruser');
Route::get('login', [AuthController::class, 'login'])->name('login');
Route::post('login', [AuthController::class, 'submit_login'])->name('login');
Route::post('/verify_OTP', [VerifyController::class, 'verify_OTP'])->name('verifyOTP');
Route::post('/verify_Mail', [VerifyController::class, 'is_verified']);
Route::post('/verifyMobileOTP', [VerifyController::class, 'verifyMobile_OTP']);
Route::post('verifyMobile', [VerifyController::class, 'Mobile_verified']);

Route::get('forgot-password', [UserController::class, 'forgotPassword'])->name('forgot-password');
Route::get('forgot-password/{token}', [UserController::class, 'forgotPasswordValidate'])->name('forgot.password');
Route::post('forgot-password', [UserController::class, 'resetPassword'])->name('forgot-password');
Route::put('reset-password', [UserController::class, 'updatePassword'])->name('reset-password');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

// Route::post('/add-location', [AppLocationController::class,'store']);
// Route::get('application-form', [GeneralInformationController::class, 'index']);
// Route::post('/general-information', [GeneralInformationController::class, 'store']);
// Route::get('personnel-information', [PersonnelInformationController::class, 'index']);
// Route::post('personnel-information', [PersonnelInformationController::class, 'store'])->name('create.personel_info');
// // Route::get('personnel-information', [PersonnelInformationController::class, 'index']);
// Route::get('delete-personnel-information/{id}', [PersonnelInformationController::class, 'destroy']);
Route::group(['middleware'=>['AuthCheck']], function(){
    Route::get('dashboard', [HomeController::class, 'index'])->name('dashboard');
    Route::post('create-app', [HomeController::class, 'Create'])->name('create.app');
    Route::get('application-form/{app_id}', [GeneralInformationController::class, 'index'])->name('general.information');
    Route::post('general-information', [GeneralInformationController::class, 'store']);
    Route::get('delete/branch/{id}', [GeneralInformationController::class, 'deleteBranch']);
    Route::get('personnel-information/{app_id}', [PersonnelInformationController::class, 'index'])->name('personnel.Information');
    Route::post('personnel-information', [PersonnelInformationController::class, 'store'])->name('create.personel_info');
    Route::get('financial-performance/{app_id}', [FinancialPerformanceController::class, 'index'])->name('financialinfo');
    Route::get('delete/financial/{id}', [FinancialPerformanceController::class, 'deleteFinanceRecord'])->name('deleteFinancialPerformance');
    Route::post('financial-performance', [FinancialPerformanceController::class, 'store'])->name('financialPerformance');
    Route::get('other-information/{app_id}', [OtherInformationController::class, 'index'])->name('other.info');
    Route::post('other-information', [OtherInformationController::class, 'store'])->name('other.information');
    Route::get('delete/nabcb-bodies/{id}', [OtherInformationController::class, 'deleteNabcb'])->name('deleteNabcb');
    Route::get('delete/iaf-bodies/{id}', [OtherInformationController::class, 'deleteIAF'])->name('deleteIAF');
    Route::get('delete/other-approvals/{id}', [OtherInformationController::class, 'deleteOther'])->name('deleteOther');
    Route::get('annexed-information/{app_id}', [AnnexedInformationController::class, 'index'])->name('annexed.information');
    Route::post('annexed-information-store', [AnnexedInformationController::class, 'store'])->name('annexed.store');
    Route::post('upload-file', [AnnexedInformationController::class, 'UploadFile'])->name('upload.file');
    Route::get('annexed/delete/{id}', [AnnexedInformationController::class, 'DeleteFile'])->name('annexed.delete');
    Route::get('declaration/{app_id}', [DeclerationController::class, 'index'])->name('declaration');
    Route::post('declaration/submit', [DeclerationController::class, 'submit'])->name('declaration.submit');
    Route::get('application/{app_id}', [HomeController::class, 'SubmittedApp'])->name('submitted.application');
    Route::get('application/preview/{app_id}', [HomeController::class, 'Preview'])->name('myapplication.preview');
    Route::get('send-back/{app_id}',[HomeController::class, 'SendBack'])->name('sendback');
    Route::get('SubmitForm', [HomeController::class,'SubmitForm'])->name('SubmitForm');
    Route::post('action', [HomeController::class, 'Action'])->name('cb.action');
    Route::get('reply-nc/{app_id}', [HomeController::class, 'NCReply'])->name('reply.nc');
    Route::get('nc-reply/{id}', [HomeController::class, 'ReplyNC'])->name('nc.reply');
    Route::post('submit-reply', [HomeController::class, 'SubmitReply'])->name('submitto.reply');
    Route::get('reply-to-assessor/{app_id}', [HomeController::class, 'ReplytoAssessor'])->name('replytoassessor');
    Route::get('view-assessment/{app_id}', [HomeController::class, 'ViewAssessment'])->name('view.assessment');
});

Route::group(['middleware'=>['AdminCheck']], function(){
    Route::get('admin/login', [DashboardController::class, 'AdminLogin'])->name('admin.login');
    Route::post('admin/login', [DashboardController::class, 'Login'])->name('admin.login');
    Route::get('admin/dashboard', [DashboardController::class, 'AdminDashboard'])->name('admin.dashboard');
    Route::get('admin/users', [AdminUserController::class, 'index'])->name('admin.users');
    Route::post('admin/users', [AdminUserController::class, 'store'])->name('create.user');
    Route::get('admin/user/{id}/edit', [AdminUserController::class, 'edit']);
    Route::get('admin/user/{id}/delete', [AdminUserController::class, 'destroy']);
    Route::get('admin/roles', [RoleController::class, 'index'])->name('admin.roles');
    Route::post('admin/create/role', [RoleController::class, 'store'])->name('create.role');
    Route::get('admin/role/{id}/edit', [RoleController::class, 'edit']);
    Route::get('admin/role/{id}/delete', [RoleController::class, 'destroy']);
    Route::get('admin/application', [ApplicationController::class, 'index'])->name('all.application');
    Route::get('admin/application/preview/{app_id}', [ApplicationController::class, 'Preview'])->name('adminapplication.preview');
    Route::get('admin/allotment', [AllotmentController::class, 'index'])->name('allotment');
    Route::get('admin/not-alloted', [AllotmentController::class, 'NotAlloted'])->name('not.alloted');
    Route::get('admin/alloted', [AllotmentController::class, 'Alloted'])->name('alloted');
    Route::get('admin/allotment/user/{app_id}', [AllotmentController::class, 'Allotuser'])->name('allotments');
    Route::post('admin/allotment/user', [AllotmentController::class, 'UserAllotment'])->name('allotment.user');
    Route::get('admin/email', [AdminUserController::class, 'ManageEmail'])->name('manage.email');
    Route::get('admin/email/{id}/edit', [AdminUserController::class, 'editEmail'])->name('update.email');
    Route::post('admin/edit-email', [AdminUserController::class, 'Editmail'])->name('edit.mail');
    Route::get('admin/logout', [DashboardController::class, 'Adminlogout'])->name('admin.logout');
});

Route::group(['middleware'=>['CheckUserRole']], function(){
    Route::get('adminuser/login', [AdminUserRoleController::class, 'login'])->name('adminuser.login');
    Route::post('adminuser/login', [AdminUserRoleController::class, 'UserRoleLogin'])->name('adminuser.login');
    Route::get('adminuser/dashboard', [AdminUserRoleController::class, 'AdminUserDashboard'])->name('adminuser.dashboard');
    Route::get('adminuser/alloted', [UserAllotmentController::class, 'index'])->name('alloted.application');
    Route::get('adminuser/pending', [UserAllotmentController::class, 'Pending'])->name('pending');
    Route::get('adminuser/processing', [UserAllotmentController::class, 'Processing'])->name('processing');
    Route::get('adminuser/closed', [UserAllotmentController::class, 'Closed'])->name('closed');
    Route::get('adminuser/application/preview/{id}', [ApplicationController::class, 'Preview'])->name('application.preview');
    Route::get('adminuser/scrutiny/{app_id}', [ScrutinyController::class, 'index'])->name('scrutiny');
    Route::post('adminuser/scrutiny', [ScrutinyController::class, 'store'])->name('adminuser.scrutiny');
    //personnal
    Route::get('adminuser/personnel/scrutiny/{app_id}', [ScrutinyController::class, 'personnelScrutiny'])->name('personnel.scrutiny');
    Route::get('adminuser/other/scrutiny/{app_id}', [ScrutinyController::class, 'otherScrutiny'])->name('other.scrutiny');
    Route::get('adminuser/financial/scrutiny/{app_id}', [ScrutinyController::class, 'financialScrutiny'])->name('financial.scrutiny');
    Route::get('adminuser/annexed/scrutiny/{app_id}', [ScrutinyController::class, 'annexedScrutiny'])->name('annexed.scrutiny');
    Route::get('adminuser/final/scrutiny/{app_id}', [ScrutinyController::class, 'finalScrutiny'])->name('final.scrutiny');

    Route::post('adminuser/send-to-cb', [ScrutinyController::class, 'SendToCB'])->name('sendtocb');
    Route::get('adminuser/scrutiny/close/{app_id}', [ScrutinyController::class, 'ScrutinyClose'])->name('scrutiny.close');
    Route::get('adminuser/allotment', [UserAllotmentController::class, 'Allotment'])->name('assessor.allotment');
    Route::get('adminuser/assessor-alloted', [UserAllotmentController::class, 'AllotedAssessor'])->name('allotedassessor');
    Route::get('adminuser/assessor-not-alloted', [UserAllotmentController::class, 'NotAllotedAssessor'])->name('not.allotedassessor');
    Route::get('adminuser/assessment-in-process', [UserAllotmentController::class, 'AssessmentInProcess'])->name('assessmentinprocess');
    Route::get('adminuser/allot-assessor/{app_id}', [UserAllotmentController::class, 'AllotAssessor'])->name('allot.assessor');
    Route::post('adminuser/assessor-allotment', [UserAllotmentController::class, 'AssessorAllotment'])->name('allotment.assessor');
    Route::get('adminuser/send-to-org/{org_id}', [AdminUserRoleController::class, 'SendToOrg'])->name('sendorgforacceptance');
    Route::get('adminuser/send-confirmation/{org_id}', [AdminUserRoleController::class, 'SendConfirmation'])->name('send.confirmation');
    Route::get('adminuser/ncreplies/{app_id}', [UserAllotmentController::class, 'viewNcReplies'])->name('ncreplies');
    Route::get('adminuser/view-replies/{nc_id}', [UserAllotmentController::class,'ViewReplies'])->name('viewreplies');
    Route::get('adminuser/clerification/{app_id}', [ClosuerController::class, 'Clerification'])->name('clerification');
    Route::post('adminuser/clerification/submit', [ClosuerController::class, 'ClerificationSubmit'])->name('clerification.submit');
    Route::get('adminuser/closure/{app_id}',[ClosuerController::class, 'Closuer'])->name('closure');
    Route::post('adminuser/closure/{id}',[ClosuerController::class, 'AssessmentClosuer'])->name('closure');
    Route::get('adminuser/certificate', [ClosuerController::class, 'Certificate'])->name('certificate');
    Route::get('adminuser/logout', [AdminUserRoleController::class, 'adminuserLogout'])->name('adminuser.logout');

    //assessor
    Route::get('assessor/dashboard', [AssessorController::class, 'Dashboard'])->name('assessor.dashboard');
    Route::get('assessor/applications', [AssessorController::class, 'AllotedApp'])->name('alloted.toassessor');
    Route::get('assessor/application/preview/{id}', [ApplicationController::class, 'Preview'])->name('ass.application.preview');
    Route::get('assessor/action/{app_id}', [AssessorController::class, 'Action'])->name('action');
    Route::post('assessor/action', [AssessorController::class, 'AssessorAcceptance'])->name('assessor.action');
    Route::get('assessor/assessment/{app_id}', [AssessorController::class, 'StartAssessment'])->name('start.assessment');
    Route::get('assessor/assessment-pending', [AssessorController::class, 'AssessmentPending'])->name('assessment.pending');
    Route::get('assessor/assessment-processing', [AssessorController::class, 'AssessmentProcessing'])->name('assessment.processing');
    Route::get('assessor/assessment-closed', [AssessorController::class, 'AssessmentClosed'])->name('assessment.closed');
    // Route::post('assessor/ncs', [NcsController::class, 'CreateNC'])->name('create.ncs');
    Route::post('assessor/generate-nc', [NcsController::class, 'GenerateNC'])->name('generate.nc');
    Route::get('assessor/getnc/{id}/edit', [NcsController::class, 'GetNC'])->name('assessor.getnc');
    Route::get('assessor/delete-nc/{id}', [NcsController::class, 'Destroy'])->name('delete.nc');
    Route::get('assessor/freeze-all-nc/{app_id}', [NcsController::class, 'FreezeAll'])->name('freeze.allnc');
    Route::get('assessor/existing-nc/{app_id}', [NcsController::class, 'ExistingNC'])->name('existing.nc');
    Route::get('assessor/send-reply-to-cb/{app_id}', [NcsController::class, 'SendReplyToCB'])->name('sendreplytocb');
    Route::post('assessor/submit-reply', [NcsController::class, 'SubmitReply'])->name('submit.reply');
    Route::get('assessor/existing-nc/{id}', [NcsController::class, 'ExistingNCReply'])->name('reply.orgnc');
    Route::get('assessor/replies/{nc_id}/{app_id}', [NcsController::class, 'Replies'])->name('replies');
    Route::post('assessor/reply-to-org', [NcsController::class, 'ReplyToORG'])->name('replyto.org');
    Route::get('assessor/close-nc/{id}', [NcsController::class,'CloseNC'])->name('closenc');
    Route::get('assessor/close-all-nc/{app_id}', [NcsController::class, 'CloseAllNC'])->name('close.all_nc');
    Route::get('assessor/assessment-report/{app_id}', [AssessmentReportController::class,'index'])->name('assessment.report');
    Route::post('assessor/submit-report', [AssessmentReportController::class, 'SubmitReport'])->name('submit.report');
    Route::get('assessor/edit-report/{id}', [AssessmentReportController::class, 'EditReport'])->name('edit.report');
    Route::get('assessor/delete-report/{id}', [AssessmentReportController::class, 'Destroy'])->name('delete.report');
    Route::get('assessor/clerification/{id}', [AssessmentReportController::class, 'Clerification'])->name('assessor.clerification');
    Route::post('assessor/clerification/submit', [AssessmentReportController::class, 'ClerificationSubmit'])->name('clerification.assessor');
    Route::get('assessor/complete-assessment', [AssessmentReportController::class, 'AssessmentCompleted'])->name('complete.assessment');
});
