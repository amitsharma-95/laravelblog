<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppAnnexedInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_annexed_information', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->string('org_reg_cert');
            $table->string('ref_of_vol');
            $table->string('applicable_acc_stand');
            $table->string('related_to_vol');
            $table->string('branch_activity');
            $table->string('list_of_experts');
            $table->string('other_cert')->nullable();
            $table->string('ref_of_any_vol')->nullable();
            $table->string('any_other_rel')->nullable();
            $table->integer('isDeleted');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_annexed_information');
    }
}
