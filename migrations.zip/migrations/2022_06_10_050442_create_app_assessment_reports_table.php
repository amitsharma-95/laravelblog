<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppAssessmentReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_assessment_reports', function (Blueprint $table) {
            $table->id();
            $table->integer('org_id');
            $table->integer('app_id');
            $table->integer('assessor_id');
            $table->string('doc_name');
            $table->string('doc_file');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_assessment_reports');
    }
}
