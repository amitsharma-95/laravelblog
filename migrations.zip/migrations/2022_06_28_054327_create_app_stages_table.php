<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppStagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_stages', function (Blueprint $table) {
            $table->id();
            $table->string('stage');
            $table->string('user_des');
            $table->string('assessor_des');
            $table->string('admin_des');
            $table->string('do_des');
            $table->integer('isActive')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_stages');
    }
}
