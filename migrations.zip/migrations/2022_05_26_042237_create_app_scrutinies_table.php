<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppScrutiniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_scrutinies', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('app_id');
            $table->bigInteger('org_id');
            $table->bigInteger('alloted_user_id');
            $table->bigInteger('option');
            $table->bigInteger('remark')->nullable();
            $table->bigInteger('scrutiny_for');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_scrutinies');
    }
}
