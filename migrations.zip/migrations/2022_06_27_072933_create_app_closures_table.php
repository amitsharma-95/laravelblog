<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppClosuresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_closures', function (Blueprint $table) {
            $table->id();
            $table->integer('org_id');
            $table->integer('app_id');
            $table->string('status');
            $table->date('from_date')->nullable();
            $table->date('to_date')->nullable();
            $table->text('final_remark')->nullable();
            $table->integer('isActive')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_closures');
    }
}
