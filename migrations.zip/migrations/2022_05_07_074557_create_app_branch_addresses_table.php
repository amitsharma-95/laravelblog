<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppBranchAddressesTable extends Migration
{
    /**
     * Run the migrations.
     * @return void
     */
    public function up()
    {
        Schema::create('app_branch_addresses', function (Blueprint $table) {
            $table->id();
            $table->integer('org_id');
            $table->integer('app_id');
            $table->text('branch_name');
            $table->text('branch_address');
            $table->string('branch_state');
            $table->string('branch_city');
            $table->integer('branch_pin');
            $table->string('branch_p_name');
            $table->string('branch_p_designation');
            $table->string('branch_p_mobile');
            $table->string('branch_p_email');
            $table->string('isDeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_branch_addresses');
    }
}
