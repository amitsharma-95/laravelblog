<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClerificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clerifications', function (Blueprint $table) {
            $table->id();
            $table->integer('app_id');
            $table->integer('org_id');
            $table->integer('assessor_id');
            $table->integer('do_id');
            $table->string('file');
            $table->string('clerification_for');
            $table->string('clerification_by');
            $table->text('clerification');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clerifications');
    }
}
