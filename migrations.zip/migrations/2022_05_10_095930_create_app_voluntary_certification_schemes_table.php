<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppVoluntaryCertificationSchemesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_voluntary_certification_schemes', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->bigInteger('branch_id');
            $table->string('location');
            $table->string('managerial_staff');
            $table->string('evaluators');
            $table->string('support_staff');
            $table->string('technical_experts');
            $table->string('total');
            $table->string('isDeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_voluntary_certification_schemes');
    }
}
