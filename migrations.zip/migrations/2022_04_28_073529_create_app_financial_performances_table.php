<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppFinancialPerformancesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_financial_performances', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->string('financial_year');
            $table->string('total_income');
            $table->string('income_from_certification');
            $table->string('net_profit');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_financial_performances');
    }
}
