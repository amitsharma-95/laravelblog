<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppPersonnelInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_personnel_information', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->string('quality_manager_name');
            $table->string('quality_manager_designation');
            $table->string('isDeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_personnel_information');
    }
}
