<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppGeneralInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_general_infos', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->string('assessment_body_name');
            $table->string('ab_mobile');
            $table->string('ab_email');
            $table->text('main_ofc_address');
            $table->string('state');
            $table->string('city');
            $table->string('pin');
            $table->string('fax')->nullable();
            $table->string('web')->nullable();
            $table->string('owneship_detail');
            $table->string('status');
            $table->string('reg_no');
            $table->date('reg_date');
            $table->string('reg_authority');
            $table->string('reg_place');
            $table->string('chief_name');
            $table->string('chief_designation');
            $table->string('p_designation');
            $table->string('p_phone')->nullable();
            $table->string('isDeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_general_infos');
    }
}
