<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppUserAllotmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_user_allotments', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('app_id');
            $table->bigInteger('user_id_of_allotment');
            $table->bigInteger('alloted_by');
            $table->bigInteger('alloted_to');
            $table->string('ip')->nullable();
            $table->string('type')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_user_allotments');
    }
}
