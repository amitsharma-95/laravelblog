<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppNcRepliesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_nc_replies', function (Blueprint $table) {
            $table->id();
            $table->integer('app_id');
            $table->integer('org_id');
            $table->integer('nc_id');
            $table->integer('assessor_id');
            $table->integer('assessment_id');
            $table->string('reply_by');
            $table->text('reply');
            $table->string('ref_doc');
            $table->integer('isActive')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_nc_replies');
    }
}
