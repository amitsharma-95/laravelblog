<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppOtherInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_other_information', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->text('other_activities');
            $table->text('related_org');
            $table->text('major_clients');
            $table->string('no_of_certificates');
            $table->string('total_certificate_issued');
            $table->integer('isDeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_other_information');
    }
}
