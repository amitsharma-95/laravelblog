<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppAssessmentNCSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_assessment_n_c_s', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('app_id');
            $table->bigInteger('org_id');
            $table->bigInteger('assessor_id');
            $table->bigInteger('assessment_id');
            $table->string('nc_for');
            $table->string('topic');
            $table->string('type');
            $table->string('ref_no');
            $table->string('findings_of_assessment');
            $table->string('isActive')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_assessment_n_c_s');
    }
}
