<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppAssessmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_assessments', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('org_id');
            $table->bigInteger('app_id');
            $table->integer('assessor_id');
            $table->dateTime('from_date');
            $table->dateTime('to_date');
            $table->string('assessor_action')->nullable();
            $table->text('assessor_remark')->nullable();
            $table->string('cb_action')->nullable();
            $table->text('cb_remark')->nullable();
            $table->integer('isActive')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_assessments');
    }
}
